"""Runs the whole test suite and writes docs/test_cases.md with REAL results (status and timing come from the run)."""
import io, os, sys, time, unittest
from datetime import datetime

CASES = [  # (test id, area, input, expected result)
 ("test_products.LoginTests.test_login_success_and_failures", "Login", "admin/Admin@123; wrong password; unknown user; empty fields", "Valid login returns the user; the rest are rejected with a message"),
 ("test_products.LoginTests.test_password_is_hashed_and_salted", "Login", "Read stored hash; hash same password twice", "Plain text not stored; the two hashes differ (random salt)"),
 ("test_products.LoginTests.test_lockout_after_repeated_failures", "Login", "5 wrong passwords then the right one", "Account locked for 30 s even with the right password"),
 ("test_products.ProductTests.test_add_and_codes_and_opening_movement", "Products", "Add 2 products (qty 10 and 0)", "Codes P0001, P0002; opening movement only when qty > 0"),
 ("test_products.ProductTests.test_duplicate_sku_is_rejected_case_insensitively", "Products", "Add SKU 'DUP-1' then 'dup-1'", "Second is rejected; nothing half-saved"),
 ("test_products.ProductTests.test_validation", "Products", "Empty name, bad SKU, text price, negative price, 1.5 qty, negative qty, no category", "Each raises a validation error"),
 ("test_products.ProductTests.test_update_does_not_touch_stock_and_returns_old_values", "Products", "Rename + reprice a product with qty 7", "Details change, stock stays 7, old values returned for undo"),
 ("test_products.ProductTests.test_delete_vs_archive", "Products", "Delete unused product; delete product that was sold", "Unused is removed; sold one is archived (kept for old invoices)"),
 ("test_products.ProductTests.test_categories_cannot_be_deleted_while_used", "Categories", "Delete a category that has products", "Blocked until products are reassigned; then products move"),
 ("test_products.ProductTests.test_supplier_rules", "Suppliers", "Duplicate company; bad phone; delete supplier with products", "All three rejected"),
 ("test_products.SearchSortIndexTests.test_all_methods_find_same_product", "Search", "Find id 3 / SKU 'idx-2' by hash, linear, binary", "All return 'Mango mouse'"),
 ("test_products.SearchSortIndexTests.test_not_found_and_bad_input", "Search", "Unknown SKU; id 'abc'", "Empty result, no crash"),
 ("test_products.SearchSortIndexTests.test_name_search_with_duplicates_and_prefix", "Search", "Two products named 'Apple cable'; prefix 'app'", "Both found by binary and linear; BST prefix finds all 3 'Apple...'"),
 ("test_products.SearchSortIndexTests.test_binary_is_cheaper_than_linear", "Search", "Find last of 65 products", "Binary uses fewer comparisons than linear"),
 ("test_products.SearchSortIndexTests.test_sort_by_every_key_and_algorithm_agree", "Sorting", "4 keys x asc/desc x bubble/merge", "Bubble and merge give the identical order"),
 ("test_dsa.SearchSortTests.test_sorts_match_python_sorted", "Sorting", "Random lists, sizes 0-150, both directions", "Equal to Python's sorted()"),
 ("test_dsa.SearchSortTests.test_sorts_are_stable", "Sorting", "Pairs with equal keys", "Equal keys keep original order"),
 ("test_dsa.SearchSortTests.test_binary_search_every_element_random", "Searching", "200 random sorted numbers", "Every element found at its own index"),
 ("test_dsa.BSTTests.test_balanced_height_vs_stick", "BST", "127 sorted keys: balanced build vs one-by-one insert", "Height 7 vs 127"),
 ("test_dsa.QueueTests.test_fifo_and_growth_with_wraparound", "Queue", "Enqueue/dequeue past the array end, forcing growth", "FIFO order preserved"),
 ("test_dsa.StackTests.test_empty_errors", "Stack", "pop/peek on empty stack", "IndexError"),
 ("test_dsa.HashTableTests.test_collisions_are_handled", "Hash table", "10 keys with identical hash", "All 10 retrievable"),
 ("test_dsa.LinkedListTests.test_prepend_append_reverse_remove", "Linked list", "prepend, append, reverse, remove", "Correct order and size"),
 ("test_inventory.StockTests.test_adjustment_records_movement_and_reason", "Stock", "Adjust 10 -> 7 with reason", "Movement -3, after 7, reason and user stored"),
 ("test_inventory.StockTests.test_stock_can_never_go_negative", "Stock", "Remove 3 from stock of 2; raw SQL quantity=-1", "Both refused; stock stays 2"),
 ("test_inventory.StockTests.test_consistency_check_and_recalculate", "Stock", "Corrupt a quantity by hand", "Mismatch detected; recalculation restores it"),
 ("test_inventory.LowStockTests.test_low_out_and_suggested_quantity", "Low stock", "OK, low, out and edge (qty = reorder) products", "Correct status and suggested order sizes"),
 ("test_inventory.RestockQueueTests.test_fifo_processing_and_duplicates", "Queue", "Queue 2 products, duplicate, process 3 times", "FIFO order; duplicate and empty queue refused"),
 ("test_inventory.UndoTests.test_undo_adjustment_and_edit_in_lifo_order", "Stack / undo", "Adjust, edit, undo, undo, undo", "Edit undone first, then adjustment, then 'nothing to undo'"),
 ("test_transactions.PurchaseTests.test_draft_does_not_change_stock_confirm_does_once", "Purchase", "Draft then confirm 25 units, then confirm again", "Stock +25 once; second confirm refused"),
 ("test_transactions.PurchaseTests.test_failed_confirm_rolls_back_everything", "Rollback", "Database error injected during confirm", "Status stays DRAFT, stock unchanged"),
 ("test_transactions.SalesTests.test_calc_totals_exact_decimal_rounding", "Sales", "3 x 19.99 + 1 x 0.10, 10% discount, 18% tax", "Subtotal 60.07, discount 6.01, tax 9.73, total 63.79"),
 ("test_transactions.SalesTests.test_successful_sale_deducts_stock_and_stores_totals", "Sales", "2 x 100 + 1 x 50, 10% discount, 18% tax", "Total 265.50; stock reduced; invoice number created"),
 ("test_transactions.SalesTests.test_insufficient_stock_rejects_whole_sale", "Sales", "Line 1 fine, line 2 asks 5 of 2", "Whole sale rejected; line 1 NOT deducted; no invoice saved"),
 ("test_transactions.SalesTests.test_duplicate_submit_is_blocked", "Sales", "Same form token submitted twice", "Second refused; stock reduced once"),
 ("test_transactions.SalesTests.test_partial_return_then_cancel_restore_stock", "Returns", "Sell 4, return 1, over-return, cancel", "Refund 106.20; stock restored; over-return refused"),
 ("test_transactions.SalesTests.test_failed_sale_rolls_back_with_midway_database_error", "Rollback", "Database error on the 2nd line of a sale", "Nothing saved, both stocks unchanged"),
 ("test_reports_backup.ReportTests.test_valuation_and_dashboard", "Reports", "2 products, cost 250 / retail 400", "Valuation and dashboard figures match"),
 ("test_reports_backup.ReportTests.test_profit_is_not_revenue_and_handles_discount_and_returns", "Profit", "Sell 5 at 100 (cost 60), 10% off; return 2", "Profit 150 then 90; tax excluded from revenue"),
 ("test_reports_backup.ReportTests.test_every_report_runs_and_exports_csv", "CSV export", "Run all 9 reports on demo data", "CSV rows equal report rows; headers match"),
 ("test_reports_backup.CsvImportTests.test_round_trip_and_error_reporting", "CSV import", "Valid row + duplicate + bad price + unknown supplier", "1 imported, 4 errors reported"),
 ("test_reports_backup.BackupTests.test_backup_then_restore_brings_data_back", "Backup", "Backup, change data, restore", "Original data back; safety copy created"),
 ("test_reports_backup.BackupTests.test_invalid_backups_are_refused", "Backup", "Junk file, wrong database, missing file, live DB", "All refused"),
 ("test_reports_backup.PersistenceTests.test_data_survives_closing_and_reopening", "Persistence", "Sell, close, reopen database", "Quantity, sale and login still there"),
]

class Timed(unittest.TextTestResult):
    def startTest(self, test): self._t = time.perf_counter(); super().startTest(test)
    def stopTest(self, test): self.times[test.id()] = time.perf_counter() - self._t; super().stopTest(test)

def main():
    root = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, root)
    suite = unittest.defaultTestLoader.discover(os.path.join(root, "tests"), top_level_dir=root)
    stream = io.StringIO()
    Timed.times = {}
    result = unittest.TextTestRunner(stream=stream, resultclass=Timed, verbosity=0).run(suite)
    bad = {t.id() for t, _ in result.failures + result.errors}
    status = lambda tid: "FAIL" if tid in bad else ("PASS" if any(k.endswith(tid) for k in Timed.times) else "NOT RUN")
    lines = ["# Test cases and results", "",
             f"Generated by `python make_test_report.py` on {datetime.now():%Y-%m-%d %H:%M}. The Status column comes from the run itself, not from typing.", "",
             f"**Whole suite: {result.testsRun} tests run, {len(result.failures)} failed, {len(result.errors)} errors.**", "",
             "Every test uses a brand-new temporary database, so your real inventory is never touched.", "",
             "| # | Area | Input / action | Expected result | Status |", "|---|------|----------------|-----------------|--------|"]
    for i, (tid, area, inp, exp) in enumerate(CASES, 1):
        lines.append(f"| {i} | {area} | {inp} | {exp} | {status(tid)} |")
    lines += ["", "## Not covered by automated tests", "",
              "- The Tkinter screens (layout, colours, animations). They were exercised only by a scripted check that drives every screen's code "
              "against the real services using a stand-in for Tkinter; you must open the app on Windows and click through it (see the demo script).",
              "- Windows-only behaviour such as the 'Open backup folder' button.", "",
              "## Full list of test methods", "", "| Test | Status | Seconds |", "|------|--------|---------|"]
    for tid in sorted(Timed.times):
        lines.append(f"| `{tid}` | {'FAIL' if tid in bad else 'PASS'} | {Timed.times[tid]:.3f} |")
    open(os.path.join(root, "docs", "test_cases.md"), "w", encoding="utf-8").write("\n".join(lines) + "\n")
    print(f"{result.testsRun} tests, {len(result.failures)} failures, {len(result.errors)} errors")
    missing = [c[0] for c in CASES if status(c[0]) == "NOT RUN"]
    if missing: print("Unmatched ids:", missing)
    return 0 if result.wasSuccessful() else 1

if __name__ == "__main__":
    sys.exit(main())
