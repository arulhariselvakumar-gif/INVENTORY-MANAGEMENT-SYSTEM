# StockWise Inventory - DSA Major Project (Project-2)

A desktop Inventory Management System for a small shop: products, categories, suppliers, purchases, sales with invoices,
returns, stock control with a full audit trail, low-stock alerts, reports, charts and backup/restore.
Built with **Python, Tkinter (ttk), SQLite and Matplotlib**. Works offline. No paid services.

The data structures and algorithms (stack, queue, linked list, hash table, binary search tree, linear/binary search,
bubble/merge sort) are written from scratch in `dsa/` and are really used by the application (table in `docs/algorithms.md`).

## 1. Install (Windows 10/11, VS Code)

1. Install Python 3.10 or newer from python.org. In the installer tick **"Add python.exe to PATH"** and keep **"tcl/tk and IDLE"** ticked.
2. Open this folder in VS Code, then open a terminal (`Ctrl + ~`) and run:

```
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## 2. Run

```
python main.py
```

* First run creates `data/inventory.db` and loads **demo data** (20 products, 4 suppliers, 11 sales, a return, a cancellation).
  Use `python main.py --empty` to start with an empty database instead.
* Sign in with **admin / Admin@123**, then change the password with the **Password** button in the sidebar.
* `python main.py --check` runs without a window and prints a health summary (useful to test the install).

## 3. Run the tests

```
python -m unittest discover -v
python make_test_report.py      # re-runs everything and rewrites docs/test_cases.md with real results
```

The tests use a temporary database, so your real data is never touched.

## 4. Folder map

```
main.py  config.py  database.py  auth.py  validators.py  errors.py  sample_data.py  make_test_report.py
dsa/        stack, queue_ds, linked_list, hash_table, binary_search_tree, searching, sorting   (no imports from the app)
services/   product, inventory (the ONLY code that changes stock), purchase, sales, master (categories+suppliers),
            report, csv, backup, undo, charts, container
ui/         app (window, sidebar, toasts), login, dashboard, products, masters, purchases, sales, stock (+low stock),
            search, reports, backup, widgets, theme, screen
tests/      test_dsa, test_products, test_inventory, test_transactions, test_reports_backup, base
docs/       architecture.md, algorithms.md, test_cases.md, VIVA_AND_DEMO.md, PROJECT_REPORT.md
data/ backups/ exports/    created/used at run time
```

Rules the code follows: the UI never writes SQL; services never import the UI; `dsa/` imports nothing from the app, so every
structure can be tested alone. The queue file is `queue_ds.py` (not `queue.py`) so it can never shadow Python's built-in `queue` module.
The recommended `models/` folder was left out on purpose: rows travel as plain dictionaries, which keeps the code shorter for a student project.

## 5. Things worth knowing

* **Stock only changes in one place** (`services/inventory_service.apply_stock_change`) and every change writes a stock movement. The sum of movements always equals the stored quantity; "Check consistency" on the Stock control page verifies it.
* **Purchases:** drafts do not touch stock. Confirming flips DRAFT to CONFIRMED and adds stock in one transaction, so confirming twice cannot add twice.
* **Sales:** all lines are checked and saved in one transaction; if any line lacks stock, nothing is saved. A per-form token blocks double submission.
* **Profit** is *estimated gross profit*: revenue after discount and returns (tax excluded) minus the cost price recorded at sale time. It is not net profit.
* **Delete product:** unused products are deleted; products with history are archived so old invoices stay correct.
* **Tax default** is 18% (config.py `DEFAULT_TAX_PERCENT`); it can be changed per sale. Currency symbol is in `config.CURRENCY`.
* **Restoring a backup** replaces all data (after saving a safety copy) and signs you out.

## 6. Troubleshooting

| Problem | Fix |
|---|---|
| `ModuleNotFoundError: No module named 'tkinter'` | Re-run the Python installer, choose Modify, tick **tcl/tk and IDLE**. |
| `ModuleNotFoundError: No module named 'matplotlib'` | Activate the venv (`.venv\Scripts\activate`) and run `pip install -r requirements.txt`. |
| `python` is not recognised | Re-install Python with **Add python.exe to PATH**, or use `py main.py`. |
| PowerShell blocks `activate` | Run `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`, or use the Command Prompt instead. |
| `database is locked` | Close other copies of the app; only one window should use `data/inventory.db`. |
| Rupee sign looks wrong in Excel | CSV files are saved as UTF-8 with BOM; use Excel's Data > From Text/CSV and choose UTF-8 if needed. |
| Forgot the admin password | Close the app, delete `data/inventory.db` (this erases data - restore a backup afterwards) and start again. |
| Unexpected error dialog | Details are written to `data/app.log`. |
