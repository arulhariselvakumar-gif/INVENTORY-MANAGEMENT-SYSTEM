"""Central settings. Change values here instead of hunting through the code."""
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
BACKUP_DIR = os.path.join(BASE_DIR, "backups")
EXPORT_DIR = os.path.join(BASE_DIR, "exports")
DB_PATH = os.path.join(DATA_DIR, "inventory.db")

APP_NAME = "StockWise Inventory"
CURRENCY = "₹"                 # shown in the UI and reports
DEFAULT_TAX_PERCENT = 18.0     # default GST rate offered on the sales screen
LOW_STOCK_TARGET_FACTOR = 2    # suggested reorder = (factor x reorder level) - current stock

DEFAULT_ADMIN_USERNAME = "admin"
DEFAULT_ADMIN_PASSWORD = "Admin@123"   # change it from the sidebar after first login
PBKDF2_ITERATIONS = 200_000
MAX_LOGIN_ATTEMPTS = 5
LOCKOUT_SECONDS = 30

BUBBLE_SORT_LIMIT = 200        # bubble sort is O(n^2); the lab refuses larger inputs
