"""Entry point.   python main.py            -> start the app (loads demo data on the very first run)
                  python main.py --empty    -> start with an empty database
                  python main.py --check    -> no window: create the database and print a health summary"""
import argparse
import os
import sys

import config


def main():
    parser = argparse.ArgumentParser(description=config.APP_NAME)
    parser.add_argument("--db", default=config.DB_PATH, help="path of the SQLite database file")
    parser.add_argument("--empty", action="store_true", help="do not load demo data on first run")
    parser.add_argument("--check", action="store_true", help="run without a window and print a health summary")
    args = parser.parse_args()

    for folder in (config.DATA_DIR, config.BACKUP_DIR, config.EXPORT_DIR):
        os.makedirs(folder, exist_ok=True)

    from services.container import Services
    svc = Services(args.db)
    first_run = svc.db.scalar("SELECT COUNT(*) FROM products") == 0 and svc.db.scalar("SELECT COUNT(*) FROM categories") == 0
    if first_run and not args.empty:
        from sample_data import load_sample_data
        info = load_sample_data(svc, svc.db.scalar("SELECT id FROM users LIMIT 1"))
        print(f"First run: loaded demo data ({info['products']} products, {info['sales']} sales).")

    if args.check:
        stats = svc.reports.dashboard_stats()
        print("Database:", args.db)
        print("Dashboard figures:", stats)
        print("Stock consistent:", not svc.inventory.verify_consistency())
        svc.close()
        return 0

    try:
        import tkinter  # noqa: F401
    except ImportError:
        print("Tkinter is missing. Re-install Python from python.org and tick 'tcl/tk and IDLE'.")
        return 1
    from ui.app import App
    App(svc).mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
