"""Login, password hashing (PBKDF2-HMAC-SHA256 + random salt) and simple lock-out."""
import hashlib
import hmac
import os
import time

import config
import validators
from database import now_str
from errors import AuthError, ValidationError


def hash_password(password, iterations=None, salt=None):
    iterations = iterations or config.PBKDF2_ITERATIONS
    salt = salt or os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return f"pbkdf2_sha256${iterations}${salt.hex()}${digest.hex()}"


def verify_password(password, stored):
    try:
        scheme, iterations, salt_hex, digest_hex = stored.split("$")
        if scheme != "pbkdf2_sha256":
            return False
        candidate = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"),
                                        bytes.fromhex(salt_hex), int(iterations))
        return hmac.compare_digest(candidate.hex(), digest_hex)
    except (ValueError, TypeError):
        return False


class AuthService:
    def __init__(self, db):
        self.db = db
        self._failures = {}          # username -> (count, locked_until)
        self.ensure_default_admin()

    def ensure_default_admin(self):
        if self.db.scalar("SELECT COUNT(*) FROM users") == 0:
            self.db.execute(
                "INSERT INTO users (username, full_name, password_hash, created_at) VALUES (?,?,?,?)",
                (config.DEFAULT_ADMIN_USERNAME, "Administrator",
                 hash_password(config.DEFAULT_ADMIN_PASSWORD), now_str()))

    def login(self, username, password):
        username = (username or "").strip()
        if not username or not password:
            raise ValidationError("Enter both username and password.")
        key = username.lower()
        count, locked_until = self._failures.get(key, (0, 0))
        if locked_until > time.time():
            raise AuthError(f"Too many failed attempts. Try again in {int(locked_until - time.time()) + 1} seconds.")
        row = self.db.one("SELECT * FROM users WHERE username = ?", (username,))
        if row is None or not verify_password(password, row["password_hash"]):
            count += 1
            locked = time.time() + config.LOCKOUT_SECONDS if count >= config.MAX_LOGIN_ATTEMPTS else 0
            self._failures[key] = (0 if locked else count, locked)
            self.db.log(row["id"] if row else None, "LOGIN_FAILED", f"username={username}")
            raise AuthError("Incorrect username or password.")
        self._failures.pop(key, None)
        self.db.log(row["id"], "LOGIN", "")
        return {"id": row["id"], "username": row["username"], "full_name": row["full_name"]}

    def is_default_password(self, username):
        """True while the account still uses the shipped default password (login screen shows a hint)."""
        row = self.db.one("SELECT password_hash FROM users WHERE username = ?", (username,))
        return bool(row) and verify_password(config.DEFAULT_ADMIN_PASSWORD, row["password_hash"])

    def logout(self, user):
        self.db.log(user["id"], "LOGOUT", "")

    def change_password(self, user_id, old_password, new_password):
        row = self.db.one("SELECT password_hash FROM users WHERE id = ?", (user_id,))
        if row is None or not verify_password(old_password, row["password_hash"]):
            raise AuthError("Current password is incorrect.")
        validators.password(new_password)
        with self.db.transaction():
            self.db.execute("UPDATE users SET password_hash = ? WHERE id = ?",
                            (hash_password(new_password), user_id))
            self.db.log(user_id, "PASSWORD_CHANGED", "")
