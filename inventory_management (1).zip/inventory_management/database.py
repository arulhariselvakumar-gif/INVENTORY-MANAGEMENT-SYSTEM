"""SQLite access layer: schema, connection helper and an all-or-nothing transaction()."""
import sqlite3
import os
from contextlib import contextmanager
from datetime import datetime

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT NOT NULL UNIQUE COLLATE NOCASE,
    full_name     TEXT NOT NULL DEFAULT '',
    password_hash TEXT NOT NULL,
    created_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS categories (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE COLLATE NOCASE,
    description TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS suppliers (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL,
    company    TEXT NOT NULL UNIQUE COLLATE NOCASE,
    phone      TEXT NOT NULL DEFAULT '',
    email      TEXT NOT NULL DEFAULT '',
    address    TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS products (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    product_code  TEXT NOT NULL UNIQUE,
    sku           TEXT NOT NULL UNIQUE COLLATE NOCASE,
    name          TEXT NOT NULL,
    description   TEXT NOT NULL DEFAULT '',
    category_id   INTEGER NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
    supplier_id   INTEGER REFERENCES suppliers(id) ON DELETE SET NULL,
    cost_price    REAL NOT NULL CHECK (cost_price >= 0),
    selling_price REAL NOT NULL CHECK (selling_price >= 0),
    quantity      INTEGER NOT NULL DEFAULT 0 CHECK (quantity >= 0),
    reorder_level INTEGER NOT NULL DEFAULT 0 CHECK (reorder_level >= 0),
    is_active     INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
    date_added    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_products_name     ON products(name);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_supplier ON products(supplier_id);

CREATE TABLE IF NOT EXISTS purchases (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    purchase_no   TEXT NOT NULL UNIQUE,
    supplier_id   INTEGER NOT NULL REFERENCES suppliers(id) ON DELETE RESTRICT,
    purchase_date TEXT NOT NULL,
    status        TEXT NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT','CONFIRMED','CANCELLED')),
    total_cost    REAL NOT NULL DEFAULT 0 CHECK (total_cost >= 0),
    notes         TEXT NOT NULL DEFAULT '',
    request_token TEXT UNIQUE,
    created_by    INTEGER REFERENCES users(id),
    created_at    TEXT NOT NULL,
    confirmed_at  TEXT
);
CREATE INDEX IF NOT EXISTS idx_purchases_date ON purchases(purchase_date);

CREATE TABLE IF NOT EXISTS purchase_items (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    purchase_id INTEGER NOT NULL REFERENCES purchases(id) ON DELETE CASCADE,
    product_id  INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
    quantity    INTEGER NOT NULL CHECK (quantity > 0),
    unit_cost   REAL NOT NULL CHECK (unit_cost >= 0),
    line_total  REAL NOT NULL CHECK (line_total >= 0)
);
CREATE INDEX IF NOT EXISTS idx_purchase_items_purchase ON purchase_items(purchase_id);

CREATE TABLE IF NOT EXISTS sales (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_no       TEXT NOT NULL UNIQUE,
    customer_name    TEXT NOT NULL DEFAULT 'Walk-in customer',
    sale_date        TEXT NOT NULL,
    subtotal         REAL NOT NULL CHECK (subtotal >= 0),
    discount_percent REAL NOT NULL DEFAULT 0 CHECK (discount_percent BETWEEN 0 AND 100),
    discount_amount  REAL NOT NULL DEFAULT 0 CHECK (discount_amount >= 0),
    tax_percent      REAL NOT NULL DEFAULT 0 CHECK (tax_percent BETWEEN 0 AND 100),
    tax_amount       REAL NOT NULL DEFAULT 0 CHECK (tax_amount >= 0),
    total            REAL NOT NULL CHECK (total >= 0),
    status           TEXT NOT NULL DEFAULT 'COMPLETED'
                     CHECK (status IN ('COMPLETED','PARTIAL_RETURN','RETURNED','CANCELLED')),
    request_token    TEXT UNIQUE,
    created_by       INTEGER REFERENCES users(id),
    created_at       TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sales_date ON sales(sale_date);

CREATE TABLE IF NOT EXISTS sale_items (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    sale_id      INTEGER NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
    product_id   INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
    quantity     INTEGER NOT NULL CHECK (quantity > 0),
    unit_price   REAL NOT NULL CHECK (unit_price >= 0),
    unit_cost    REAL NOT NULL CHECK (unit_cost >= 0),
    line_total   REAL NOT NULL CHECK (line_total >= 0),
    returned_qty INTEGER NOT NULL DEFAULT 0,
    CHECK (returned_qty >= 0 AND returned_qty <= quantity)
);
CREATE INDEX IF NOT EXISTS idx_sale_items_sale ON sale_items(sale_id);

CREATE TABLE IF NOT EXISTS sale_returns (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    sale_id       INTEGER NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
    sale_item_id  INTEGER NOT NULL REFERENCES sale_items(id) ON DELETE CASCADE,
    quantity      INTEGER NOT NULL CHECK (quantity > 0),
    refund_amount REAL NOT NULL CHECK (refund_amount >= 0),
    reason        TEXT NOT NULL,
    performed_by  INTEGER REFERENCES users(id),
    created_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS stock_adjustments (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id   INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    old_quantity INTEGER NOT NULL CHECK (old_quantity >= 0),
    new_quantity INTEGER NOT NULL CHECK (new_quantity >= 0),
    reason       TEXT NOT NULL,
    performed_by INTEGER REFERENCES users(id),
    created_at   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS stock_movements (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id     INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    movement_type  TEXT NOT NULL
                   CHECK (movement_type IN ('OPENING','PURCHASE','SALE','RETURN','ADJUSTMENT')),
    quantity_change INTEGER NOT NULL CHECK (quantity_change <> 0),
    quantity_after INTEGER NOT NULL CHECK (quantity_after >= 0),
    reference_type TEXT NOT NULL DEFAULT '',
    reference_id   INTEGER,
    reason         TEXT NOT NULL DEFAULT '',
    performed_by   INTEGER REFERENCES users(id),
    created_at     TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_movements_product ON stock_movements(product_id, id);

CREATE TABLE IF NOT EXISTS restock_tasks (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id    INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    suggested_qty INTEGER NOT NULL CHECK (suggested_qty > 0),
    status        TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','DONE')),
    created_at    TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_restock_pending
    ON restock_tasks(product_id) WHERE status = 'PENDING';

CREATE TABLE IF NOT EXISTS activity_logs (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER REFERENCES users(id) ON DELETE SET NULL,
    action     TEXT NOT NULL,
    details    TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);
"""

TABLES = ["users", "categories", "suppliers", "products", "purchases", "purchase_items",
          "sales", "sale_items", "sale_returns", "stock_adjustments", "stock_movements",
          "restock_tasks", "activity_logs"]


def now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def today_str():
    return datetime.now().strftime("%Y-%m-%d")


class Database:
    """One connection, autocommit mode; transaction() issues BEGIN/COMMIT/ROLLBACK itself."""

    def __init__(self, path):
        self.path = path
        folder = os.path.dirname(os.path.abspath(path))
        os.makedirs(folder, exist_ok=True)
        self.conn = sqlite3.connect(path, isolation_level=None)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        self.conn.execute("PRAGMA journal_mode = DELETE")
        self._depth = 0
        self.init_schema()

    def init_schema(self):
        self.conn.executescript(SCHEMA)
        self.conn.execute("PRAGMA foreign_keys = ON")

    @contextmanager
    def transaction(self):
        """All statements inside succeed together or are rolled back together.
        Nested calls simply join the outer transaction."""
        if self._depth > 0:
            self._depth += 1
            try:
                yield self.conn
            finally:
                self._depth -= 1
            return
        self.conn.execute("BEGIN IMMEDIATE")
        self._depth = 1
        try:
            yield self.conn
            self.conn.execute("COMMIT")
        except BaseException:
            self.conn.execute("ROLLBACK")
            raise
        finally:
            self._depth = 0

    def query(self, sql, params=()):
        return self.conn.execute(sql, params).fetchall()

    def one(self, sql, params=()):
        return self.conn.execute(sql, params).fetchone()

    def scalar(self, sql, params=(), default=0):
        row = self.conn.execute(sql, params).fetchone()
        return default if row is None or row[0] is None else row[0]

    def execute(self, sql, params=()):
        return self.conn.execute(sql, params)

    def log(self, user_id, action, details=""):
        """Write an audit entry. Joins the current transaction if one is open."""
        self.conn.execute(
            "INSERT INTO activity_logs (user_id, action, details, created_at) VALUES (?,?,?,?)",
            (user_id, action, details, now_str()))

    def close(self):
        self.conn.close()
