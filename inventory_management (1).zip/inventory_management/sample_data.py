"""Loads realistic demo data THROUGH the services, so stock, movements and invoices stay consistent."""
from datetime import date, timedelta

CATEGORIES = [("Mobile accessories", "Chargers, cables, cases"), ("Computer peripherals", "Keyboards, mice, storage"),
              ("Audio", "Headphones and speakers"), ("Stationery", "Office paper and writing"),
              ("Networking", "Routers and cables"), ("Power", "Batteries and power strips")]
SUPPLIERS = [("Ravi Kumar", "Sri Balaji Traders", "9840011122", "ravi@balajitraders.example", "T. Nagar, Chennai"),
             ("Meena Iyer", "Digital Hub Wholesale", "9841022233", "meena@digitalhub.example", "Ritchie Street, Chennai"),
             ("Arun Prakash", "Coimbatore Office Supplies", "9842033344", "arun@cos.example", "RS Puram, Coimbatore"),
             ("Farah Khan", "SoundWave Distributors", "9843044455", "farah@soundwave.example", "Anna Salai, Chennai")]
# sku, name, category, supplier index, cost, price, opening qty, reorder level
PRODUCTS = [
    ("MA-USBC-1M", "USB-C cable 1 m", 0, 0, 90, 199, 120, 30), ("MA-CHG-20W", "20W fast charger", 0, 0, 450, 799, 45, 15),
    ("MA-CASE-S23", "Phone case (clear)", 0, 0, 60, 249, 8, 20), ("MA-PBK-10K", "Power bank 10000 mAh", 0, 1, 780, 1299, 22, 10),
    ("CP-KB-WL", "Wireless keyboard", 1, 1, 650, 1099, 18, 8), ("CP-MS-OPT", "Optical mouse", 1, 1, 180, 399, 60, 20),
    ("CP-SSD-512", "512 GB portable SSD", 1, 1, 3600, 4999, 9, 5), ("CP-PEN-64", "64 GB pen drive", 1, 0, 380, 649, 35, 12),
    ("AU-HP-BT", "Bluetooth headphones", 2, 3, 1100, 1999, 14, 8), ("AU-SPK-MINI", "Mini speaker", 2, 3, 700, 1299, 6, 6),
    ("AU-EAR-WD", "Wired earphones", 2, 3, 120, 299, 75, 25), ("ST-A4-500", "A4 paper ream (500)", 3, 2, 210, 320, 150, 40),
    ("ST-PEN-BL", "Ball pen blue (box of 10)", 3, 2, 45, 90, 200, 50), ("ST-NB-200", "Notebook 200 pages", 3, 2, 38, 85, 5, 30),
    ("ST-STP-01", "Stapler with pins", 3, 2, 65, 140, 40, 10), ("NW-RT-AC12", "Wi-Fi router AC1200", 4, 1, 1250, 1899, 12, 6),
    ("NW-CAT6-5M", "Cat6 cable 5 m", 4, 1, 110, 249, 55, 15), ("PW-AA-8", "AA batteries (pack of 8)", 5, 0, 130, 240, 90, 30),
    ("PW-STRIP-4", "4-socket power strip", 5, 2, 280, 499, 3, 10), ("PW-UPS-600", "600 VA mini UPS", 5, 1, 2400, 3499, 6, 4)]


def load_sample_data(svc, user_id=1):
    cats = [svc.categories.add(n, d, user_id) for n, d in CATEGORIES]
    sups = [svc.suppliers.add({"name": n, "company": c, "phone": p, "email": e, "address": a}, user_id)
            for n, c, p, e, a in SUPPLIERS]
    ids = {}
    for sku, name, cat, sup, cost, price, qty, rl in PRODUCTS:
        ids[sku] = svc.products.add({"sku": sku, "name": name, "category_id": cats[cat], "supplier_id": sups[sup],
                                     "cost_price": cost, "selling_price": price, "quantity": qty,
                                     "reorder_level": rl, "description": ""}, user_id)
    today = date.today()
    day = lambda n: (today - timedelta(days=n)).isoformat()
    # two confirmed purchases and one draft that is still waiting
    svc.purchases.create(sups[0], day(25), [(ids["MA-USBC-1M"], 60, 88), (ids["MA-CHG-20W"], 20, 445)],
                         "Monthly top-up", user_id, confirm=True)
    svc.purchases.create(sups[1], day(14), [(ids["CP-MS-OPT"], 40, 175), (ids["NW-RT-AC12"], 6, 1240)],
                         "", user_id, confirm=True)
    svc.purchases.create(sups[2], day(1), [(ids["ST-NB-200"], 120, 37), (ids["PW-STRIP-4"], 15, 275)],
                         "Awaiting delivery - confirm on arrival", user_id)
    sales = [(24, [("MA-USBC-1M", 15), ("MA-CHG-20W", 6)], "Anand Stores", 0), (21, [("ST-A4-500", 20), ("ST-PEN-BL", 30)], "Kavya Offices", 5),
             (18, [("CP-KB-WL", 3), ("CP-MS-OPT", 6)], "Walk-in customer", 0), (15, [("AU-HP-BT", 4), ("AU-EAR-WD", 12)], "Suresh", 0),
             (12, [("PW-AA-8", 20), ("ST-STP-01", 5)], "Walk-in customer", 0), (9, [("CP-SSD-512", 2), ("CP-PEN-64", 5)], "Digital Zone", 3),
             (7, [("MA-CASE-S23", 6), ("MA-USBC-1M", 10)], "Walk-in customer", 0), (5, [("NW-RT-AC12", 3), ("NW-CAT6-5M", 8)], "Net Solutions", 0),
             (3, [("AU-SPK-MINI", 6), ("AU-HP-BT", 2)], "Priya", 10), (2, [("MA-PBK-10K", 5), ("PW-STRIP-4", 2)], "Walk-in customer", 0),
             (1, [("ST-NB-200", 4), ("CP-MS-OPT", 10)], "Kavya Offices", 0)]
    sale_ids = [svc.sales.create([(ids[s], q) for s, q in items], cust, disc, 18, user_id, sale_date=day(d))
                for d, items, cust, disc in sales]
    # one partial return and one cancellation to show the return workflow
    first = svc.sales.get(sale_ids[3])["items"][0]
    svc.sales.return_items(sale_ids[3], {first["id"]: 1}, "Headphones faulty", user_id)
    svc.sales.cancel(sale_ids[6], "Customer changed mind", user_id)
    svc.inventory.queue_restock(ids["ST-NB-200"], user_id)
    return {"products": len(PRODUCTS), "sales": len(sale_ids)}
