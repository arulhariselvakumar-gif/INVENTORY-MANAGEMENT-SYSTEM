# Inventory Management System Using Data Structures and Algorithms

*B.Tech Artificial Intelligence and Data Science - DSA Major Project (Project-2)*
*Student name / register number / guide / date: ______ (fill in)*

## 1. Project Title
Inventory Management System Using Data Structures and Algorithms (application name: StockWise Inventory).

## 2. Abstract
Small shops often track stock in notebooks or spreadsheets, which leads to wrong quantities, missed reorders and unreliable profit figures. This project presents StockWise Inventory, an offline desktop application built with Python, Tkinter, SQLite and Matplotlib. It manages products, categories, suppliers, purchases, multi-item sales with invoices, returns, stock adjustments, low-stock alerts, reports with charts, CSV import and export, and database backup and restore. Every stock change passes through one function that also writes an auditable stock movement, and purchases, sales and returns run inside database transactions so a failure never leaves half-saved data. The academic focus is the practical use of data structures and algorithms written from scratch: a hash table for SKU lookup, a binary search tree for name-prefix search, a linked list for stock history, a queue for restock tasks, a stack for undo, linear and binary search, and bubble and merge sort. Each is connected to a real feature and none is claimed where it is not used. The system was verified with 69 automated tests that use a temporary database, covering validation, transactions, rollback, duplicate prevention, reports, backup and persistence; all passed in the final run. The result is a consistent, testable and beginner-readable system that demonstrates how classical data structures solve everyday business problems.

## 3. Introduction
Inventory control answers three questions: what is in stock, what moved, and what must be ordered. Errors in any of them cost money through lost sales or money tied up in unsold goods. Computers help only if the numbers are consistent, so the design of this project puts consistency first: one place changes stock, one audit table records why, and the database enforces rules that code could forget. The project also serves as a laboratory for the DSA course: the Search and sort lab runs the course algorithms on the shop's own data and shows how much work each performs.

## 4. Problem Statement
Design and build a working desktop application that lets a small business manage products, suppliers, purchases and sales, keeps stock correct under all operations (including failures, returns and double submissions), warns when items run low, produces honest reports, and demonstrates the use of fundamental data structures and algorithms in meaningful places.

## 5. Objectives
1. Maintain accurate stock that can never become negative and can always be explained by its movement history.
2. Record purchases and multi-item sales with correct totals, discounts, tax and unique invoice numbers.
3. Support returns and cancellations that restore stock correctly.
4. Alert the user to low and out-of-stock products and suggest order quantities.
5. Provide reports (stock, valuation, sales, purchases, best sellers, supplier summary, estimated profit) with CSV export and charts.
6. Implement and integrate stack, queue, linked list, hash table, BST, linear and binary search, bubble and merge sort.
7. Protect data: hashed passwords, validation, parameterised SQL, transactions, backup and restore.
8. Provide a clear, modern interface with confirmations and meaningful messages.

## 6. Scope of the Project
In scope: a single-computer, single-window desktop application for one shop; one administrator account; one tax percentage per invoice; rupee currency symbol (configurable); offline operation.
Out of scope: multi-user networking, barcode hardware, printing, accounting ledgers, multi-warehouse stock, batch/expiry tracking, online payments.

## 7. Existing System
Typically a paper register or a spreadsheet. Weaknesses: manual arithmetic errors, no audit trail (a changed cell leaves no trace), no protection against selling more than is in stock, no alerts, profit confused with sales revenue, and a single damaged file can lose everything.

## 8. Proposed System
A layered desktop application. The interface calls services; services validate, run SQL inside transactions and use the `dsa` package; SQLite stores everything in one file that can be backed up safely. Rules are enforced twice, in code (friendly messages) and in the database (CHECK, UNIQUE and FOREIGN KEY constraints).

## 9. Data Structures Used
| Structure | Used for |
|---|---|
| List (array) | Product collections, cart lines, report rows |
| Hash table (separate chaining) | Exact SKU / ID lookup (`ProductIndex`, sales SKU box) |
| Linked list | Stock history of a product, newest first |
| Queue (circular array) | FIFO restock tasks |
| Stack | Undo of stock adjustments and product edits |
| Binary search tree (built balanced) | Name-prefix search and sorted name index |

SQLite's own B-tree indexes serve stored lookups and are separate from these teaching structures.

## 10. Algorithms Used
Linear search (unsorted data), binary search (data merge-sorted by the searched field), bubble sort (small-data demonstration, limited to 200 products), merge sort (default for sorting and for table headings), BST prefix search, hash-based lookup, PBKDF2 password hashing, exact decimal money arithmetic. Details, pseudocode and complexity are in section 19 and `docs/algorithms.md`.

## 11. Programming Language
Python 3.10+ (developed and tested on Python 3.12). Chosen for readability, the built-in `sqlite3` and `tkinter` modules, and a large standard library.

## 12. Software Requirements
Windows 10/11; Python 3.10 or newer with tcl/tk; Matplotlib 3.7 or newer (`pip install -r requirements.txt`); Visual Studio Code. No internet connection, paid service or external API is needed at run time.

## 13. Hardware Requirements
Any PC that runs Windows 10/11: 2 GB RAM (4 GB recommended), 300 MB free disk space, display of at least 1280 x 720 pixels.

## 14. Functional Requirements
FR1 Administrator login/logout with hashed passwords and change-password. FR2 Product add, view, edit, delete/archive, unique product code and SKU, search and filters. FR3 Category add, edit, delete (with reassignment). FR4 Supplier add, view, update, search, delete when unused. FR5 Stock adjustment with reason; movement history; consistency check. FR6 Purchase drafts, multi-item purchases, confirmation that adds stock once, cancellation of drafts. FR7 Multi-item sales with discount, tax, stock check and invoice number; invoice view and text export. FR8 Returns (partial) and cancellation restoring stock. FR9 Low-stock and out-of-stock alerts with suggested quantities, filters, CSV export and a restock queue. FR10 Search and sort lab (linear, binary, hash, BST, bubble, merge). FR11 Reports and charts with CSV export. FR12 Product CSV import and export. FR13 Backup and restore. FR14 Undo of the last stock adjustment or product edit.

## 15. Non-Functional Requirements
Correctness (stock never negative, movements sum to quantity); atomicity (all-or-nothing transactions); security (salted PBKDF2 hashes, parameterised SQL, lock-out after five failures); usability (confirmations, plain-language errors, sortable tables, toasts); portability (single database file, no installation beyond Python); maintainability (layered folders, no circular imports, `dsa` independent); testability (temporary test database, 69 tests); performance (indexed queries; interactive for thousands of products).

## 16. Modules
Authentication (`auth.py`); Database (`database.py`); Product, Category and Supplier management (`product_service.py`, `master_service.py`); Inventory/stock (`inventory_service.py`); Purchases (`purchase_service.py`); Sales and returns (`sales_service.py`); Reports and charts (`report_service.py`, `charts.py`); CSV (`csv_service.py`); Backup (`backup_service.py`); Undo (`undo_service.py`); DSA package (`dsa/`); User interface (`ui/`: window, login, dashboard, products, masters, purchases, sales, stock and low stock, search lab, reports, backup).

## 17. System Architecture
```mermaid
flowchart TB
    UI[ui/ - Tkinter screens] --> SV[services/ - rules, transactions, reports]
    SV --> DB[(SQLite database file)]
    SV --> DS[dsa/ - stack, queue, linked list, hash table, BST, searches, sorts]
    SV --> MP[Matplotlib figures]
    SV --> CSV[CSV files]
    SV --> BK[Backup files]
```
Rule: the UI never contains SQL; services never import the UI; `dsa` imports nothing from the application. See `docs/architecture.md`.

## 18. Flowchart
```mermaid
flowchart TD
    S([Start]) --> L[Login]
    L -->|fail| L
    L --> M[Dashboard / sidebar menu]
    M --> P[Products, categories, suppliers]
    M --> PU[Purchase: draft, then receive]
    M --> SA[Sale: cart, totals, complete]
    M --> ST[Stock control and undo]
    M --> LS[Low-stock alerts and restock queue]
    M --> SE[Search and sort lab]
    M --> RE[Reports, charts, CSV]
    M --> BA[Backup and restore]
    PU --> T{Transaction OK?}
    SA --> T
    T -->|yes| C[Commit + stock movements]
    T -->|no| R[Rollback, show message]
    M --> O([Sign out])
```
The sale and purchase flowcharts in `docs/architecture.md` give the detailed steps.

## 19. Algorithm / Pseudocode
```
apply_stock_change(product, delta):            # inside a transaction
    new = product.quantity + delta
    if new < 0: raise InsufficientStock
    product.quantity = new
    insert stock_movement(product, delta, new, reason, user, time)

confirm_purchase(id):
    BEGIN
    UPDATE purchases SET status='CONFIRMED' WHERE id=id AND status='DRAFT'
    if no row changed: raise AlreadyProcessed
    for each item: apply_stock_change(item.product, +item.quantity)
    COMMIT   (any error -> ROLLBACK)

create_sale(items, discount%, tax%, token):
    BEGIN
    if token already used: raise Duplicate
    subtotal = sum(price x qty); discount = subtotal x d%; tax = (subtotal - discount) x t%
    insert sale, insert lines (price and cost copied), for each line: apply_stock_change(-qty)
    COMMIT   (not enough stock on any line -> ROLLBACK everything)

binary_search(a, target):  lo=0; hi=n-1
    while lo <= hi: mid=(lo+hi)//2; if a[mid]==target return mid; if a[mid]<target lo=mid+1 else hi=mid-1
    return -1
merge_sort(a): if len(a)<=1 return a; return merge(merge_sort(left), merge_sort(right))
bubble_sort(a): repeat: swap out-of-order neighbours; stop when a pass makes no swap
suggested_order(qty, reorder) = max(2 x reorder, 1) - qty, at least 1
```
Full pseudocode for every structure is in `docs/algorithms.md`.

## 20. Database / File Structure
Thirteen tables: users, categories, suppliers, products, purchases, purchase_items, sales, sale_items, sale_returns, stock_adjustments, stock_movements, restock_tasks, activity_logs. Primary keys are integer identities; foreign keys are enforced (`PRAGMA foreign_keys=ON`); CHECK constraints guard quantities, prices, percentages and statuses; UNIQUE constraints guard SKU, invoice number, purchase number, category name, supplier company and request tokens. ER diagram and the purpose of each table: `docs/architecture.md`.
Files: `data/inventory.db` (database), `backups/*.db`, `exports/*.csv`, `data/app.log` (unexpected errors only).

## 21. Implementation Details
Size: about 4,500 lines of application code (dsa 420, services 1,300, ui 2,200, core 530) and 760 lines of tests.
* **One door for stock.** `apply_stock_change` is the only code that updates `products.quantity`; it refuses negative results and writes a movement.
* **Transactions.** `Database.transaction()` wraps BEGIN IMMEDIATE / COMMIT / ROLLBACK and nests.
* **Duplicate protection.** Purchase confirmation flips status with a conditional UPDATE; sale and purchase forms carry a random token stored in a UNIQUE column.
* **Money.** Totals use `Decimal` with half-up rounding to avoid floating-point drift.
* **Profit.** Revenue = (quantity - returned) x price x (1 - discount share); cost uses the cost price copied onto the sale line; tax is excluded. It is gross profit.
* **Passwords.** PBKDF2-HMAC-SHA256, random salt, 200,000 iterations, constant-time comparison, 30-second lock after five failures.
* **Interface.** Custom flat buttons with colour fade, click-to-sort tables that use our own merge sort, slide-in page changes, toast messages, count-up dashboard numbers. All handlers are wrapped so errors become dialogs instead of crashes.
* **Backup.** SQLite online backup API; restore verifies integrity and expected tables, saves a safety copy, replaces data, signs the user out.

## 22. Complexity Analysis
| Operation | Best | Average | Worst | Space |
|---|---|---|---|---|
| Stack push/pop | O(1) | O(1) | O(1) | O(n) |
| Queue enqueue/dequeue | O(1) | O(1) | O(n) on resize (amortised O(1)) | O(n) |
| Linked list prepend | O(1) | O(1) | O(1) | O(n) |
| Linked list find/remove | O(1) | O(n) | O(n) | O(1) |
| Hash table get/put | O(1) | O(1) | O(n) | O(n) |
| BST search (balanced) | O(log n) | O(log n) | O(n) if unbalanced | O(n) |
| BST prefix search | O(h) | O(h+k) | O(n) | O(h) |
| Linear search | O(1) | O(n) | O(n) | O(1) |
| Binary search | O(1) | O(log n) | O(log n) | O(1) |
| Bubble sort | O(n) | O(n^2) | O(n^2) | O(1) |
| Merge sort | O(n log n) | O(n log n) | O(n log n) | O(n) |
Measured behaviour: searching a SKU among 65 products needs at most 7 comparisons by binary search against up to 65 by linear search (test `test_binary_is_cheaper_than_linear`); a balanced BST of 127 keys has height 7 while the same keys inserted in sorted order give height 127.

## 23. Test Cases
Result of the final run: **69 tests, 0 failures, 0 errors** (Python 3.12, temporary databases). Selected cases (the complete table with 44 scenarios, inputs, expected results and statuses generated from the run is `docs/test_cases.md`):

| Area | Input | Expected | Actual / status |
|---|---|---|---|
| Login | Wrong password; five wrong then right | Rejected; locked | Passed |
| Duplicate SKU | `DUP-1` then `dup-1` | Second rejected, nothing half-saved | Passed |
| Sale | 2x100 + 1x50, 10% off, 18% tax | Total 265.50, stock reduced | Passed |
| Insufficient stock | Line 1 fine, line 2 asks 5 of 2 | Whole sale rejected, no stock change | Passed |
| Duplicate submit | Same form token twice | Second refused | Passed |
| Purchase | Confirm twice | Stock added once | Passed |
| Rollback | Injected database error mid-sale / mid-confirm | Nothing saved | Passed |
| Return / cancel | Sell 4, return 1, cancel | Refund 106.20; stock restored | Passed |
| Profit | Sell 5 at 100, cost 60, 10% off | Profit 150 (tax excluded) | Passed |
| Backup | Backup, change, restore | Original data back | Passed |
| Persistence | Sell, close, reopen | Data still there | Passed |
| Algorithms | Random data vs Python `sorted()` | Identical, stable | Passed |
**Not machine-tested:** the look and feel of the Tkinter screens. Their code paths were exercised by a script against the real services using a stand-in for Tkinter (84 checks passed), but visual layout must be confirmed by running the application.

## 24. Output Screenshots
Insert the screenshots you take from the running application (checklist and file names in `docs/VIVA_AND_DEMO.md`). No screenshot is supplied or invented here.
* Figure 1: Login screen - *[insert 01_login.png]*
* Figure 2: Dashboard - *[insert 03_dashboard.png]*
* Figure 3: Products table - *[insert 04_products.png]*
* Figure 4: Add product dialog - *[insert 05_add_product.png]*
* Figure 5: Purchase entry - *[insert 09_purchase_draft.png]*
* Figure 6: Sale cart and totals - *[insert 11_sale_cart.png]*
* Figure 7: Invoice - *[insert 12_invoice.png]*
* Figure 8: Stock control and history - *[insert 15_stock_control.png]*
* Figure 9: Low-stock alerts with restock queue - *[insert 16_low_stock_queue.png]*
* Figure 10: Search and sort lab - *[insert 17_search_binary.png, 18_sort_merge.png]*
* Figure 11: Estimated profit report - *[insert 19_report_profit.png]*
* Figure 12: Charts - *[insert 20_charts.png]*
* Figure 13: Backup and restore - *[insert 21_backup.png]*
* Figure 14: Test run output - *[insert 22_tests.png]*

## 25. Advantages
Stock is always explainable by its history; failures leave no partial data; double clicks cannot duplicate transactions; works offline on a basic PC; data structures are real and measurable in the lab; reports separate revenue from profit; one-file database is easy to back up; code is layered and readable for students.

## 26. Limitations
One computer and one user at a time; one administrator role; one tax percentage per invoice; no barcode scanner or printer integration; profit is gross and uses the product's recorded cost price rather than FIFO or average costing; purchase drafts cannot be edited (cancel and recreate); bubble sort is limited to 200 products by design; screens were not visually verified by automated tools.

## 27. Future Scope
Multiple users with roles and permissions; barcode scanning and label printing; PDF invoices; batch and expiry tracking; average or FIFO costing; multi-warehouse stock and transfers; a network or web version with a client-server database; e-mail alerts to suppliers; demand forecasting from sales history; balancing the BST automatically (AVL or red-black).

## 28. Conclusion
StockWise Inventory meets the stated objectives: it manages the full purchase-stock-sale cycle with correct, auditable numbers; it protects data through validation, constraints, transactions and backups; and it uses each required data structure and algorithm in a place where it has a real job, with measurements the user can see. The automated tests give confidence in the logic, and the report is honest about what remains to be checked by eye and what the system does not do. The design is a sound base for the extensions listed above.
