# Demonstration script, screenshot checklist and viva questions

## A. Demonstration script (about 10 minutes)

Start with `python main.py` (demo data loads on the first run). Sign in as **admin / Admin@123**.

1. **Dashboard (1 min).** Point at the cards: products, units, stock value, low-stock count. Say: "These come from SQL queries on the live database. Click the low-stock card."
2. **Low-stock alerts (1 min).** Show LOW and OUT rows and the suggested order size. Select *Mini speaker*, click **Add to restock queue**. Say: "This is a Queue: first in, first out."
3. **Process the queue (1 min).** Click **Process next**. The Purchases page opens with the product, supplier and quantity filled in. Click **Add line**, then **Save and receive stock**. Open **Products** and show the quantity went up.
4. **Stock history (1 min).** Products > select the item > **Stock history**. Say: "This list is a linked list, newest first."
5. **Sale (2 min).** Sales page: type `MA-USBC-1M`, Enter (hash table lookup), quantity 2, **Add to cart**; type `Wire` (BST prefix) and add one; set discount 5. Show totals; **Complete sale**; the invoice opens. Try to add more units than are in stock to show the stock check.
6. **Return (1 min).** Select the sale, **Return items**, return 1 unit with a reason. Show status "Partly returned" and that stock went back up.
7. **Search and sort lab (1.5 min).** Run SKU search with Linear, Binary and Hash and compare the comparison counts. Run name sort with Bubble and Merge. Say the complexity shown.
8. **Stock control + undo (1 min).** Adjust a product's stock with a reason; click **Undo** (stack).
9. **Reports (1 min).** *Estimated profit* report: read the assumptions line aloud ("revenue is not profit"). Open the Charts tab. Export CSV.
10. **Backup (30 s).** **Back up now**; mention restore makes a safety copy first.

Failure demos worth showing: wrong password (card shakes), duplicate SKU, selling more than stock, double-clicking *Complete sale* (second click is refused as a duplicate).

## B. Screenshot checklist (take them yourself from the running app; none are supplied)

Use Windows `Win + Shift + S`, save as PNG into a `screenshots` folder, and name them as below so they match the report's section 24.

| # | File name | What to capture |
|---|---|---|
| 1 | 01_login.png | Login screen |
| 2 | 02_login_error.png | Wrong password message |
| 3 | 03_dashboard.png | Dashboard with cards and tables |
| 4 | 04_products.png | Product table with a low and an out-of-stock row |
| 5 | 05_add_product.png | Add product dialog with margin text visible |
| 6 | 06_duplicate_sku.png | Duplicate SKU warning |
| 7 | 07_categories.png | Categories page |
| 8 | 08_suppliers.png | Suppliers page |
| 9 | 09_purchase_draft.png | Purchase with two lines before saving |
| 10 | 10_purchase_list.png | Purchase records showing Draft and Confirmed |
| 11 | 11_sale_cart.png | Sale cart with totals |
| 12 | 12_invoice.png | Invoice window |
| 13 | 13_stock_error.png | "Only N in stock" warning |
| 14 | 14_return.png | Return items dialog |
| 15 | 15_stock_control.png | Stock control with history tab |
| 16 | 16_low_stock_queue.png | Low-stock page with restock queue |
| 17 | 17_search_binary.png | Search lab, binary search result with comparisons |
| 18 | 18_sort_merge.png | Search lab, merge sort result |
| 19 | 19_report_profit.png | Estimated profit report with assumptions |
| 20 | 20_charts.png | Charts tab |
| 21 | 21_backup.png | Backup and restore page |
| 22 | 22_tests.png | Terminal showing `python -m unittest discover -v` finishing with OK |

## C. Viva questions and simple answers

**General**
1. *What problem does the project solve?* A small shop needs to know what it has, what it sold and what to reorder. The app keeps stock, purchases, sales and alerts consistent.
2. *Why Python, Tkinter and SQLite?* Python is quick to write; Tkinter ships with Python so there is nothing to install; SQLite is a file database that needs no server and works offline.
3. *Why separate `ui`, `services`, `dsa`?* Each layer has one job. The UI shows things, services hold business rules and SQL, `dsa` holds the course structures and imports nothing else, so each part can be tested alone.
4. *How is the password stored?* Never as text. PBKDF2-HMAC-SHA256 with a random 16-byte salt and 200,000 rounds; login compares with `hmac.compare_digest`. Five wrong tries lock the account for 30 seconds.
5. *What stops SQL injection?* Every query uses `?` placeholders (parameterised queries); user text is never glued into SQL.

**Data structures**
6. *Where is a stack used?* Undo of the last stock adjustment or product edit. The newest action is undone first (LIFO).
7. *Where is a queue used?* The restock queue. First product queued is processed first (FIFO). It is a circular array that doubles when full.
8. *Where is a linked list used?* A product's stock history. Rows are prepended so the head is the newest; walking the list gives newest-first without sorting.
9. *Why a hash table for SKU lookup?* It jumps to a bucket using the hash of the key: O(1) on average, versus O(n) for scanning.
10. *What is a collision and how do you handle it?* Two keys landing in the same bucket. We use chaining: each bucket holds a small list; a test forces every key into one bucket and all are still found.
11. *Why is the BST built balanced?* Inserting sorted names one by one makes a stick of height n (O(n) search). Inserting the middle first keeps height near log n. A test shows height 7 vs 127 for 127 keys.
12. *Why not use the BST for everything?* It is only useful for sorted and prefix queries on names. Exact SKU lookup is faster with the hash table, and persistent lookups use SQLite's own indexes.
13. *Is the hash table the same as the database index?* No. SQLite has its own B-tree indexes for the stored data. Our hash table and BST are in-memory teaching structures built from a snapshot.

**Algorithms**
14. *Linear vs binary search?* Linear checks every item, works on unsorted data, O(n). Binary halves a sorted range each step, O(log n), but needs data sorted by the same key.
15. *Why must data be sorted for binary search?* Because after comparing with the middle we discard half the data; that is only valid if everything on one side is smaller.
16. *Best, average and worst case of bubble sort?* O(n) when already sorted (we stop early), O(n^2) average and worst. That is why the lab limits it to 200 products.
17. *Why is merge sort used for real work?* It is O(n log n) in every case and stable. The price is O(n) extra memory.
18. *What does "stable" mean?* Equal items keep their original order. Tests prove both our sorts are stable.
19. *How do you know your sorts are correct?* Tests compare them with Python's `sorted()` on random data of many sizes, ascending and descending, including empty and one-item lists.
20. *Complexity of a prefix search in the BST?* O(h + k): h tree height, k matches. Branches that cannot match are skipped.

**Database and transactions**
21. *What is a transaction? Where do you use one?* A group of statements that all succeed or all fail. A sale inserts the invoice, its lines and reduces stock; if one product lacks stock, everything rolls back. Tests inject a failure half-way to prove it.
22. *How do you stop stock going negative?* Three layers: validation, an explicit check in `apply_stock_change`, and a database CHECK (`quantity >= 0`).
23. *How do you stop a purchase adding stock twice?* Confirming runs `UPDATE ... SET status='CONFIRMED' WHERE status='DRAFT'`; only the first run changes a row, so the second is refused before any stock moves.
24. *How do you stop a double-clicked sale being saved twice?* Each sale form carries a random token stored in a UNIQUE column; the second submit hits the same token and is refused.
25. *Why store the cost price on each sale line?* Cost prices change. Storing cost and price at sale time keeps old profit figures correct.
26. *Why can a product be "archived" instead of deleted?* Old invoices and purchase records refer to it. Deleting would break them, so used products are hidden, unused ones are deleted.
27. *What is the audit trail?* `stock_movements` records every change (type, amount, quantity after, reason, user, time). The sum of movements must equal the stored quantity; "Check consistency" tests that.

**Business logic**
28. *Is revenue the same as profit?* No. Profit here = revenue after discount and returns (tax excluded) minus cost price at sale time, so it is gross profit. Rent and salaries are not included.
29. *How is the suggested reorder quantity calculated?* Enough to reach twice the reorder level (at least 1): `max(2 x reorder level, 1) - current stock`. The factor is in `config.py`.
30. *What happens when a sale is cancelled?* Every remaining unit goes back into stock through RETURN movements, a refund is recorded and the sale becomes CANCELLED.
31. *How does restore stay safe?* The backup file is checked (integrity check and expected tables), a safety copy of the current data is made, then the data is replaced with SQLite's backup API and the user is signed out.

**Honesty questions**
32. *What was tested?* 69 automated tests on the services, algorithms, database rules, reports, backup and persistence; all passed when run. The screens were driven by a script using a stand-in for Tkinter; layout and looks were not machine-checked, so check them by eye.
33. *What are the limitations?* Single user at a time on one computer, one admin role, no barcode hardware, no printing, no multi-currency, no tax rules beyond one percentage per invoice.
