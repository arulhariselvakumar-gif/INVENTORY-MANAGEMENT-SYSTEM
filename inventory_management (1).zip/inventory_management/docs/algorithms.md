# Data structures and algorithms

All are written from scratch in `dsa/`. The table says where each one is **actually called** by the application.
No product search or sort uses Python's built-in `sorted()`. It is used in the tests as an independent referee, and in two cosmetic places: ordering backup file names and ordering the bars of one chart.

| Structure / algorithm | File | Where the app uses it |
|---|---|---|
| List (array) | built-in | Product collections, report rows, cart lines |
| Hash table (chaining) | `dsa/hash_table.py` | `ProductIndex.by_sku` / `by_id`: exact SKU/ID lookup in the Search lab and the sales SKU box |
| Linked list | `dsa/linked_list.py` | `InventoryService.history_list()`: stock history of a product, newest first (Products > Stock history, Stock control) |
| Queue (circular array) | `dsa/queue_ds.py` | `InventoryService.restock_queue()`: FIFO restock tasks (Low-stock alerts > Process next) |
| Stack | `dsa/stack.py` | `UndoService`: undo last stock adjustment or product edit |
| Binary search tree | `dsa/binary_search_tree.py` | `ProductIndex.name_tree`: name-prefix search (Search lab, sales box fallback) |
| Linear search | `dsa/searching.py` | Search lab on unsorted data |
| Binary search | `dsa/searching.py` | Search lab on data first merge-sorted by the searched field |
| Bubble sort | `dsa/sorting.py` | Sort lab (limited to 200 products; it is O(n^2)) |
| Merge sort | `dsa/sorting.py` | Sort lab, `ProductIndex` sorted copies, and every table's click-to-sort headings |

Not claimed: BST delete, hash-table iteration order, and anything about SQLite's internals.

## Complexity

| Operation | Best | Average | Worst | Space |
|---|---|---|---|---|
| Stack push / pop / peek | O(1) | O(1) | O(1) | O(n) |
| Queue enqueue / dequeue (amortised) | O(1) | O(1) | O(n) on the occasional resize | O(n) |
| Linked list prepend | O(1) | O(1) | O(1) | O(n) |
| Linked list append (head pointer only) / find / remove | O(1) | O(n) | O(n) | O(1) extra |
| Hash table put / get / remove | O(1) | O(1) | O(n) if every key collides | O(n) |
| BST insert / search (balanced build) | O(log n) | O(log n) | O(n) if built from sorted data one by one | O(n) |
| BST prefix search | O(h) | O(h + k) | O(n) | O(h) |
| Linear search | O(1) | O(n) | O(n) | O(1) |
| Binary search | O(1) | O(log n) | O(log n) | O(1) |
| Bubble sort (with early exit) | O(n) | O(n^2) | O(n^2) | O(1) extra |
| Merge sort | O(n log n) | O(n log n) | O(n log n) | O(n) |

h = height of the tree, k = number of matches.

## 1. Stack - undo
**Purpose:** remember reversible actions; the newest is undone first (LIFO).
**Procedure:** `push` when a stock adjustment or product edit succeeds; `undo` looks at the top, reverses it, and pops it only after the reversal worked.
```
push(item): if capacity reached: drop oldest; append item
pop():      if empty: error; remove and return last item
```
Example: adjust A 10->6, then edit B's price, then Undo -> price restored; Undo -> stock back to 10; Undo -> "nothing to undo".
Limits: sales and purchases are never undone by the stack (they have cancel/return workflows so the audit trail stays honest).

## 2. Queue - restock tasks
**Purpose:** handle restock requests in the order they were raised (FIFO).
Circular array: `head` index plus `size`; when full the array doubles and items are copied to the start.
```
enqueue(x): if size == capacity: grow(); data[(head+size) mod cap] = x; size++
dequeue():  if size == 0: error; x = data[head]; head = (head+1) mod cap; size--; return x
```
Example: queue Notebook then Power strip; "Process next" returns Notebook, then Power strip, then "queue is empty".

## 3. Linked list - stock history
**Purpose:** a product's movements read oldest to newest from the database are **prepended**, so the head is the newest. Walking the list gives newest-first with no sorting.
```
prepend(v): head = Node(v, head)
iterate:    cur = head; while cur: yield cur.value; cur = cur.next
```
Example: movements OPENING, ADJUSTMENT, SALE become SALE -> ADJUSTMENT -> OPENING.

## 4. Hash table - SKU / ID lookup
Separate chaining: `index = hash(key) mod buckets`; each bucket is a list of [key, value]; the table doubles when load factor > 0.75.
```
put(k,v): b = bucket[hash(k) mod n]; if k in b: update else append; resize if load > 0.75
get(k):   scan the one bucket only
```
Example: SKU "MA-CHG-20W" (upper-cased) -> product record in one step, versus scanning the list.

## 5. Binary search tree - name prefix
Keys are lower-case product names; equal names share a node (list of values). It is **built balanced**: sort, insert the middle first, then recurse on both halves, so height is about log2(n). Inserting 127 sorted names one by one would give height 127 (tested).
```
prefix_search(p): walk(node): if node.key >= p: walk(left); if key startswith p: collect; if key[:len(p)] <= p: walk(right)
```
Example: "usb" returns "USB cable 1 m" without visiting branches that cannot start with "usb".

## 6. Linear search / 7. Binary search
```
linear(items, target): for i, x in items: comparisons++; if key(x) == target: return i;  return -1
binary(items, target): lo, hi = 0, n-1; while lo <= hi: mid = (lo+hi)//2; compare; move lo or hi
```
Both return the comparison count; the lab shows it. Binary search needs data sorted by the same key, so the app merge-sorts a copy first (once per field).
Example: find SKU in 65 products: linear up to 65 comparisons, binary at most 7 (tested).

## 8. Bubble sort / 9. Merge sort
```
bubble: repeat n-1 passes: for i in 0..end: if a[i] > a[i+1]: swap; stop early if a pass made no swap
merge:  sort(list): if len <= 1 return; split; merge(sort(left), sort(right))
        merge: take the smaller front item; ties take LEFT (keeps the sort stable)
```
Both support `key=`, `reverse=`, and return a new list. They are stable and tested against Python's `sorted()` on random data of sizes 0 to 150.
Real use: Sort lab (name, price, quantity, stock value) and the click-to-sort table headings use merge sort.
