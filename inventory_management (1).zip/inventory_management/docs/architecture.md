# Architecture

## Layers

```
 ui/ (Tkinter screens)            what the user sees; never writes SQL
   |  calls
 services/ (business rules)       validation, transactions, reports; the only code that talks to the database
   |  uses                \
 database.py (SQLite)      dsa/ (stack, queue, linked list, hash table, BST, searches, sorts)
```

* `services/container.py` builds one `Services` object around a single `Database`, and the UI receives it.
* `dsa/` has no imports from the application, so each structure is testable alone (`tests/test_dsa.py`).
* Errors are plain exception classes in `errors.py`; the window turns them into friendly dialogs (`App.handle_error`).

## Entity-relationship diagram

```mermaid
erDiagram
    USERS ||--o{ STOCK_MOVEMENTS : performs
    USERS ||--o{ ACTIVITY_LOGS : writes
    CATEGORIES ||--o{ PRODUCTS : groups
    SUPPLIERS  ||--o{ PRODUCTS : supplies
    SUPPLIERS  ||--o{ PURCHASES : receives_orders
    PURCHASES  ||--|{ PURCHASE_ITEMS : contains
    PRODUCTS   ||--o{ PURCHASE_ITEMS : bought_in
    SALES      ||--|{ SALE_ITEMS : contains
    PRODUCTS   ||--o{ SALE_ITEMS : sold_in
    SALE_ITEMS ||--o{ SALE_RETURNS : returned_as
    PRODUCTS   ||--o{ STOCK_MOVEMENTS : history
    PRODUCTS   ||--o{ STOCK_ADJUSTMENTS : corrected_by
    PRODUCTS   ||--o{ RESTOCK_TASKS : queued_for
```

## Tables (13)

| Table | Purpose | Important fields and rules |
|---|---|---|
| users | Admin accounts | `username` unique (case-insensitive); `password_hash` = PBKDF2-SHA256 with random salt |
| categories | Product groups | `name` unique |
| suppliers | Who we buy from | `company` unique; phone required |
| products | Items in stock | `sku` unique; `quantity >= 0` (CHECK); prices >= 0; `reorder_level >= 0`; `is_active` (archive flag); FK to category (RESTRICT) and supplier (SET NULL) |
| purchases | Purchase header | `status` DRAFT / CONFIRMED / CANCELLED; `request_token` unique (blocks double submit); `purchase_no` unique |
| purchase_items | Purchase lines | `quantity > 0`; `line_total`; cascade-deleted with header |
| sales | Invoice header | `invoice_no` unique; discount and tax percent 0-100 (CHECK); `status` COMPLETED / PARTIAL_RETURN / RETURNED / CANCELLED; `request_token` unique |
| sale_items | Invoice lines | stores `unit_price` AND `unit_cost` at sale time (so profit stays correct if prices change); `returned_qty <= quantity` (CHECK) |
| sale_returns | Refund records | one row per returned line, with refund amount and reason |
| stock_adjustments | Manual corrections | old and new quantity, reason, user |
| stock_movements | Audit trail of every stock change | type OPENING / PURCHASE / SALE / RETURN / ADJUSTMENT; change, quantity after, reference, user |
| restock_tasks | Persistent restock queue | one PENDING task per product (partial unique index) |
| activity_logs | Who did what | action, details, timestamp |

Indexes: SKU and invoice/purchase numbers (via UNIQUE), product name, category, supplier, movement (product, id), sale and purchase dates, line tables by header id.
SQLite's own B-tree indexes serve persistent lookups; the in-memory hash table and BST in `dsa/` are teaching structures built from a snapshot for the Search and sort lab and the sales SKU box. They are separate things.

## Transactions

`Database.transaction()` issues `BEGIN IMMEDIATE`, then `COMMIT` or `ROLLBACK`; nested calls join the outer transaction. Used by: add product (insert + opening movement), adjust stock, confirm purchase, create sale, return/cancel sale, restore helpers.
Tests inject a database error half-way through a sale and a purchase confirmation and prove that nothing is left partly saved.

## Flow of a sale

```mermaid
flowchart TD
    A[Pick products + quantities] --> B[Validate input]
    B -->|invalid| X[Show message]
    B --> C[BEGIN transaction]
    C --> D{Token already used?}
    D -->|yes| X2[Refuse duplicate]
    D -->|no| E[Read price and cost of each product]
    E --> F[Calculate subtotal, discount, tax, total]
    F --> G[Insert sale + items]
    G --> H{Stock enough for every line?}
    H -->|no| R[ROLLBACK - nothing saved]
    H -->|yes| I[Reduce stock + write movements]
    I --> J[COMMIT, show invoice]
```

## Flow of a purchase

```mermaid
flowchart LR
    D[Draft saved - stock unchanged] -->|Receive stock| C{Status is DRAFT?}
    C -->|yes| U[Set CONFIRMED and add stock in ONE transaction]
    C -->|no| E[Refuse - stock not changed again]
    D -->|Cancel draft| X[CANCELLED]
```
