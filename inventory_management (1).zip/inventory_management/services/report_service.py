"""Dashboard numbers, all reports and CSV export. Every report returns the same shape:
{"title", "columns": [(key, heading)], "rows": [dict], "summary": str}."""
import csv
import os

import config
import validators
from services.inventory_service import STATUS_SQL, InventoryService

PROFIT_ASSUMPTIONS = (
    "How profit is estimated: revenue = units sold (minus returned units) x selling price, after the "
    "sale's discount; tax is NOT revenue (it is collected for the government). Cost = the product's "
    "cost price recorded at the moment of sale. Estimated gross profit = revenue - cost. "
    "Rent, salaries and other expenses are not included, so this is not net profit.")

# net revenue and cost of one sale line, shared by several reports
_NET_REV = ("(si.quantity - si.returned_qty) * si.unit_price * "
            "(1 - CASE WHEN s.subtotal > 0 THEN s.discount_amount / s.subtotal ELSE 0 END)")
_NET_COST = "(si.quantity - si.returned_qty) * si.unit_cost"


def _range(column, date_from, date_to):
    sql, params = "", []
    if date_from:
        sql += f" AND {column} >= ?"
        params.append(validators.date(date_from, "From date"))
    if date_to:
        sql += f" AND {column} <= ?"
        params.append(validators.date(date_to, "To date"))
    return sql, params


def _report(title, columns, rows, summary=""):
    return {"title": title, "columns": columns, "rows": rows, "summary": summary}


class ReportService:
    def __init__(self, db):
        self.db = db
        self.inventory = InventoryService(db)

    # ---------- dashboard ----------
    def dashboard_stats(self):
        db = self.db
        low = db.one(f"SELECT COUNT(*) AS n, SUM(quantity = 0) AS out FROM products p "
                     f"WHERE is_active = 1 AND quantity <= reorder_level")
        return {
            "total_products": db.scalar("SELECT COUNT(*) FROM products WHERE is_active = 1"),
            "total_quantity": db.scalar("SELECT SUM(quantity) FROM products WHERE is_active = 1"),
            "stock_value": round(db.scalar("SELECT SUM(quantity * cost_price) FROM products WHERE is_active = 1", default=0.0), 2),
            "low_stock": low["n"] or 0, "out_of_stock": low["out"] or 0,
            "suppliers": db.scalar("SELECT COUNT(*) FROM suppliers"),
            "purchases": db.scalar("SELECT COUNT(*) FROM purchases WHERE status = 'CONFIRMED'"),
            "purchase_spend": round(db.scalar("SELECT SUM(total_cost) FROM purchases WHERE status = 'CONFIRMED'", default=0.0), 2),
            "sales": db.scalar("SELECT COUNT(*) FROM sales WHERE status IN ('COMPLETED','PARTIAL_RETURN')"),
            "sales_revenue": round(db.scalar(
                f"SELECT SUM({_NET_REV}) FROM sale_items si JOIN sales s ON s.id = si.sale_id", default=0.0), 2),
        }

    def recent_transactions(self, limit=8):
        return [dict(r) for r in self.db.query(
            """SELECT * FROM (
                 SELECT 'Sale' AS kind, invoice_no AS ref, customer_name AS party, total AS amount,
                        status, created_at FROM sales
                 UNION ALL
                 SELECT 'Purchase', p.purchase_no, s.company, p.total_cost, p.status, p.created_at
                 FROM purchases p JOIN suppliers s ON s.id = p.supplier_id)
               ORDER BY created_at DESC, ref DESC LIMIT ?""", (limit,))]

    # ---------- reports ----------
    def current_stock(self, category_id=None, supplier_id=None, status=None):
        sql = f"""SELECT p.sku, p.name, c.name AS category, COALESCE(s.company,'-') AS supplier,
                         p.quantity, p.reorder_level, p.cost_price, p.selling_price,
                         ROUND(p.quantity * p.cost_price, 2) AS stock_value, {STATUS_SQL} AS status
                  FROM products p JOIN categories c ON c.id = p.category_id
                  LEFT JOIN suppliers s ON s.id = p.supplier_id WHERE p.is_active = 1"""
        params = []
        for clause, value in (("p.category_id = ?", category_id), ("p.supplier_id = ?", supplier_id),
                              (f"{STATUS_SQL} = ?", status if status in ("OK", "LOW", "OUT") else None)):
            if value:
                sql += " AND " + clause
                params.append(value)
        rows = [dict(r) for r in self.db.query(sql + " ORDER BY p.name", params)]
        cols = [("sku", "SKU"), ("name", "Product"), ("category", "Category"), ("supplier", "Supplier"),
                ("quantity", "Qty"), ("reorder_level", "Reorder at"), ("cost_price", "Cost"),
                ("selling_price", "Price"), ("stock_value", "Stock value"), ("status", "Status")]
        return _report("Current stock", cols, rows, f"{len(rows)} product(s), {sum(r['quantity'] for r in rows)} unit(s) in stock.")

    def valuation(self):
        rows = [dict(r) for r in self.db.query(
            """SELECT c.name AS category, COUNT(p.id) AS products, COALESCE(SUM(p.quantity),0) AS units,
                      ROUND(COALESCE(SUM(p.quantity * p.cost_price),0),2) AS cost_value,
                      ROUND(COALESCE(SUM(p.quantity * p.selling_price),0),2) AS retail_value,
                      ROUND(COALESCE(SUM(p.quantity * (p.selling_price - p.cost_price)),0),2) AS potential_margin
               FROM categories c LEFT JOIN products p ON p.category_id = c.id AND p.is_active = 1
               GROUP BY c.id ORDER BY cost_value DESC""")]
        cost, retail = sum(r["cost_value"] for r in rows), sum(r["retail_value"] for r in rows)
        cols = [("category", "Category"), ("products", "Products"), ("units", "Units"), ("cost_value", "Value at cost"),
                ("retail_value", "Value at selling price"), ("potential_margin", "Potential margin")]
        return _report("Inventory valuation", cols, rows,
                       f"Total value at cost {config.CURRENCY}{cost:,.2f}; at selling price {config.CURRENCY}{retail:,.2f}. "
                       "Potential margin is only realised if every unit sells at list price.")

    def low_stock(self, status=None, category_id=None, supplier_id=None):
        rows = self.inventory.low_stock(status, category_id, supplier_id)
        cols = [("sku", "SKU"), ("name", "Product"), ("category", "Category"), ("supplier", "Supplier"),
                ("quantity", "In stock"), ("reorder_level", "Reorder at"), ("suggested_qty", "Suggested order"),
                ("estimated_cost", "Estimated cost"), ("status", "Status")]
        title = {"OUT": "Out-of-stock products", "LOW": "Low-stock products"}.get(status, "Low and out-of-stock products")
        return _report(title, cols, rows, f"{len(rows)} product(s) need attention.")

    def purchases(self, date_from=None, date_to=None):
        extra, params = _range("p.purchase_date", date_from, date_to)
        rows = [dict(r) for r in self.db.query(
            f"""SELECT p.purchase_date, p.purchase_no, s.company AS supplier, p.status,
                       (SELECT COALESCE(SUM(quantity),0) FROM purchase_items WHERE purchase_id = p.id) AS units,
                       p.total_cost
                FROM purchases p JOIN suppliers s ON s.id = p.supplier_id WHERE 1=1 {extra}
                ORDER BY p.purchase_date DESC, p.id DESC""", params)]
        spent = sum(r["total_cost"] for r in rows if r["status"] == "CONFIRMED")
        cols = [("purchase_date", "Date"), ("purchase_no", "Purchase no."), ("supplier", "Supplier"),
                ("status", "Status"), ("units", "Units"), ("total_cost", "Total cost")]
        return _report("Purchases by date", cols, rows, f"Confirmed purchases in range: {config.CURRENCY}{spent:,.2f}.")

    def sales(self, date_from=None, date_to=None):
        extra, params = _range("sale_date", date_from, date_to)
        rows = [dict(r) for r in self.db.query(
            f"""SELECT sale_date, invoice_no, customer_name, subtotal, discount_amount, tax_amount, total, status
                FROM sales WHERE 1=1 {extra} ORDER BY sale_date DESC, id DESC""", params)]
        billed = sum(r["total"] for r in rows if r["status"] not in ("CANCELLED", "RETURNED"))
        cols = [("sale_date", "Date"), ("invoice_no", "Invoice"), ("customer_name", "Customer"), ("subtotal", "Subtotal"),
                ("discount_amount", "Discount"), ("tax_amount", "Tax"), ("total", "Total"), ("status", "Status")]
        return _report("Sales by date", cols, rows,
                       f"Billed (excluding cancelled/fully returned): {config.CURRENCY}{billed:,.2f} including tax. "
                       "Billed amount is not profit.")

    def best_sellers(self, date_from=None, date_to=None, limit=10):
        extra, params = _range("s.sale_date", date_from, date_to)
        rows = [dict(r) for r in self.db.query(
            f"""SELECT p.sku, p.name, SUM(si.quantity - si.returned_qty) AS units_sold,
                       ROUND(SUM({_NET_REV}), 2) AS revenue
                FROM sale_items si JOIN sales s ON s.id = si.sale_id JOIN products p ON p.id = si.product_id
                WHERE 1=1 {extra} GROUP BY p.id HAVING units_sold > 0
                ORDER BY units_sold DESC, revenue DESC LIMIT ?""", params + [limit])]
        cols = [("sku", "SKU"), ("name", "Product"), ("units_sold", "Units sold (net)"), ("revenue", "Revenue")]
        return _report(f"Best-selling products (top {limit})", cols, rows, "Units are net of returns.")

    def supplier_summary(self, date_from=None, date_to=None):
        extra, params = _range("p.purchase_date", date_from, date_to)
        rows = [dict(r) for r in self.db.query(
            f"""SELECT s.company AS supplier, COUNT(DISTINCT p.id) AS purchases,
                       COALESCE(SUM(i.quantity),0) AS units, ROUND(COALESCE(SUM(i.line_total),0),2) AS total_spent
                FROM suppliers s JOIN purchases p ON p.supplier_id = s.id AND p.status = 'CONFIRMED'
                JOIN purchase_items i ON i.purchase_id = p.id WHERE 1=1 {extra}
                GROUP BY s.id ORDER BY total_spent DESC""", params)]
        cols = [("supplier", "Supplier"), ("purchases", "Purchases"), ("units", "Units bought"), ("total_spent", "Total spent")]
        return _report("Supplier-wise purchase summary", cols, rows, "Only confirmed purchases are counted.")

    def profit(self, date_from=None, date_to=None):
        extra, params = _range("s.sale_date", date_from, date_to)
        rows = [dict(r) for r in self.db.query(
            f"""SELECT p.sku, p.name, SUM(si.quantity - si.returned_qty) AS units,
                       ROUND(SUM({_NET_REV}), 2) AS revenue, ROUND(SUM({_NET_COST}), 2) AS cost,
                       ROUND(SUM({_NET_REV}) - SUM({_NET_COST}), 2) AS profit
                FROM sale_items si JOIN sales s ON s.id = si.sale_id JOIN products p ON p.id = si.product_id
                WHERE 1=1 {extra} GROUP BY p.id HAVING units > 0 ORDER BY profit DESC""", params)]
        rev, cost = sum(r["revenue"] for r in rows), sum(r["cost"] for r in rows)
        margin = (rev - cost) / rev * 100 if rev else 0
        cols = [("sku", "SKU"), ("name", "Product"), ("units", "Units"), ("revenue", "Revenue"),
                ("cost", "Cost of goods"), ("profit", "Estimated profit")]
        c = config.CURRENCY
        return _report("Estimated profit", cols, rows,
                       f"Revenue {c}{rev:,.2f} - cost {c}{cost:,.2f} = estimated gross profit {c}{rev - cost:,.2f} "
                       f"({margin:.1f}% margin).\n{PROFIT_ASSUMPTIONS}")

    def stock_movements(self):
        rows = self.inventory.movement_summary()
        cols = [("sku", "SKU"), ("name", "Product"), ("opening", "Opening"), ("received", "Received"),
                ("sold", "Sold"), ("returned", "Returned"), ("adjusted", "Adjusted"), ("current_qty", "Current")]
        return _report("Stock movement summary", cols, rows,
                       "Opening + received - sold + returned + adjusted = current stock.")

    REPORTS = {
        "Current stock": ("current_stock", False), "Inventory valuation": ("valuation", False),
        "Low and out-of-stock": ("low_stock", False), "Purchases by date": ("purchases", True),
        "Sales by date": ("sales", True), "Best-selling products": ("best_sellers", True),
        "Supplier-wise purchases": ("supplier_summary", True), "Estimated profit": ("profit", True),
        "Stock movement summary": ("stock_movements", False)}

    def run(self, name, date_from=None, date_to=None):
        method, uses_dates = self.REPORTS[name]
        func = getattr(self, method)
        return func(date_from, date_to) if uses_dates else func()

    # ---------- chart data ----------
    def stock_by_category(self):
        return [(r["category"], r["units"], r["cost_value"]) for r in self.valuation()["rows"] if r["units"]]

    def sales_trend(self, date_from=None, date_to=None):
        extra, params = _range("s.sale_date", date_from, date_to)
        return [(r["d"], r["revenue"]) for r in self.db.query(
            f"""SELECT s.sale_date AS d, ROUND(SUM({_NET_REV}), 2) AS revenue
                FROM sale_items si JOIN sales s ON s.id = si.sale_id WHERE 1=1 {extra}
                GROUP BY s.sale_date ORDER BY s.sale_date""", params)]

    # ---------- export ----------
    @staticmethod
    def export_csv(report, path):
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "w", newline="", encoding="utf-8-sig") as fh:   # utf-8-sig so Excel shows the rupee sign
            writer = csv.writer(fh)
            writer.writerow([h for _, h in report["columns"]])
            for row in report["rows"]:
                writer.writerow([row.get(k, "") for k, _ in report["columns"]])
        return len(report["rows"])
