"""Undo for reversible actions, backed by the Stack data structure.
Reversible: stock adjustments and product edits. Sales/purchases are NOT undone here -
they have their own cancel / return workflow so the audit trail stays honest."""
from dsa.stack import Stack
from errors import BusinessRuleError


class UndoService:
    def __init__(self, products, inventory):
        self.products, self.inventory = products, inventory
        self.stack = Stack(capacity=20)

    def record_adjustment(self, product_id, delta, label):
        self.stack.push({"type": "adjustment", "product_id": product_id, "delta": delta, "label": label})

    def record_product_edit(self, product_id, old_values, label):
        self.stack.push({"type": "edit", "product_id": product_id, "old": old_values, "label": label})

    def can_undo(self):
        return not self.stack.is_empty()

    def peek_label(self):
        return self.stack.peek()["label"] if self.can_undo() else ""

    def undo(self, user_id):
        if self.stack.is_empty():
            raise BusinessRuleError("There is nothing to undo.")
        action = self.stack.peek()
        # Only discard the entry once the reversal has succeeded; if it fails (for example the
        # stock was sold in the meantime) the entry stays on the stack.
        if action["type"] == "adjustment":
            current = self.products.get(action["product_id"])["quantity"]
            self.inventory.adjust_stock(action["product_id"], current - action["delta"],
                                        "Undo: " + action["label"], user_id)
        else:
            self.products.restore(action["product_id"], action["old"], user_id)
        self.stack.pop()
        return action["label"]
