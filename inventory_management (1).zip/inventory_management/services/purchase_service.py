"""Purchases: draft -> confirmed. Stock is added exactly once, when the draft is confirmed."""
import sqlite3

import validators
from database import now_str
from errors import (BusinessRuleError, DuplicateTransactionError, NotFoundError, ValidationError)
from services.inventory_service import apply_stock_change


class PurchaseService:
    def __init__(self, db):
        self.db = db

    def create(self, supplier_id, purchase_date, items, notes="", user_id=None,
               request_token=None, confirm=False):
        """items = [(product_id, quantity, unit_cost), ...]. Saves a DRAFT (or confirms at once)."""
        if self.db.one("SELECT 1 FROM suppliers WHERE id = ?", (supplier_id,)) is None:
            raise ValidationError("Choose a supplier.")
        purchase_date = validators.date(purchase_date, "Purchase date")
        notes = validators.text(notes, "Notes", required=False, max_len=200)
        if not items:
            raise ValidationError("Add at least one product to the purchase.")
        lines, seen = [], set()
        for product_id, qty, cost in items:
            if product_id in seen:
                raise ValidationError("A product appears twice in this purchase. Combine the quantities.")
            seen.add(product_id)
            lines.append((product_id, validators.integer(qty, "Quantity", minimum=1),
                          validators.money(cost, "Unit cost")))
        try:
            with self.db.transaction():
                if request_token and self.db.one("SELECT 1 FROM purchases WHERE request_token = ?",
                                                 (request_token,)):
                    raise DuplicateTransactionError("This purchase was already saved.")
                for product_id, _, _ in lines:
                    if self.db.one("SELECT 1 FROM products WHERE id = ? AND is_active = 1", (product_id,)) is None:
                        raise ValidationError("One of the products no longer exists.")
                total = round(sum(q * c for _, q, c in lines), 2)
                cur = self.db.execute(
                    """INSERT INTO purchases (purchase_no, supplier_id, purchase_date, status, total_cost, notes,
                                              request_token, created_by, created_at)
                       VALUES (?,?,?,'DRAFT',?,?,?,?,?)""",
                    (f"TMP-{request_token or now_str()}", supplier_id, purchase_date, total, notes,
                     request_token, user_id, now_str()))
                pid = cur.lastrowid
                number = f"PO-{purchase_date[:4]}{purchase_date[5:7]}-{pid:05d}"
                self.db.execute("UPDATE purchases SET purchase_no = ? WHERE id = ?", (number, pid))
                for product_id, qty, cost in lines:
                    self.db.execute(
                        "INSERT INTO purchase_items (purchase_id, product_id, quantity, unit_cost, line_total) "
                        "VALUES (?,?,?,?,?)", (pid, product_id, qty, cost, round(qty * cost, 2)))
                self.db.log(user_id, "PURCHASE_CREATED", number)
                if confirm:
                    self.confirm(pid, user_id)
        except sqlite3.IntegrityError as exc:
            # only a clash on the request token means "submitted twice"; anything else is a real error
            if request_token and "request_token" in str(exc):
                raise DuplicateTransactionError("This purchase was already saved.") from None
            raise
        return pid

    def confirm(self, purchase_id, user_id=None):
        """Flip DRAFT -> CONFIRMED and add stock in ONE transaction. The status flip comes first and
        only succeeds for a DRAFT, so confirming twice can never add the stock twice."""
        with self.db.transaction():
            cur = self.db.execute(
                "UPDATE purchases SET status='CONFIRMED', confirmed_at=? WHERE id=? AND status='DRAFT'",
                (now_str(), purchase_id))
            if cur.rowcount == 0:
                row = self.db.one("SELECT status FROM purchases WHERE id = ?", (purchase_id,))
                if row is None:
                    raise NotFoundError("Purchase not found.")
                raise BusinessRuleError(f"This purchase is already {row['status'].lower()}; stock was not changed again.")
            number = self.db.scalar("SELECT purchase_no FROM purchases WHERE id = ?", (purchase_id,))
            for item in self.db.query("SELECT product_id, quantity FROM purchase_items WHERE purchase_id = ?",
                                      (purchase_id,)):
                apply_stock_change(self.db, item["product_id"], item["quantity"], "PURCHASE",
                                   "purchase", purchase_id, f"Received on {number}", user_id)
            self.db.log(user_id, "PURCHASE_CONFIRMED", number)

    def cancel(self, purchase_id, user_id=None):
        with self.db.transaction():
            cur = self.db.execute("UPDATE purchases SET status='CANCELLED' WHERE id=? AND status='DRAFT'",
                                  (purchase_id,))
            if cur.rowcount == 0:
                raise BusinessRuleError("Only draft purchases can be cancelled. For confirmed purchases "
                                        "correct the stock with a stock adjustment.")
            self.db.log(user_id, "PURCHASE_CANCELLED", str(purchase_id))

    def get(self, purchase_id):
        head = self.db.one(
            """SELECT p.*, s.company AS supplier FROM purchases p
               JOIN suppliers s ON s.id = p.supplier_id WHERE p.id = ?""", (purchase_id,))
        if head is None:
            raise NotFoundError("Purchase not found.")
        items = [dict(r) for r in self.db.query(
            """SELECT i.*, pr.sku, pr.name FROM purchase_items i JOIN products pr ON pr.id = i.product_id
               WHERE i.purchase_id = ? ORDER BY i.id""", (purchase_id,))]
        return {**dict(head), "items": items}

    def list(self, date_from=None, date_to=None, status=None, supplier_id=None):
        sql = """SELECT p.id, p.purchase_no, p.purchase_date, s.company AS supplier, p.status, p.total_cost,
                        (SELECT COALESCE(SUM(quantity),0) FROM purchase_items WHERE purchase_id = p.id) AS units
                 FROM purchases p JOIN suppliers s ON s.id = p.supplier_id WHERE 1=1"""
        params = []
        for clause, value in (("p.purchase_date >= ?", date_from), ("p.purchase_date <= ?", date_to),
                              ("p.status = ?", status), ("p.supplier_id = ?", supplier_id)):
            if value:
                sql += " AND " + clause
                params.append(value)
        return [dict(r) for r in self.db.query(sql + " ORDER BY p.id DESC", params)]
