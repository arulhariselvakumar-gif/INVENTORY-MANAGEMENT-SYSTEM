"""Builds every service around one Database so the UI only needs a single object."""
from auth import AuthService
from database import Database
from services.backup_service import BackupService
from services.csv_service import CsvService
from services.inventory_service import InventoryService
from services.master_service import CategoryService, SupplierService
from services.product_service import ProductService
from services.purchase_service import PurchaseService
from services.report_service import ReportService
from services.sales_service import SalesService
from services.undo_service import UndoService


class Services:
    def __init__(self, db_path, backup_dir=None):
        self.db = Database(db_path)
        self.auth = AuthService(self.db)
        self.categories = CategoryService(self.db)
        self.suppliers = SupplierService(self.db)
        self.products = ProductService(self.db)
        self.inventory = InventoryService(self.db)
        self.purchases = PurchaseService(self.db)
        self.sales = SalesService(self.db)
        self.reports = ReportService(self.db)
        self.csv = CsvService(self.db, self.products)
        self.backup = BackupService(self.db, backup_dir)
        self.undo = UndoService(self.products, self.inventory)

    def close(self):
        self.db.close()
