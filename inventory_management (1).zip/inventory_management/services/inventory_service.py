"""Stock operations: the ONLY place that changes products.quantity.
Every change goes through apply_stock_change(), which also writes the audit trail."""
import config
import validators
from database import now_str
from dsa.linked_list import LinkedList
from dsa.queue_ds import Queue
from errors import (BusinessRuleError, DuplicateError, InsufficientStockError,
                    NotFoundError, ValidationError)

STATUS_SQL = "CASE WHEN p.quantity = 0 THEN 'OUT' WHEN p.quantity <= p.reorder_level THEN 'LOW' ELSE 'OK' END"


def apply_stock_change(db, product_id, delta, movement_type, reference_type="",
                       reference_id=None, reason="", user_id=None):
    """Change stock by `delta` (+ in, - out) and record a stock movement.
    MUST be called inside db.transaction() so that stock and movement stay in step.
    Raises InsufficientStockError instead of letting stock go negative."""
    if delta == 0:
        raise ValidationError("Quantity change cannot be zero.")
    row = db.one("SELECT quantity, name FROM products WHERE id = ?", (product_id,))
    if row is None:
        raise NotFoundError("Product not found.")
    new_qty = row["quantity"] + delta
    if new_qty < 0:
        raise InsufficientStockError(
            f"Not enough stock for '{row['name']}': {row['quantity']} available, {-delta} requested.")
    db.execute("UPDATE products SET quantity = ? WHERE id = ?", (new_qty, product_id))
    db.execute(
        """INSERT INTO stock_movements (product_id, movement_type, quantity_change, quantity_after,
                                        reference_type, reference_id, reason, performed_by, created_at)
           VALUES (?,?,?,?,?,?,?,?,?)""",
        (product_id, movement_type, delta, new_qty, reference_type, reference_id, reason, user_id, now_str()))
    return new_qty


class InventoryService:
    def __init__(self, db):
        self.db = db

    # ---------- adjustments ----------
    def adjust_stock(self, product_id, new_quantity, reason, user_id):
        new_quantity = validators.integer(new_quantity, "New quantity", minimum=0)
        reason = validators.text(reason, "Reason", max_len=200)
        with self.db.transaction():
            row = self.db.one("SELECT quantity, name FROM products WHERE id = ?", (product_id,))
            if row is None:
                raise NotFoundError("Product not found.")
            delta = new_quantity - row["quantity"]
            if delta == 0:
                raise ValidationError("The new quantity equals the current stock - nothing to adjust.")
            cur = self.db.execute(
                """INSERT INTO stock_adjustments (product_id, old_quantity, new_quantity, reason,
                                                  performed_by, created_at) VALUES (?,?,?,?,?,?)""",
                (product_id, row["quantity"], new_quantity, reason, user_id, now_str()))
            apply_stock_change(self.db, product_id, delta, "ADJUSTMENT", "stock_adjustment",
                               cur.lastrowid, reason, user_id)
            self.db.log(user_id, "STOCK_ADJUSTED",
                        f"{row['name']}: {row['quantity']} -> {new_quantity} ({reason})")
        return {"old": row["quantity"], "new": new_quantity, "delta": delta}

    # ---------- history (linked list) ----------
    def history_list(self, product_id):
        """Return a LinkedList of movements, newest first. Rows are read oldest->newest
        and PREPENDED, so the head is always the latest movement."""
        rows = self.db.query(
            """SELECT m.*, COALESCE(u.username, '-') AS user_name
               FROM stock_movements m LEFT JOIN users u ON u.id = m.performed_by
               WHERE m.product_id = ? ORDER BY m.id ASC""", (product_id,))
        history = LinkedList()
        for r in rows:
            history.prepend(dict(r))
        return history

    # ---------- reports on stock ----------
    def movement_summary(self):
        """Per product: opening / received / sold / returned / adjusted quantities."""
        return [dict(r) for r in self.db.query(
            """SELECT p.sku, p.name, p.quantity AS current_qty,
                 COALESCE(SUM(CASE WHEN m.movement_type='OPENING'    THEN m.quantity_change END),0) AS opening,
                 COALESCE(SUM(CASE WHEN m.movement_type='PURCHASE'   THEN m.quantity_change END),0) AS received,
                 COALESCE(-SUM(CASE WHEN m.movement_type='SALE'      THEN m.quantity_change END),0) AS sold,
                 COALESCE(SUM(CASE WHEN m.movement_type='RETURN'     THEN m.quantity_change END),0) AS returned,
                 COALESCE(SUM(CASE WHEN m.movement_type='ADJUSTMENT' THEN m.quantity_change END),0) AS adjusted
               FROM products p LEFT JOIN stock_movements m ON m.product_id = p.id
               WHERE p.is_active = 1 GROUP BY p.id ORDER BY p.name""")]

    def verify_consistency(self):
        """Products whose stored quantity differs from the sum of their movements."""
        return [dict(r) for r in self.db.query(
            """SELECT p.id, p.sku, p.name, p.quantity AS stored_qty,
                      COALESCE(SUM(m.quantity_change), 0) AS movement_total
               FROM products p LEFT JOIN stock_movements m ON m.product_id = p.id
               GROUP BY p.id HAVING p.quantity <> COALESCE(SUM(m.quantity_change), 0)""")]

    def recalculate_stock(self, user_id=None):
        """Rebuild quantity from the movement history for every mismatching product."""
        fixed = self.verify_consistency()
        with self.db.transaction():
            for r in fixed:
                self.db.execute("UPDATE products SET quantity = ? WHERE id = ?",
                                (max(r["movement_total"], 0), r["id"]))
            if fixed:
                self.db.log(user_id, "STOCK_RECALCULATED", f"{len(fixed)} product(s) corrected")
        return len(fixed)

    # ---------- low stock ----------
    def low_stock(self, status=None, category_id=None, supplier_id=None):
        """status: None/'ALL' (low + out), 'LOW' or 'OUT'."""
        sql = f"""SELECT p.id, p.sku, p.name, p.quantity, p.reorder_level, p.cost_price,
                         c.name AS category, COALESCE(s.company, '-') AS supplier,
                         {STATUS_SQL} AS status
                  FROM products p JOIN categories c ON c.id = p.category_id
                  LEFT JOIN suppliers s ON s.id = p.supplier_id
                  WHERE p.is_active = 1 AND p.quantity <= p.reorder_level"""
        params = []
        if status in ("LOW", "OUT"):
            sql += f" AND {STATUS_SQL} = ?"
            params.append(status)
        if category_id:
            sql += " AND p.category_id = ?"
            params.append(category_id)
        if supplier_id:
            sql += " AND p.supplier_id = ?"
            params.append(supplier_id)
        sql += " ORDER BY p.quantity ASC, p.name"
        out = []
        for r in self.db.query(sql, params):
            d = dict(r)
            d["suggested_qty"] = self.suggested_reorder(d["quantity"], d["reorder_level"])
            d["estimated_cost"] = round(d["suggested_qty"] * d["cost_price"], 2)
            out.append(d)
        return out

    @staticmethod
    def suggested_reorder(quantity, reorder_level):
        """Order enough to reach FACTOR x reorder level (at least 1 unit)."""
        target = max(config.LOW_STOCK_TARGET_FACTOR * reorder_level, 1)
        return max(target - quantity, 1)

    # ---------- restock queue (FIFO) ----------
    def queue_restock(self, product_id, user_id):
        row = self.db.one("SELECT quantity, reorder_level, name FROM products WHERE id = ? AND is_active = 1",
                          (product_id,))
        if row is None:
            raise NotFoundError("Product not found.")
        if self.db.scalar("SELECT COUNT(*) FROM restock_tasks WHERE product_id=? AND status='PENDING'",
                          (product_id,)):
            raise DuplicateError(f"'{row['name']}' is already waiting in the restock queue.")
        qty = self.suggested_reorder(row["quantity"], row["reorder_level"])
        with self.db.transaction():
            self.db.execute(
                "INSERT INTO restock_tasks (product_id, suggested_qty, created_at) VALUES (?,?,?)",
                (product_id, qty, now_str()))
            self.db.log(user_id, "RESTOCK_QUEUED", f"{row['name']} x{qty}")
        return qty

    def restock_queue(self):
        """Load pending tasks into the Queue data structure, oldest at the front."""
        queue = Queue()
        for r in self.db.query(
                """SELECT t.id, t.product_id, t.suggested_qty, t.created_at, p.sku, p.name, p.supplier_id
                   FROM restock_tasks t JOIN products p ON p.id = t.product_id
                   WHERE t.status = 'PENDING' ORDER BY t.id"""):
            queue.enqueue(dict(r))
        return queue

    def process_next_restock(self, user_id):
        """Dequeue the front task (first in, first out) and mark it done."""
        queue = self.restock_queue()
        if queue.is_empty():
            raise BusinessRuleError("The restock queue is empty.")
        task = queue.dequeue()
        with self.db.transaction():
            self.db.execute("UPDATE restock_tasks SET status = 'DONE' WHERE id = ?", (task["id"],))
            self.db.log(user_id, "RESTOCK_PROCESSED", f"{task['name']} x{task['suggested_qty']}")
        return task
