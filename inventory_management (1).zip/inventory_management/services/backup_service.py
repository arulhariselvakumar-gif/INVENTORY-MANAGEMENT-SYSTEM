"""Safe backup & restore using SQLite's online backup API (consistent even while the app is open)."""
import os
import sqlite3
from datetime import datetime

import config
from database import TABLES
from errors import ValidationError


class BackupService:
    def __init__(self, db, backup_dir=None):
        self.db = db
        self.backup_dir = backup_dir or config.BACKUP_DIR

    def default_name(self, prefix="inventory_backup"):
        return os.path.join(self.backup_dir, f"{prefix}_{datetime.now():%Y%m%d_%H%M%S}.db")

    def backup(self, path=None):
        path = path or self.default_name()
        if os.path.abspath(path) == os.path.abspath(self.db.path):
            raise ValidationError("Choose a different file - you cannot back up onto the live database.")
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        if os.path.exists(path):
            os.remove(path)
        dest = sqlite3.connect(path)
        try:
            self.db.conn.backup(dest)
        finally:
            dest.close()
        return path

    @staticmethod
    def verify(path):
        """Raise ValidationError unless `path` is an intact copy of this application's database."""
        if not os.path.isfile(path):
            raise ValidationError("Backup file not found.")
        try:
            conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
            try:
                if conn.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                    raise ValidationError("The backup file is damaged (integrity check failed).")
                names = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            finally:
                conn.close()
        except sqlite3.DatabaseError:
            raise ValidationError("That file is not a valid inventory database.") from None
        missing = [t for t in TABLES if t not in names]
        if missing:
            raise ValidationError("That file is not an inventory backup (missing: " + ", ".join(missing[:3]) + ").")

    def restore(self, path):
        """Verify, take a safety copy of the CURRENT data, then replace it. Returns the safety copy path."""
        self.verify(path)
        if os.path.abspath(path) == os.path.abspath(self.db.path):
            raise ValidationError("Pick a backup file, not the live database.")
        safety = self.backup(self.default_name("before_restore"))
        src = sqlite3.connect(path)
        try:
            src.backup(self.db.conn)
        finally:
            src.close()
        self.db.conn.execute("PRAGMA foreign_keys = ON")
        return safety

    def list_backups(self):
        if not os.path.isdir(self.backup_dir):
            return []
        out = []
        for name in sorted(os.listdir(self.backup_dir), reverse=True):
            if name.endswith(".db"):
                full = os.path.join(self.backup_dir, name)
                out.append({"name": name, "path": full, "size_kb": round(os.path.getsize(full) / 1024, 1),
                            "modified": datetime.fromtimestamp(os.path.getmtime(full)).strftime("%Y-%m-%d %H:%M:%S")})
        return out
