"""Matplotlib figures (built with the object-oriented Figure API, so no global pyplot state)."""
from matplotlib.figure import Figure

import config

PALETTE = ["#0f766e", "#e0a526", "#2f6f9f", "#b4532a", "#5b8c3a", "#7a5c99", "#a3a3a3"]


def stock_distribution_figure(data):
    """data = [(category, units, value)]. Horizontal bars, value labelled."""
    fig = Figure(figsize=(6, 3.6), dpi=100, facecolor="white")
    ax = fig.add_subplot(111)
    if not data:
        ax.text(0.5, 0.5, "No stock to show yet", ha="center", va="center")
        ax.axis("off")
        return fig
    data = sorted(data, key=lambda r: r[1])
    names, units = [r[0] for r in data], [r[1] for r in data]
    bars = ax.barh(names, units, color=PALETTE[0])
    for bar, (_, u, v) in zip(bars, data):
        ax.text(bar.get_width(), bar.get_y() + bar.get_height() / 2,
                f"  {u} units  ({config.CURRENCY}{v:,.0f})", va="center", fontsize=8)
    ax.set_xlabel("Units in stock")
    ax.set_title("Stock distribution by category", fontsize=11, loc="left")
    ax.set_xlim(0, max(units) * 1.45)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    fig.tight_layout()
    return fig


def sales_trend_figure(data):
    """data = [(date, revenue)]."""
    fig = Figure(figsize=(6, 3.6), dpi=100, facecolor="white")
    ax = fig.add_subplot(111)
    if not data:
        ax.text(0.5, 0.5, "No sales in this period", ha="center", va="center")
        ax.axis("off")
        return fig
    labels, values = [d[5:] for d, _ in data], [v for _, v in data]
    ax.plot(labels, values, color=PALETTE[0], marker="o", linewidth=2)
    ax.fill_between(labels, values, color=PALETTE[0], alpha=0.12)
    ax.set_title(f"Daily sales revenue, net of discounts and returns ({config.CURRENCY})", fontsize=10, loc="left")
    ax.set_xlabel("Date (MM-DD)")
    step = max(1, len(labels) // 8)
    ax.set_xticks(range(0, len(labels), step))
    ax.set_xticklabels(labels[::step], rotation=45, fontsize=8)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    fig.tight_layout()
    return fig
