"""Sales, invoices, returns and cancellations. All money maths uses Decimal to avoid float drift."""
import sqlite3
from decimal import Decimal, ROUND_HALF_UP

import config
import validators
from database import now_str, today_str
from errors import (BusinessRuleError, DuplicateTransactionError, NotFoundError, ValidationError)
from services.inventory_service import apply_stock_change

_CENT = Decimal("0.01")


def _d(value):
    return Decimal(str(value))


def _round(value):
    return value.quantize(_CENT, rounding=ROUND_HALF_UP)


def calc_totals(lines, discount_percent, tax_percent):
    """lines = [(quantity, unit_price)]. Discount is applied to the subtotal, tax to the discounted amount."""
    subtotal = sum((_d(price) * qty for qty, price in lines), Decimal(0))
    discount = _round(subtotal * _d(discount_percent) / 100)
    taxable = subtotal - discount
    tax = _round(taxable * _d(tax_percent) / 100)
    return {"subtotal": float(_round(subtotal)), "discount_amount": float(discount),
            "tax_amount": float(tax), "total": float(_round(taxable + tax))}


class SalesService:
    def __init__(self, db):
        self.db = db

    def create(self, items, customer_name="", discount_percent=0, tax_percent=None, user_id=None,
               request_token=None, sale_date=None):
        """items = [(product_id, quantity), ...]. Stock is reduced only if EVERY line can be served;
        otherwise the whole sale is rolled back."""
        if not items:
            raise ValidationError("Add at least one product to the sale.")
        customer = validators.text(customer_name, "Customer name", required=False, max_len=80) or "Walk-in customer"
        discount_percent = validators.percent(discount_percent, "Discount %")
        tax_percent = validators.percent(config.DEFAULT_TAX_PERCENT if tax_percent is None else tax_percent, "Tax %")
        sale_date = validators.date(sale_date or today_str(), "Sale date")
        merged = {}
        for product_id, qty in items:            # same product twice -> one line
            merged[product_id] = merged.get(product_id, 0) + validators.integer(qty, "Quantity", minimum=1)
        try:
            with self.db.transaction():
                if request_token and self.db.one("SELECT 1 FROM sales WHERE request_token = ?", (request_token,)):
                    raise DuplicateTransactionError("This sale was already recorded - it was not saved twice.")
                lines = []
                for product_id, qty in merged.items():
                    prod = self.db.one("SELECT id, name, selling_price, cost_price FROM products "
                                       "WHERE id = ? AND is_active = 1", (product_id,))
                    if prod is None:
                        raise ValidationError("One of the products no longer exists.")
                    lines.append((prod, qty))
                totals = calc_totals([(q, p["selling_price"]) for p, q in lines], discount_percent, tax_percent)
                cur = self.db.execute(
                    """INSERT INTO sales (invoice_no, customer_name, sale_date, subtotal, discount_percent,
                           discount_amount, tax_percent, tax_amount, total, status, request_token, created_by, created_at)
                       VALUES (?,?,?,?,?,?,?,?,?,'COMPLETED',?,?,?)""",
                    (f"TMP-{request_token or now_str()}", customer, sale_date, totals["subtotal"], discount_percent,
                     totals["discount_amount"], tax_percent, totals["tax_amount"], totals["total"],
                     request_token, user_id, now_str()))
                sale_id = cur.lastrowid
                invoice = f"INV-{sale_date[:4]}{sale_date[5:7]}-{sale_id:05d}"
                self.db.execute("UPDATE sales SET invoice_no = ? WHERE id = ?", (invoice, sale_id))
                for prod, qty in lines:
                    line_total = float(_round(_d(prod["selling_price"]) * qty))
                    item = self.db.execute(
                        """INSERT INTO sale_items (sale_id, product_id, quantity, unit_price, unit_cost, line_total)
                           VALUES (?,?,?,?,?,?)""",
                        (sale_id, prod["id"], qty, prod["selling_price"], prod["cost_price"], line_total))
                    apply_stock_change(self.db, prod["id"], -qty, "SALE", "sale", sale_id,
                                       f"Sold on {invoice}", user_id)
                self.db.log(user_id, "SALE_CREATED", f"{invoice} total {totals['total']}")
        except sqlite3.IntegrityError as exc:
            # only a clash on the request token means "submitted twice"; anything else is a real error
            if request_token and "request_token" in str(exc):
                raise DuplicateTransactionError("This sale was already recorded - it was not saved twice.") from None
            raise
        return sale_id

    # ---------- returns ----------
    def return_items(self, sale_id, quantities, reason, user_id=None):
        """quantities = {sale_item_id: quantity_to_return}. Restores stock and records a refund."""
        reason = validators.text(reason, "Reason", max_len=200)
        quantities = {k: v for k, v in quantities.items() if v}
        if not quantities:
            raise ValidationError("Enter a quantity to return for at least one item.")
        with self.db.transaction():
            sale = self.db.one("SELECT * FROM sales WHERE id = ?", (sale_id,))
            if sale is None:
                raise NotFoundError("Sale not found.")
            if sale["status"] in ("CANCELLED", "RETURNED"):
                raise BusinessRuleError(f"This sale is already {sale['status'].lower()}.")
            refund_total = Decimal(0)
            for item_id, qty in quantities.items():
                qty = validators.integer(qty, "Return quantity", minimum=1)
                item = self.db.one("SELECT * FROM sale_items WHERE id = ? AND sale_id = ?", (item_id, sale_id))
                if item is None:
                    raise NotFoundError("Sale item not found.")
                left = item["quantity"] - item["returned_qty"]
                if qty > left:
                    raise BusinessRuleError(f"Only {left} unit(s) of this item can still be returned.")
                net_unit = _d(item["unit_price"]) * (1 - _d(sale["discount_percent"]) / 100)
                refund = _round(net_unit * qty * (1 + _d(sale["tax_percent"]) / 100))
                refund_total += refund
                self.db.execute("UPDATE sale_items SET returned_qty = returned_qty + ? WHERE id = ?", (qty, item_id))
                self.db.execute(
                    """INSERT INTO sale_returns (sale_id, sale_item_id, quantity, refund_amount, reason,
                                                 performed_by, created_at) VALUES (?,?,?,?,?,?,?)""",
                    (sale_id, item_id, qty, float(refund), reason, user_id, now_str()))
                apply_stock_change(self.db, item["product_id"], qty, "RETURN", "sale", sale_id,
                                   f"Return on {sale['invoice_no']}: {reason}", user_id)
            remaining = self.db.scalar("SELECT SUM(quantity - returned_qty) FROM sale_items WHERE sale_id = ?",
                                       (sale_id,))
            self.db.execute("UPDATE sales SET status = ? WHERE id = ?",
                            ("RETURNED" if remaining == 0 else "PARTIAL_RETURN", sale_id))
            self.db.log(user_id, "SALE_RETURN", f"{sale['invoice_no']} refund {refund_total}")
        return float(refund_total)

    def cancel(self, sale_id, reason, user_id=None):
        """Return every remaining unit and mark the sale CANCELLED."""
        reason = validators.text(reason, "Reason", max_len=200)
        with self.db.transaction():
            sale = self.db.one("SELECT status FROM sales WHERE id = ?", (sale_id,))
            if sale is None:
                raise NotFoundError("Sale not found.")
            if sale["status"] in ("CANCELLED", "RETURNED"):
                raise BusinessRuleError(f"This sale is already {sale['status'].lower()}.")
            remaining = {r["id"]: r["quantity"] - r["returned_qty"] for r in
                         self.db.query("SELECT id, quantity, returned_qty FROM sale_items WHERE sale_id = ?",
                                       (sale_id,))}
            refund = self.return_items(sale_id, remaining, reason, user_id)
            self.db.execute("UPDATE sales SET status = 'CANCELLED' WHERE id = ?", (sale_id,))
            self.db.log(user_id, "SALE_CANCELLED", str(sale_id))
        return refund

    # ---------- reading ----------
    def get(self, sale_id):
        head = self.db.one("SELECT * FROM sales WHERE id = ?", (sale_id,))
        if head is None:
            raise NotFoundError("Sale not found.")
        items = [dict(r) for r in self.db.query(
            """SELECT i.*, p.sku, p.name FROM sale_items i JOIN products p ON p.id = i.product_id
               WHERE i.sale_id = ? ORDER BY i.id""", (sale_id,))]
        return {**dict(head), "items": items}

    def list(self, date_from=None, date_to=None, search="", status=None):
        sql = "SELECT id, invoice_no, sale_date, customer_name, subtotal, discount_amount, tax_amount, total, status FROM sales WHERE 1=1"
        params = []
        for clause, value in (("sale_date >= ?", date_from), ("sale_date <= ?", date_to), ("status = ?", status)):
            if value:
                sql += " AND " + clause
                params.append(value)
        if search.strip():
            sql += " AND (invoice_no LIKE ? OR customer_name LIKE ?)"
            params += [f"%{search.strip()}%"] * 2
        return [dict(r) for r in self.db.query(sql + " ORDER BY id DESC", params)]

    def invoice_text(self, sale_id):
        s = self.get(sale_id)
        cur, line = config.CURRENCY, "-" * 62
        out = [config.APP_NAME.center(62), "TAX INVOICE".center(62), line,
               f"Invoice : {s['invoice_no']}      Date: {s['sale_date']}",
               f"Customer: {s['customer_name']}      Status: {s['status']}", line,
               f"{'Item':<30}{'Qty':>5}{'Price':>13}{'Total':>14}"]
        for i in s["items"]:
            out.append(f"{(i['name'][:27] + '...') if len(i['name']) > 30 else i['name']:<30}"
                       f"{i['quantity']:>5}{i['unit_price']:>13,.2f}{i['line_total']:>14,.2f}")
            if i["returned_qty"]:
                out.append(f"   (returned: {i['returned_qty']})")
        out += [line, f"{'Subtotal':>48}{cur}{s['subtotal']:>12,.2f}",
                f"{'Discount (' + format(s['discount_percent'], 'g') + '%)':>48}-{cur}{s['discount_amount']:>11,.2f}",
                f"{'Tax (' + format(s['tax_percent'], 'g') + '%)':>48}{cur}{s['tax_amount']:>12,.2f}",
                f"{'TOTAL':>48}{cur}{s['total']:>12,.2f}", line, "Thank you for your business.".center(62)]
        return "\n".join(out)
