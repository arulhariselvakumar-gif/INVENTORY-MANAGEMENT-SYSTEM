"""Product CSV import / export."""
import csv
import os
import sqlite3

import validators
from errors import InventoryError, ValidationError
from services.master_service import CategoryService

COLUMNS = ["sku", "name", "category", "supplier", "cost_price", "selling_price", "quantity",
           "reorder_level", "description"]


class CsvService:
    def __init__(self, db, products):
        self.db, self.products = db, products

    def export_products(self, path):
        rows = self.products.list()
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "w", newline="", encoding="utf-8-sig") as fh:
            writer = csv.writer(fh)
            writer.writerow(COLUMNS)
            for p in rows:
                supplier = "" if p["supplier"] == "-" else p["supplier"]
                writer.writerow([p["sku"], p["name"], p["category"], supplier, p["cost_price"],
                                 p["selling_price"], p["quantity"], p["reorder_level"], p["description"]])
        return len(rows)

    def import_products(self, path, user_id=None):
        """Imports valid rows; returns (imported_count, [error messages]). Missing categories are created.
        Suppliers are matched by company name; an unknown supplier is reported as an error."""
        try:
            with open(path, newline="", encoding="utf-8-sig") as fh:
                reader = csv.DictReader(fh)
                missing = [c for c in ("sku", "name", "category", "cost_price", "selling_price") if c not in (reader.fieldnames or [])]
                if missing:
                    raise ValidationError("CSV is missing column(s): " + ", ".join(missing))
                rows = list(reader)
        except (OSError, UnicodeDecodeError, csv.Error) as exc:
            raise ValidationError(f"Could not read the CSV file: {exc}") from None
        categories, imported, errors = CategoryService(self.db), 0, []
        for line, row in enumerate(rows, start=2):
            try:
                supplier_id = None
                company = (row.get("supplier") or "").strip()
                if company:
                    found = self.db.one("SELECT id FROM suppliers WHERE company = ?", (company,))
                    if found is None:
                        raise ValidationError(f"unknown supplier '{company}'")
                    supplier_id = found["id"]
                self.products.add({
                    "sku": row.get("sku"), "name": row.get("name"), "description": row.get("description", ""),
                    "category_id": categories.get_or_create(row.get("category"), user_id),
                    "supplier_id": supplier_id, "cost_price": row.get("cost_price"),
                    "selling_price": row.get("selling_price"), "quantity": row.get("quantity") or 0,
                    "reorder_level": row.get("reorder_level") or 0}, user_id)
                imported += 1
            except (InventoryError, sqlite3.Error) as exc:
                errors.append(f"Line {line}: {exc}")
        return imported, errors
