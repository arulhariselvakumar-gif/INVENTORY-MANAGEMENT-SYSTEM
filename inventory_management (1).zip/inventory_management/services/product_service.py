"""Products: CRUD with validation, plus ProductIndex - the in-memory structures
(hash tables, BST, sorted lists) that power the Search & sort lab."""
import sqlite3
import time

import config
import validators
from database import now_str, today_str
from dsa.binary_search_tree import BinarySearchTree
from dsa.hash_table import HashTable
from dsa.searching import binary_search, linear_search, linear_search_all
from dsa.sorting import bubble_sort, merge_sort
from errors import (BusinessRuleError, DuplicateError, NotFoundError, ValidationError)
from services.inventory_service import STATUS_SQL, apply_stock_change

SORT_KEYS = {
    "name": lambda p: p["name"].lower(),
    "price": lambda p: p["selling_price"],
    "quantity": lambda p: p["quantity"],
    "stock_value": lambda p: p["stock_value"],
}
_BASE_SQL = f"""SELECT p.*, c.name AS category, COALESCE(s.company, '-') AS supplier,
                       ROUND(p.quantity * p.cost_price, 2) AS stock_value, {STATUS_SQL} AS status
                FROM products p JOIN categories c ON c.id = p.category_id
                LEFT JOIN suppliers s ON s.id = p.supplier_id"""


class ProductService:
    def __init__(self, db):
        self.db = db

    # ---------- reading ----------
    def get(self, product_id):
        row = self.db.one(_BASE_SQL + " WHERE p.id = ?", (product_id,))
        if row is None:
            raise NotFoundError("Product not found.")
        return dict(row)

    def list(self, search="", category_id=None, supplier_id=None, status=None, include_inactive=False):
        sql, params, where = _BASE_SQL, [], []
        if not include_inactive:
            where.append("p.is_active = 1")
        if search.strip():
            like = f"%{search.strip()}%"
            where.append("(p.product_code LIKE ? OR p.sku LIKE ? OR p.name LIKE ? OR c.name LIKE ?)")
            params += [like] * 4
        if category_id:
            where.append("p.category_id = ?")
            params.append(category_id)
        if supplier_id:
            where.append("p.supplier_id = ?")
            params.append(supplier_id)
        if status in ("OK", "LOW", "OUT"):
            where.append(f"{STATUS_SQL} = ?")
            params.append(status)
        if where:
            sql += " WHERE " + " AND ".join(where)
        return [dict(r) for r in self.db.query(sql + " ORDER BY p.name", params)]

    def build_index(self):
        return ProductIndex(self.list())

    # ---------- validation ----------
    def _clean(self, data):
        category_id = data.get("category_id")
        if not category_id:
            raise ValidationError("Choose a category.")
        if self.db.one("SELECT 1 FROM categories WHERE id = ?", (category_id,)) is None:
            raise ValidationError("The selected category no longer exists.")
        supplier_id = data.get("supplier_id") or None
        if supplier_id and self.db.one("SELECT 1 FROM suppliers WHERE id = ?", (supplier_id,)) is None:
            raise ValidationError("The selected supplier no longer exists.")
        return {
            "name": validators.text(data.get("name"), "Product name", max_len=100),
            "sku": validators.sku(data.get("sku")),
            "description": validators.text(data.get("description"), "Description", required=False, max_len=300),
            "category_id": category_id,
            "supplier_id": supplier_id,
            "cost_price": validators.money(data.get("cost_price"), "Cost price"),
            "selling_price": validators.money(data.get("selling_price"), "Selling price"),
            "reorder_level": validators.integer(data.get("reorder_level", 0), "Reorder level"),
        }

    def _next_code(self):
        last = self.db.scalar("SELECT MAX(CAST(SUBSTR(product_code, 2) AS INTEGER)) FROM products")
        return f"P{last + 1:04d}"

    # ---------- writing ----------
    def add(self, data, user_id=None):
        clean = self._clean(data)
        qty = validators.integer(data.get("quantity", 0), "Opening quantity")
        try:
            with self.db.transaction():
                cur = self.db.execute(
                    """INSERT INTO products (product_code, sku, name, description, category_id, supplier_id,
                                             cost_price, selling_price, quantity, reorder_level, date_added)
                       VALUES (?,?,?,?,?,?,?,?,0,?,?)""",
                    (self._next_code(), clean["sku"], clean["name"], clean["description"], clean["category_id"],
                     clean["supplier_id"], clean["cost_price"], clean["selling_price"],
                     clean["reorder_level"], today_str()))
                pid = cur.lastrowid
                if qty > 0:   # stock always enters through a movement so history stays complete
                    apply_stock_change(self.db, pid, qty, "OPENING", "product", pid,
                                       "Opening stock", user_id)
                self.db.log(user_id, "PRODUCT_ADDED", f"{clean['sku']} {clean['name']} (opening {qty})")
        except sqlite3.IntegrityError:
            raise DuplicateError(f"SKU '{clean['sku']}' is already used by another product.") from None
        return pid

    def update(self, product_id, data, user_id=None):
        """Edit details (not stock - use a stock adjustment). Returns the OLD values for undo."""
        old = self.get(product_id)
        clean = self._clean(data)
        self._write(product_id, clean, user_id, "PRODUCT_UPDATED")
        return old

    def restore(self, product_id, old, user_id=None):
        """Put back previously saved details (used by Undo)."""
        keys = ("name", "sku", "description", "category_id", "supplier_id",
                "cost_price", "selling_price", "reorder_level")
        self._write(product_id, {k: old[k] for k in keys}, user_id, "PRODUCT_RESTORED")

    def _write(self, product_id, clean, user_id, action):
        try:
            with self.db.transaction():
                self.db.execute(
                    """UPDATE products SET name=?, sku=?, description=?, category_id=?, supplier_id=?,
                       cost_price=?, selling_price=?, reorder_level=? WHERE id=?""",
                    (clean["name"], clean["sku"], clean["description"], clean["category_id"],
                     clean["supplier_id"], clean["cost_price"], clean["selling_price"],
                     clean["reorder_level"], product_id))
                self.db.log(user_id, action, f"{clean['sku']} {clean['name']}")
        except sqlite3.IntegrityError:
            raise DuplicateError(f"SKU '{clean['sku']}' is already used by another product.") from None

    def delete(self, product_id, user_id=None):
        """Products never used in a purchase or sale are removed; the rest are archived
        (hidden but kept) so old invoices and reports stay correct. Returns 'deleted'/'archived'."""
        prod = self.get(product_id)
        used = self.db.scalar("SELECT (SELECT COUNT(*) FROM sale_items WHERE product_id = :p) + "
                              "(SELECT COUNT(*) FROM purchase_items WHERE product_id = :p)", {"p": product_id})
        with self.db.transaction():
            if used:
                self.db.execute("UPDATE products SET is_active = 0 WHERE id = ?", (product_id,))
                self.db.execute("UPDATE restock_tasks SET status='DONE' WHERE product_id=? AND status='PENDING'",
                                (product_id,))
                result = "archived"
            else:
                self.db.execute("DELETE FROM products WHERE id = ?", (product_id,))
                result = "deleted"
            self.db.log(user_id, f"PRODUCT_{result.upper()}", f"{prod['sku']} {prod['name']}")
        return result


class ProductIndex:
    """Snapshot of the product list with the teaching data structures built on top of it."""

    def __init__(self, products):
        self.products = list(products)                       # plain list (array) in DB order
        self.by_sku, self.by_id = HashTable(), HashTable()   # hash tables
        for p in self.products:
            self.by_sku.put(p["sku"].upper(), p)
            self.by_id.put(p["id"], p)
        self.name_tree = BinarySearchTree.build_balanced([(p["name"].lower(), p) for p in self.products])
        self._sorted = {}

    # each search returns {"results": [...], "comparisons": int, "method": str, "complexity": str, "micros": float}
    def _result(self, results, comparisons, method, complexity, started):
        return {"results": results, "comparisons": comparisons, "method": method,
                "complexity": complexity, "micros": round((time.perf_counter() - started) * 1e6, 1)}

    def hash_lookup(self, field, value):
        started = time.perf_counter()
        if field == "id":
            try:
                found = self.by_id.get(int(value))
            except ValueError:
                found = None
        else:
            found = self.by_sku.get(str(value).strip().upper())
        return self._result([found] if found else [], 1, "Hash table lookup", "O(1) average", started)

    def linear(self, field, value):
        started = time.perf_counter()
        value = str(value).strip().lower()
        getter = {"id": lambda p: str(p["id"]), "sku": lambda p: p["sku"].lower(),
                  "name": lambda p: p["name"].lower()}[field]
        if field == "name":     # names may repeat, so collect every match
            found = linear_search_all(self.products, lambda p: getter(p) == value)
            return self._result(found, len(self.products), "Linear search", "O(n)", started)
        idx, comps = linear_search(self.products, value, key=getter)
        return self._result([self.products[idx]] if idx >= 0 else [], comps, "Linear search", "O(n)", started)

    def _sorted_by(self, field):
        if field not in self._sorted:       # sorted once with our merge sort, then reused
            getter = {"id": lambda p: p["id"], "sku": lambda p: p["sku"].lower(),
                      "name": lambda p: p["name"].lower()}[field]
            self._sorted[field] = (merge_sort(self.products, key=getter), getter)
        return self._sorted[field]

    def binary(self, field, value):
        started = time.perf_counter()
        ordered, getter = self._sorted_by(field)
        try:
            target = int(value) if field == "id" else str(value).strip().lower()
        except ValueError:
            return self._result([], 0, "Binary search", "O(log n)", started)
        idx, comps = binary_search(ordered, target, key=getter)
        found = []
        if idx >= 0:                        # names can repeat: walk outwards from the hit
            lo = hi = idx
            while lo > 0 and getter(ordered[lo - 1]) == target:
                lo -= 1
            while hi < len(ordered) - 1 and getter(ordered[hi + 1]) == target:
                hi += 1
            found = ordered[lo:hi + 1]
        return self._result(found, comps, "Binary search (on sorted data)", "O(log n)", started)

    def name_prefix(self, prefix):
        started = time.perf_counter()
        found = self.name_tree.prefix_search(prefix.strip().lower())
        return self._result(found, self.name_tree.height(), "BST prefix search",
                            "O(h + k)  (h = tree height, k = matches)", started)

    def sort(self, key_name, algorithm, descending=False):
        if algorithm == "bubble" and len(self.products) > config.BUBBLE_SORT_LIMIT:
            raise BusinessRuleError(
                f"Bubble sort is O(n^2); it is limited to {config.BUBBLE_SORT_LIMIT} products "
                f"(you have {len(self.products)}). Use merge sort instead.")
        started, stats = time.perf_counter(), {}
        func = bubble_sort if algorithm == "bubble" else merge_sort
        ordered = func(self.products, key=SORT_KEYS[key_name], reverse=descending, stats=stats)
        complexity = "O(n^2) average/worst, O(n) best" if algorithm == "bubble" else "O(n log n) always"
        name = "Bubble sort" if algorithm == "bubble" else "Merge sort"
        return self._result(ordered, stats["comparisons"], name, complexity, started)
