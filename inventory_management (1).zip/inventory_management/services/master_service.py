"""Categories and suppliers."""
import sqlite3

import validators
from database import now_str
from errors import BusinessRuleError, DuplicateError, NotFoundError


class CategoryService:
    def __init__(self, db):
        self.db = db

    def list(self):
        return [dict(r) for r in self.db.query(
            """SELECT c.id, c.name, c.description, COUNT(p.id) AS product_count
               FROM categories c LEFT JOIN products p ON p.category_id = c.id AND p.is_active = 1
               GROUP BY c.id ORDER BY c.name""")]

    def get(self, category_id):
        row = self.db.one("SELECT * FROM categories WHERE id = ?", (category_id,))
        if row is None:
            raise NotFoundError("Category not found.")
        return dict(row)

    def get_or_create(self, name, user_id=None):
        name = validators.text(name, "Category name", max_len=60)
        row = self.db.one("SELECT id FROM categories WHERE name = ?", (name,))
        return row["id"] if row else self.add(name, "", user_id)

    def add(self, name, description="", user_id=None):
        name = validators.text(name, "Category name", max_len=60)
        description = validators.text(description, "Description", required=False, max_len=200)
        try:
            with self.db.transaction():
                cur = self.db.execute("INSERT INTO categories (name, description) VALUES (?,?)",
                                      (name, description))
                self.db.log(user_id, "CATEGORY_ADDED", name)
        except sqlite3.IntegrityError:
            raise DuplicateError(f"A category named '{name}' already exists.") from None
        return cur.lastrowid

    def update(self, category_id, name, description="", user_id=None):
        name = validators.text(name, "Category name", max_len=60)
        description = validators.text(description, "Description", required=False, max_len=200)
        self.get(category_id)
        try:
            with self.db.transaction():
                self.db.execute("UPDATE categories SET name=?, description=? WHERE id=?",
                                (name, description, category_id))
                self.db.log(user_id, "CATEGORY_UPDATED", name)
        except sqlite3.IntegrityError:
            raise DuplicateError(f"A category named '{name}' already exists.") from None

    def delete(self, category_id, reassign_to=None, user_id=None):
        """A category still used by products can only be removed if they are reassigned."""
        cat = self.get(category_id)
        in_use = self.db.scalar("SELECT COUNT(*) FROM products WHERE category_id = ?", (category_id,))
        if in_use and reassign_to is None:
            raise BusinessRuleError(
                f"'{cat['name']}' is used by {in_use} product(s). Choose another category to move them to.")
        if reassign_to == category_id:
            raise BusinessRuleError("Choose a different category to reassign to.")
        if reassign_to is not None:
            self.get(reassign_to)
        with self.db.transaction():
            if in_use:
                self.db.execute("UPDATE products SET category_id = ? WHERE category_id = ?",
                                (reassign_to, category_id))
            self.db.execute("DELETE FROM categories WHERE id = ?", (category_id,))
            self.db.log(user_id, "CATEGORY_DELETED", f"{cat['name']} ({in_use} product(s) reassigned)")
        return in_use


class SupplierService:
    def __init__(self, db):
        self.db = db

    def _clean(self, data):
        return (validators.text(data.get("name"), "Contact name", max_len=80),
                validators.text(data.get("company"), "Company name", max_len=100),
                validators.phone(data.get("phone"), required=True),
                validators.email(data.get("email")),
                validators.text(data.get("address"), "Address", required=False, max_len=200))

    def list(self, search=""):
        like = f"%{search.strip()}%"
        return [dict(r) for r in self.db.query(
            """SELECT s.*, COUNT(p.id) AS product_count
               FROM suppliers s LEFT JOIN products p ON p.supplier_id = s.id AND p.is_active = 1
               WHERE s.name LIKE ? OR s.company LIKE ? OR s.phone LIKE ? OR s.email LIKE ?
               GROUP BY s.id ORDER BY s.company""", (like, like, like, like))]

    def get(self, supplier_id):
        row = self.db.one("SELECT * FROM suppliers WHERE id = ?", (supplier_id,))
        if row is None:
            raise NotFoundError("Supplier not found.")
        return dict(row)

    def add(self, data, user_id=None):
        values = self._clean(data)
        try:
            with self.db.transaction():
                cur = self.db.execute(
                    "INSERT INTO suppliers (name, company, phone, email, address, created_at) VALUES (?,?,?,?,?,?)",
                    values + (now_str(),))
                self.db.log(user_id, "SUPPLIER_ADDED", values[1])
        except sqlite3.IntegrityError:
            raise DuplicateError(f"A supplier from '{values[1]}' already exists.") from None
        return cur.lastrowid

    def update(self, supplier_id, data, user_id=None):
        values = self._clean(data)
        self.get(supplier_id)
        try:
            with self.db.transaction():
                self.db.execute(
                    "UPDATE suppliers SET name=?, company=?, phone=?, email=?, address=? WHERE id=?",
                    values + (supplier_id,))
                self.db.log(user_id, "SUPPLIER_UPDATED", values[1])
        except sqlite3.IntegrityError:
            raise DuplicateError(f"A supplier from '{values[1]}' already exists.") from None

    def delete(self, supplier_id, user_id=None):
        sup = self.get(supplier_id)
        if self.db.scalar("SELECT COUNT(*) FROM purchases WHERE supplier_id = ?", (supplier_id,)):
            raise BusinessRuleError("This supplier has purchase records and cannot be deleted.")
        if self.db.scalar("SELECT COUNT(*) FROM products WHERE supplier_id = ?", (supplier_id,)):
            raise BusinessRuleError("Products are still linked to this supplier. Change them first.")
        with self.db.transaction():
            self.db.execute("DELETE FROM suppliers WHERE id = ?", (supplier_id,))
            self.db.log(user_id, "SUPPLIER_DELETED", sup["company"])
