"""Input validation helpers. Every function returns a cleaned value or raises ValidationError."""
import re
from datetime import datetime
from errors import ValidationError

_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
_PHONE = re.compile(r"^[0-9+\-\s()]{7,15}$")
_SKU = re.compile(r"^[A-Za-z0-9][A-Za-z0-9\-_]{1,31}$")


def text(value, label, required=True, max_len=120):
    value = (value or "").strip()
    if required and not value:
        raise ValidationError(f"{label} is required.")
    if len(value) > max_len:
        raise ValidationError(f"{label} must be at most {max_len} characters.")
    return value


def sku(value):
    value = text(value, "SKU", max_len=32).upper()
    if not _SKU.match(value):
        raise ValidationError("SKU must be 2-32 characters: letters, digits, '-' or '_'.")
    return value


def money(value, label, allow_zero=True):
    try:
        number = float(str(value).replace(",", "").strip())
    except (TypeError, ValueError):
        raise ValidationError(f"{label} must be a number.") from None
    if number != number or number in (float("inf"), float("-inf")):
        raise ValidationError(f"{label} must be a real number.")
    if number < 0 or (number == 0 and not allow_zero):
        raise ValidationError(f"{label} must be {'zero or more' if allow_zero else 'greater than zero'}.")
    if number > 100_000_000:
        raise ValidationError(f"{label} is unrealistically large.")
    return round(number, 2)


def integer(value, label, minimum=0, maximum=10_000_000):
    raw = str(value).strip()
    if not re.fullmatch(r"-?\d+", raw):
        raise ValidationError(f"{label} must be a whole number.")
    number = int(raw)
    if number < minimum:
        raise ValidationError(f"{label} must be at least {minimum}.")
    if number > maximum:
        raise ValidationError(f"{label} must be at most {maximum}.")
    return number


def percent(value, label):
    number = money(value, label)
    if number > 100:
        raise ValidationError(f"{label} cannot be more than 100.")
    return number


def email(value, required=False):
    value = text(value, "Email", required=required, max_len=120)
    if value and not _EMAIL.match(value):
        raise ValidationError("Email address looks invalid (example: name@company.com).")
    return value


def phone(value, required=False):
    value = text(value, "Phone", required=required, max_len=20)
    if value and not _PHONE.match(value):
        raise ValidationError("Phone must have 7-15 digits (you may use + - ( ) and spaces).")
    return value


def date(value, label="Date"):
    value = text(value, label, max_len=10)
    try:
        return datetime.strptime(value, "%Y-%m-%d").strftime("%Y-%m-%d")
    except ValueError:
        raise ValidationError(f"{label} must be in YYYY-MM-DD format.") from None


def password(value):
    if len(value or "") < 8:
        raise ValidationError("Password must be at least 8 characters.")
    if not (any(c.isalpha() for c in value) and any(c.isdigit() for c in value)):
        raise ValidationError("Password must contain both letters and digits.")
    return value
