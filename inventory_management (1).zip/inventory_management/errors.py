"""Small exception hierarchy so the UI can show friendly messages."""


class InventoryError(Exception):
    """Base class: the message is always safe to show to the user."""


class ValidationError(InventoryError):
    """User typed something invalid."""


class NotFoundError(InventoryError):
    """A requested record does not exist."""


class DuplicateError(InventoryError):
    """A unique value (SKU, name, ...) is already in use."""


class InsufficientStockError(InventoryError):
    """The operation would make stock negative."""


class BusinessRuleError(InventoryError):
    """The action is not allowed in the record's current state."""


class DuplicateTransactionError(InventoryError):
    """The same transaction was submitted twice."""


class AuthError(InventoryError):
    """Login failed or account is temporarily locked."""
