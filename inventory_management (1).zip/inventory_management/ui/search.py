import tkinter as tk
from tkinter import ttk

from errors import BusinessRuleError, ValidationError
from services.product_service import ProductIndex
from ui.screen import Screen, safe
from ui.theme import C, font
from ui.widgets import DataTable, FlatButton, IdCombo, field

FIELDS = [("Product ID", "id"), ("SKU", "sku"), ("Name", "name")]
METHODS = ["Linear search", "Binary search", "Hash table lookup", "BST prefix search"]
SORT_KEYS = [("Name", "name"), ("Price", "price"), ("Quantity", "quantity"), ("Stock value", "stock_value")]
STATUS = [("All stock levels", None), ("In stock", "OK"), ("Low", "LOW"), ("Out of stock", "OUT")]
WHY = {
    "Linear search": "Checks products one by one from the start. Works on any order, but slows down as the list grows.",
    "Binary search": "Needs data sorted by the searched field (we merge-sort it first). Halves the search range every step.",
    "Hash table lookup": "Turns the SKU or ID into a bucket number and jumps straight there. Only for exact ID or SKU.",
    "BST prefix search": "Walks a binary search tree of product names and skips whole branches that cannot match. Name prefix only.",
    "Bubble sort": "Swaps neighbours until nothing moves. Simple to understand, but slow on big lists (limited here).",
    "Merge sort": "Splits the list in halves, sorts each, merges them. Reliably fast, used for all large lists.",
}


class SearchScreen(Screen):
    title = "Search and sort lab"
    subtitle = "Run the course algorithms on your real product data and compare how much work each one does."

    def build(self, parent):
        flt = ttk.Frame(parent)
        flt.pack(fill="x", pady=(0, 10))
        ttk.Label(flt, text="Work on:", style="Muted.TLabel").pack(side="left", padx=(0, 8))
        self.category, self.supplier = IdCombo(flt, width=20), IdCombo(flt, width=24)
        self.status = ttk.Combobox(flt, state="readonly", width=16, values=[t for t, _ in STATUS])
        self.status.current(0)
        for w in (self.category, self.supplier, self.status):
            w.pack(side="left", padx=(0, 8))
        self.size = ttk.Label(flt, text="", style="Muted.TLabel")
        self.size.pack(side="left", padx=8)

        cards = ttk.Frame(parent)
        cards.pack(fill="x")
        cards.columnconfigure((0, 1), weight=1, uniform="c")
        s = ttk.Frame(cards, style="Card.TFrame", padding=14)
        s.grid(row=0, column=0, sticky="nsew", padx=(0, 12))
        s.columnconfigure((0, 1), weight=1, uniform="a")
        ttk.Label(s, text="Search", style="CardH2.TLabel").grid(row=0, column=0, sticky="w", pady=(0, 6))
        self.field_box = field(s, 1, "Search by", ttk.Combobox(s, state="readonly", values=[t for t, _ in FIELDS]), 0)
        self.field_box.current(1)
        self.method = field(s, 1, "Algorithm", ttk.Combobox(s, state="readonly", values=METHODS), 1)
        self.method.current(2)
        self.query = tk.StringVar()
        entry = field(s, 2, "Value to find", ttk.Entry(s, textvariable=self.query), 0, span=2)
        entry.bind("<Return>", lambda e: self.run_search())
        FlatButton(s, "Run search", self.run_search).grid(row=6, column=0, sticky="w")

        o = ttk.Frame(cards, style="Card.TFrame", padding=14)
        o.grid(row=0, column=1, sticky="nsew")
        o.columnconfigure((0, 1, 2), weight=1, uniform="b")
        ttk.Label(o, text="Sort", style="CardH2.TLabel").grid(row=0, column=0, sticky="w", pady=(0, 6))
        self.sort_key = field(o, 1, "Sort by", ttk.Combobox(o, state="readonly", values=[t for t, _ in SORT_KEYS]), 0)
        self.sort_key.current(0)
        self.sort_algo = field(o, 1, "Algorithm", ttk.Combobox(o, state="readonly", values=["Merge sort", "Bubble sort"]), 1)
        self.sort_algo.current(0)
        self.sort_order = field(o, 1, "Order", ttk.Combobox(o, state="readonly", values=["Ascending", "Descending"]), 2)
        self.sort_order.current(0)
        FlatButton(o, "Run sort", self.run_sort).grid(row=6, column=0, sticky="w")

        self.info = tk.Label(parent, text="Pick an algorithm and run it. The work done is shown here.", bg=C["bg"], fg=C["text"],
                             font=font(10, "bold"), anchor="w", justify="left", wraplength=1000)
        self.info.pack(fill="x", pady=(12, 0))
        self.why = tk.Label(parent, text="", bg=C["bg"], fg=C["muted"], anchor="w", justify="left", wraplength=1000)
        self.why.pack(fill="x", pady=(0, 6))
        self.table = DataTable(parent, [("sku", "SKU", 100, "w", None), ("name", "Product", 200, "w", None),
                                        ("category", "Category", 120, "w", None), ("supplier", "Supplier", 150, "w", None),
                                        ("quantity", "Qty", 55, "e", None), ("selling_price", "Price", 85, "e", lambda v: f"{v:,.2f}"),
                                        ("stock_value", "Stock value", 100, "e", lambda v: f"{v:,.2f}"),
                                        ("status", "Status", 70, "w", None)], height=9,
                               tag_func=lambda r: {"LOW": "low", "OUT": "out"}.get(r["status"], ""),
                               empty_text="Results appear here.")
        self.table.pack(fill="both", expand=True)

    def on_show(self, **_):
        self.category.set_items(self.cat_pairs(self.svc), first="All categories")
        self.supplier.set_items(self.sup_pairs(self.svc), first="All suppliers")

    def _index(self):
        status = STATUS[max(self.status.current(), 0)][1]
        products = self.svc.products.list(category_id=self.category.get_id(), supplier_id=self.supplier.get_id(), status=status)
        self.size.configure(text=f"{len(products)} product(s) in the data set")
        return ProductIndex(products)

    def _show(self, res, extra=""):
        n = len(res["results"])
        self.info.configure(text=f"{res['method']}: {n} result(s)   |   comparisons / steps: {res['comparisons']}   |   "
                                 f"time: {res['micros']} microseconds   |   complexity: {res['complexity']}{extra}")
        self.why.configure(text=WHY.get(res["method"].split(" (")[0], ""))
        self.table.set_rows(res["results"])
        if n == 0:
            self.app.toast("Not found - no product matches that value.", "warn")

    @safe
    def run_search(self):
        value = self.query.get().strip()
        if not value:
            raise ValidationError("Type the value you want to find.")
        fld = FIELDS[max(self.field_box.current(), 0)][1]
        method = METHODS[max(self.method.current(), 0)]
        index = self._index()
        if method == "Hash table lookup":
            if fld == "name":
                raise BusinessRuleError("Hash lookup needs an exact ID or SKU. Use BST prefix search or linear search for names.")
            res = index.hash_lookup(fld, value)
        elif method == "BST prefix search":
            if fld != "name":
                raise BusinessRuleError("The tree is built on product names. Set 'Search by' to Name.")
            res = index.name_prefix(value)
        elif method == "Binary search":
            res = index.binary(fld, value)
        else:
            res = index.linear(fld, value)
        extra = f"   |   products scanned at most: {len(index.products)}" if method == "Linear search" else ""
        self._show(res, extra)

    @safe
    def run_sort(self):
        key = SORT_KEYS[max(self.sort_key.current(), 0)][1]
        algo = "bubble" if self.sort_algo.current() == 1 else "merge"
        res = self._index().sort(key, algo, descending=self.sort_order.current() == 1)
        self._show(res)
