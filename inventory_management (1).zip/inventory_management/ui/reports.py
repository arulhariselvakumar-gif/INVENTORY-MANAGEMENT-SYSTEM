import os
import tkinter as tk
from datetime import date, timedelta
from tkinter import filedialog, ttk

import config
from services.charts import sales_trend_figure, stock_distribution_figure
from services.report_service import ReportService
from ui.screen import Screen, safe
from ui.theme import C, font
from ui.widgets import DataTable, FlatButton


def _fmt(value):
    return f"{value:,.2f}" if isinstance(value, float) else value


class ReportsScreen(Screen):
    title = "Reports and charts"
    subtitle = "Choose a report, set the dates if it uses them, and export it as CSV."

    def build(self, parent):
        bar = ttk.Frame(parent)
        bar.pack(fill="x", pady=(0, 10))
        self.report = ttk.Combobox(bar, state="readonly", width=26, values=list(ReportService.REPORTS))
        self.report.current(0)
        self.report.pack(side="left", padx=(0, 8))
        self.report.bind("<<ComboboxSelected>>", lambda e: self.generate())
        self.from_var, self.to_var = tk.StringVar(), tk.StringVar()
        ttk.Label(bar, text="From", style="Muted.TLabel").pack(side="left")
        ttk.Entry(bar, textvariable=self.from_var, width=12).pack(side="left", padx=(4, 8))
        ttk.Label(bar, text="To", style="Muted.TLabel").pack(side="left")
        ttk.Entry(bar, textvariable=self.to_var, width=12).pack(side="left", padx=(4, 8))
        FlatButton(bar, "Last 30 days", self.last_30, kind="quiet").pack(side="left", padx=(0, 8))
        FlatButton(bar, "Show report", self.generate).pack(side="left")
        FlatButton(bar, "Export CSV", self.export, kind="amber").pack(side="right")
        ttk.Label(parent, text="Dates are YYYY-MM-DD and apply to purchase, sales, best-seller, supplier and profit reports. "
                               "Leave empty for all time.", style="Muted.TLabel").pack(anchor="w", pady=(0, 8))

        self.tabs = ttk.Notebook(parent)
        self.tabs.pack(fill="both", expand=True)
        self.table_tab = ttk.Frame(self.tabs, style="Card.TFrame", padding=12)
        self.chart_tab = ttk.Frame(self.tabs, style="Card.TFrame", padding=12)
        self.tabs.add(self.table_tab, text="Report")
        self.tabs.add(self.chart_tab, text="Charts")
        self.table = None
        self.summary = tk.Label(self.table_tab, text="", bg=C["card"], fg=C["muted"], anchor="w", justify="left", wraplength=980)
        self.summary.pack(side="bottom", fill="x", pady=(8, 0))
        self.table_holder = ttk.Frame(self.table_tab, style="Card.TFrame")
        self.table_holder.pack(fill="both", expand=True)
        self.chart_tab.columnconfigure((0, 1), weight=1, uniform="ch")
        self.chart_tab.rowconfigure(0, weight=1)
        self._canvases = []
        self._current = None

    def on_show(self, **_):
        self.generate()

    def last_30(self):
        self.to_var.set(date.today().isoformat())
        self.from_var.set((date.today() - timedelta(days=30)).isoformat())
        self.generate()

    @safe
    def generate(self):
        report = self.svc.reports.run(self.report.get(), self.from_var.get().strip() or None, self.to_var.get().strip() or None)
        self._current = report
        if self.table is not None:
            self.table.destroy()
        cols = [(k, h, 110 if k not in ("name", "supplier", "customer_name") else 190,
                 "e" if any(t in k for t in ("price", "cost", "value", "total", "revenue", "profit", "units", "qty", "quantity",
                                              "spent", "margin", "opening", "received", "sold", "returned", "adjusted", "current", "reorder", "amount", "tax", "discount", "subtotal", "purchases", "products"))
                 else "w", _fmt) for k, h in report["columns"]]
        self.table = DataTable(self.table_holder, cols, height=14,
                               tag_func=lambda r: {"LOW": "low", "OUT": "out"}.get(r.get("status"), ""),
                               empty_text="No records for this report and date range.")
        self.table.pack(fill="both", expand=True)
        self.table.set_rows(report["rows"])
        self.summary.configure(text=report["summary"])
        self.draw_charts()

    def draw_charts(self):
        from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg      # imported late: only needed here
        for canvas in self._canvases:
            canvas.get_tk_widget().destroy()
        self._canvases = []
        try:
            figs = [stock_distribution_figure(self.svc.reports.stock_by_category()),
                    sales_trend_figure(self.svc.reports.sales_trend(self.from_var.get().strip() or None,
                                                                    self.to_var.get().strip() or None))]
        except Exception:
            figs = [stock_distribution_figure(self.svc.reports.stock_by_category()), sales_trend_figure([])]
        for i, fig in enumerate(figs):
            canvas = FigureCanvasTkAgg(fig, master=self.chart_tab)
            canvas.get_tk_widget().grid(row=0, column=i, sticky="nsew", padx=(0, 8) if i == 0 else 0)
            canvas.draw()
            self._canvases.append(canvas)

    @safe
    def export(self):
        if self._current is None:
            self.generate()
        name = self.report.get().lower().replace(" ", "_").replace("-", "_") + ".csv"
        path = filedialog.asksaveasfilename(parent=self.app, defaultextension=".csv", initialdir=config.EXPORT_DIR,
                                            initialfile=name, filetypes=[("CSV file", "*.csv")])
        if path:
            n = self.svc.reports.export_csv(self._current, path)
            self.app.toast(f"Exported {n} rows")
