"""Reusable widgets: animated buttons, sortable table, id-combobox, dialogs, count-up numbers."""
import tkinter as tk
from tkinter import ttk

from dsa.sorting import merge_sort
from ui.theme import C, font


def _rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def mix(c1, c2, t):
    a, b = _rgb(c1), _rgb(c2)
    return "#%02x%02x%02x" % tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3))


class FlatButton(tk.Label):
    """A label that behaves like a button; its colour fades smoothly on hover."""
    KINDS = {"primary": (C["accent"], C["accent_dark"], "white"),
             "ghost": (C["grey_bg"], C["line"], C["text"]),
             "danger": (C["danger"], C["danger_dark"], "white"),
             "quiet": (C["card"], C["grey_bg"], C["accent"]),
             "amber": (C["amber"], "#c98f12", C["ink"])}

    def __init__(self, master, text, command=None, kind="primary", **kw):
        self.base, self.hover, fg = self.KINDS[kind]
        super().__init__(master, text=text, bg=self.base, fg=fg, font=font(10, "bold"), padx=14, pady=7,
                         cursor="hand2", takefocus=1, **kw)
        self._kind, self._fg, self._command = kind, fg, command
        self._current, self._job, self._enabled, self._inside = self.base, None, True, False
        self.bind("<Enter>", lambda e: self._enter())
        self.bind("<Leave>", lambda e: self._leave())
        self.bind("<ButtonPress-1>", lambda e: self._paint(mix(self.hover, "#000000", 0.12)))
        self.bind("<ButtonRelease-1>", lambda e: self._release())
        self.bind("<Return>", lambda e: self.invoke())
        self.bind("<space>", lambda e: self.invoke())

    def _enter(self):
        self._inside = True
        if self._enabled:
            self._fade(self.hover)

    def _leave(self):
        self._inside = False
        if self._enabled:
            self._fade(self.base)

    def _release(self):
        if self._enabled and self._inside:
            self._paint(self.hover)
            self.invoke()

    def _paint(self, colour):
        self._current = colour
        self.configure(bg=colour)

    def _fade(self, target, steps=6):
        if self._job:
            self.after_cancel(self._job)
        start = self._current

        def step(i=1):
            self._paint(mix(start, target, i / steps))
            self._job = self.after(14, step, i + 1) if i < steps else None
        step()

    def invoke(self):
        if self._enabled and self._command:
            self._command()

    def set_enabled(self, enabled):
        self._enabled = enabled
        if enabled:
            self.configure(fg=self._fg, cursor="hand2")
            self._paint(self.base)
        else:
            self.configure(fg="#8a9591", cursor="arrow")
            self._paint(C["grey_bg"])

    def set_text(self, text):
        self.configure(text=text)


class DataTable(ttk.Frame):
    """Treeview with scrollbars, click-to-sort headers (using OUR merge sort), striping and an empty state.
    columns = [(key, heading, width, anchor, formatter_or_None)]"""

    def __init__(self, master, columns, height=10, on_select=None, on_double=None, tag_func=None,
                 empty_text="Nothing to show yet."):
        super().__init__(master)
        self.columns, self.tag_func, self.on_select = columns, tag_func, on_select
        self._rows, self._shown, self._sort_key, self._descending = [], {}, None, False
        keys = [c[0] for c in columns]
        self.tree = ttk.Treeview(self, columns=keys, show="headings", height=height, selectmode="browse")
        for key, heading, width, anchor, _ in columns:
            self.tree.heading(key, text=heading, command=lambda k=key: self._sort_by(k))
            self.tree.column(key, width=width, minwidth=50, anchor=anchor, stretch=True)
        vbar = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        hbar = ttk.Scrollbar(self, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vbar.set, xscrollcommand=hbar.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vbar.grid(row=0, column=1, sticky="ns")
        hbar.grid(row=1, column=0, sticky="ew")
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)
        self.tree.tag_configure("odd", background=C["stripe"])
        self.tree.tag_configure("low", background=C["warn_bg"])
        self.tree.tag_configure("out", background=C["out_bg"])
        self.tree.tag_configure("done", foreground=C["muted"])
        self.empty = tk.Label(self.tree, text=empty_text, bg="white", fg=C["muted"], font=font(10))
        if on_select:
            self.tree.bind("<<TreeviewSelect>>", lambda e: on_select(self.selected()))
        if on_double:
            self.tree.bind("<Double-1>", lambda e: on_double(self.selected()))

    @staticmethod
    def _sort_value(value):
        if value is None:
            value = ""
        return (1, value.lower()) if isinstance(value, str) else (0, value)

    def _sort_by(self, key):
        self._descending = (not self._descending) if self._sort_key == key else False
        self._sort_key = key
        self._render()

    def set_rows(self, rows):
        self._rows = list(rows)
        self._render()

    def _render(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        rows = self._rows
        if self._sort_key:
            rows = merge_sort(rows, key=lambda r: self._sort_value(r.get(self._sort_key)), reverse=self._descending)
        self._shown = {}
        for i, row in enumerate(rows):
            values = []
            for key, _, _, _, fmt in self.columns:
                v = row.get(key, "")
                values.append(fmt(v) if fmt else ("" if v is None else v))
            tags = ["odd"] if i % 2 else []
            if self.tag_func and self.tag_func(row):
                tags = [self.tag_func(row)]
            iid = self.tree.insert("", "end", values=values, tags=tags)
            self._shown[iid] = row
        for key, heading, *_ in self.columns:
            arrow = (" ▼" if self._descending else " ▲") if key == self._sort_key else ""
            self.tree.heading(key, text=heading + arrow)
        if rows:
            self.empty.place_forget()
        else:
            self.empty.place(relx=0.5, rely=0.45, anchor="center")

    def selected(self):
        sel = self.tree.selection()
        return self._shown.get(sel[0]) if sel else None

    def row_count(self):
        return len(self._rows)


class IdCombo(ttk.Combobox):
    """Read-only combobox that shows labels but returns ids."""

    def __init__(self, master, **kw):
        super().__init__(master, state="readonly", **kw)
        self._pairs = []

    def set_items(self, pairs, first=None):
        """pairs = [(id, label)]. `first` adds a leading choice such as ("", "All categories")."""
        self._pairs = ([(None, first)] if first else []) + list(pairs)
        self["values"] = [label for _, label in self._pairs]
        if self._pairs:
            self.current(0)
        else:
            self.set("")

    def get_id(self):
        idx = self.current()
        return self._pairs[idx][0] if 0 <= idx < len(self._pairs) else None

    def set_id(self, item_id):
        for i, (pid, _) in enumerate(self._pairs):
            if pid == item_id:
                self.current(i)
                return


class Dialog(tk.Toplevel):
    """Modal pop-up with a gentle fade-in."""

    def __init__(self, app, title, width=480):
        super().__init__(app)
        self.app = app
        self.title(title)
        self.configure(bg=C["card"])
        self.transient(app)
        self.resizable(False, False)
        self.body = ttk.Frame(self, style="Card.TFrame", padding=22)
        self.body.pack(fill="both", expand=True)
        self._width = width
        self.bind("<Escape>", lambda e: self.destroy())
        self.after(10, self._show)

    def _show(self):
        try:
            self.update_idletasks()
            w, h = self._width, self.winfo_reqheight()
            x = self.app.winfo_rootx() + (self.app.winfo_width() - w) // 2
            y = self.app.winfo_rooty() + max(40, (self.app.winfo_height() - h) // 3)
            self.geometry(f"{w}x{h}+{max(x, 0)}+{max(y, 0)}")
            self.grab_set()
            self._fade(0.0)
        except tk.TclError:
            pass

    def _fade(self, alpha):
        try:
            self.attributes("-alpha", alpha)
            if alpha < 1:
                self.after(15, self._fade, min(alpha + 0.2, 1.0))
        except tk.TclError:
            pass


def animate_number(widget, target, formatter, steps=18, delay=22):
    """Count a number up from 0 to `target` (eased), writing formatted text into a label."""
    def step(i=0):
        t = 1 - (1 - i / steps) ** 3
        try:
            widget.configure(text=formatter(target * t if i < steps else target))
        except tk.TclError:
            return
        if i < steps:
            widget.after(delay, step, i + 1)
    step()


def field(parent, row, label, widget, col=0, span=1, pad=(0, 10)):
    """Place 'label above widget' pair on a grid and return the widget."""
    ttk.Label(parent, text=label, style="CardMuted.TLabel").grid(row=row * 2, column=col, columnspan=span,
                                                                   sticky="w", pady=(0, 3))
    widget.grid(row=row * 2 + 1, column=col, columnspan=span, sticky="ew", pady=pad, padx=(0, 10))
    return widget
