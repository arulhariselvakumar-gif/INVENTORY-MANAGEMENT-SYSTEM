import os
import tkinter as tk
from tkinter import filedialog, ttk

import config
from ui.screen import Screen, safe
from ui.theme import C, font, money
from ui.widgets import DataTable, Dialog, FlatButton, IdCombo, field

STATUS_TEXT = {"OK": "In stock", "LOW": "Low", "OUT": "Out"}
STATUS_FILTER = [("All stock levels", None), ("In stock", "OK"), ("Low", "LOW"), ("Out of stock", "OUT")]


class ProductDialog(Dialog):
    """Add or edit a product. Stock is set only when adding; later changes go through Stock control."""

    def __init__(self, app, on_saved, product=None):
        super().__init__(app, "Edit product" if product else "Add product", 600)
        self.svc, self.on_saved, self.product = app.svc, on_saved, product
        b = self.body
        for c in (0, 1):
            b.columnconfigure(c, weight=1, uniform="f")
        v = self.vars = {k: tk.StringVar() for k in ("name", "sku", "cost", "price", "qty", "reorder", "desc")}
        field(b, 0, "Product name", ttk.Entry(b, textvariable=v["name"]), 0)
        field(b, 0, "SKU (unique)", ttk.Entry(b, textvariable=v["sku"]), 1)
        self.category = field(b, 1, "Category", IdCombo(b), 0)
        self.supplier = field(b, 1, "Supplier", IdCombo(b), 1)
        field(b, 2, "Cost price", ttk.Entry(b, textvariable=v["cost"]), 0)
        field(b, 2, "Selling price", ttk.Entry(b, textvariable=v["price"]), 1)
        if product:
            note = ttk.Label(b, text=f"In stock: {product['quantity']}. Change stock on the Stock control page.",
                             style="CardMuted.TLabel")
            note.grid(row=6, column=0, sticky="w", pady=(0, 10))
        else:
            field(b, 3, "Opening quantity", ttk.Entry(b, textvariable=v["qty"]), 0)
        field(b, 3, "Reorder level (alert at or below)", ttk.Entry(b, textvariable=v["reorder"]), 1)
        field(b, 4, "Description (optional)", ttk.Entry(b, textvariable=v["desc"]), 0, span=2)
        self.margin = ttk.Label(b, text="", style="CardMuted.TLabel")
        self.margin.grid(row=10, column=0, columnspan=2, sticky="w")
        self.category.set_items([(c["id"], c["name"]) for c in self.svc.categories.list()])
        self.supplier.set_items([(s["id"], s["company"]) for s in self.svc.suppliers.list()], first="(no supplier)")
        v["qty"].set("0")
        v["reorder"].set("5")
        if product:
            for key, col in (("name", "name"), ("sku", "sku"), ("cost", "cost_price"), ("price", "selling_price"),
                             ("reorder", "reorder_level"), ("desc", "description")):
                v[key].set(product[col])
            self.category.set_id(product["category_id"])
            self.supplier.set_id(product["supplier_id"])
        for key in ("cost", "price"):
            v[key].trace_add("write", lambda *_: self.update_margin())
        self.update_margin()
        FlatButton(b, "Save product", self.save).grid(row=11, column=1, sticky="e", pady=(14, 0))
        FlatButton(b, "Cancel", self.destroy, kind="ghost").grid(row=11, column=0, sticky="w", pady=(14, 0))

    def update_margin(self):
        try:
            cost, price = float(self.vars["cost"].get()), float(self.vars["price"].get())
            if price > 0:
                self.margin.configure(text=f"Margin per unit: {money(price - cost)} ({(price - cost) / price * 100:.1f}% of price)")
                return
        except ValueError:
            pass
        self.margin.configure(text="")

    @safe
    def save(self):
        v = self.vars
        data = {"name": v["name"].get(), "sku": v["sku"].get(), "category_id": self.category.get_id(),
                "supplier_id": self.supplier.get_id(), "cost_price": v["cost"].get(),
                "selling_price": v["price"].get(), "reorder_level": v["reorder"].get(),
                "description": v["desc"].get(), "quantity": v["qty"].get()}
        uid = self.app.user["id"]
        if self.product:
            old = self.svc.products.update(self.product["id"], data, uid)
            self.svc.undo.record_product_edit(self.product["id"], old, f"Edited {old['name']}")
            message = "Product updated"
        else:
            self.svc.products.add(data, uid)
            message = "Product added"
        self.destroy()
        self.on_saved()
        self.app.toast(message)


class HistoryDialog(Dialog):
    def __init__(self, app, product):
        super().__init__(app, f"Stock history - {product['name']}", 820)
        ttk.Label(self.body, text=f"{product['sku']}  |  now {product['quantity']} in stock (newest first)",
                  style="CardMuted.TLabel").pack(anchor="w", pady=(0, 8))
        table = DataTable(self.body, [("created_at", "When", 140, "w", None), ("movement_type", "Type", 100, "w", None),
                                      ("quantity_change", "Change", 70, "e", lambda v: f"{v:+d}"),
                                      ("quantity_after", "After", 60, "e", None), ("reason", "Reason", 260, "w", None),
                                      ("user_name", "By", 80, "w", None)], height=10,
                          empty_text="No stock movements recorded yet.")
        table.pack(fill="both", expand=True)
        table.set_rows(list(app.svc.inventory.history_list(product["id"])))   # walks the linked list
        FlatButton(self.body, "Close", self.destroy, kind="ghost").pack(anchor="e", pady=(12, 0))


class ProductsScreen(Screen):
    title = "Products"
    subtitle = "Everything you stock. Click a column heading to sort; double-click a row to edit."

    def build(self, parent):
        bar = ttk.Frame(parent)
        bar.pack(fill="x", pady=(0, 8))
        self.search_var = tk.StringVar()
        entry = ttk.Entry(bar, textvariable=self.search_var, width=30)
        entry.pack(side="left", padx=(0, 8))
        self._after = None
        self.search_var.trace_add("write", lambda *_: self._debounce())
        self.category = IdCombo(bar, width=20)
        self.category.pack(side="left", padx=(0, 8))
        self.supplier = IdCombo(bar, width=24)
        self.supplier.pack(side="left", padx=(0, 8))
        self.status = ttk.Combobox(bar, state="readonly", width=16, values=[t for t, _ in STATUS_FILTER])
        self.status.current(0)
        self.status.pack(side="left")
        for combo in (self.category, self.supplier, self.status):
            combo.bind("<<ComboboxSelected>>", lambda e: self.load())
        ttk.Label(bar, text="Search by name, SKU, code or category", style="Muted.TLabel").pack(side="left", padx=12)

        actions = ttk.Frame(parent)
        actions.pack(fill="x", pady=(0, 10))
        FlatButton(actions, "Add product", self.add).pack(side="left", padx=(0, 8))
        FlatButton(actions, "Edit", self.edit, kind="ghost").pack(side="left", padx=(0, 8))
        FlatButton(actions, "Stock history", self.history, kind="ghost").pack(side="left", padx=(0, 8))
        FlatButton(actions, "Delete", self.delete, kind="danger").pack(side="left", padx=(0, 8))
        self.undo_btn = FlatButton(actions, "Undo", self.undo, kind="ghost")
        self.undo_btn.pack(side="left", padx=(16, 8))
        FlatButton(actions, "Export CSV", self.export, kind="quiet").pack(side="right")
        FlatButton(actions, "Import CSV", self.import_csv, kind="quiet").pack(side="right", padx=(0, 8))

        cols = [("product_code", "Code", 70, "w", None), ("sku", "SKU", 110, "w", None), ("name", "Product", 200, "w", None),
                ("category", "Category", 120, "w", None), ("supplier", "Supplier", 140, "w", None),
                ("quantity", "Qty", 55, "e", None), ("reorder_level", "Reorder at", 75, "e", None),
                ("cost_price", "Cost", 80, "e", lambda v: f"{v:,.2f}"), ("selling_price", "Price", 80, "e", lambda v: f"{v:,.2f}"),
                ("stock_value", "Stock value", 100, "e", lambda v: f"{v:,.2f}"),
                ("status", "Status", 80, "w", lambda v: STATUS_TEXT[v])]
        self.table = DataTable(parent, cols, height=16, on_double=lambda r: self.edit(),
                               tag_func=lambda r: {"LOW": "low", "OUT": "out"}.get(r["status"], ""),
                               empty_text="No products match. Use 'Add product' or import a CSV file.")
        self.table.pack(fill="both", expand=True)
        self.count = ttk.Label(parent, text="", style="Muted.TLabel")
        self.count.pack(anchor="w", pady=(6, 0))

    def _debounce(self):
        if self._after:
            self.after_cancel(self._after)
        self._after = self.after(250, self.load)

    def on_show(self, **_):
        self.category.set_items(self.cat_pairs(self.svc), first="All categories")
        self.supplier.set_items(self.sup_pairs(self.svc), first="All suppliers")
        self.load()

    @safe
    def load(self):
        status = STATUS_FILTER[self.status.current()][1] if self.status.current() >= 0 else None
        rows = self.svc.products.list(self.search_var.get(), self.category.get_id(), self.supplier.get_id(), status)
        self.table.set_rows(rows)
        value = sum(r["stock_value"] for r in rows)
        self.count.configure(text=f"{len(rows)} product(s) shown, stock value {money(value)}")
        self.refresh_undo()

    def refresh_undo(self):
        can = self.svc.undo.can_undo()
        self.undo_btn.set_enabled(can)
        label = self.svc.undo.peek_label()
        self.undo_btn.set_text(("Undo: " + (label[:26] + "...") if len(label) > 29 else "Undo: " + label) if can else "Undo")

    def _pick(self):
        row = self.table.selected()
        if row is None:
            self.app.toast("Select a product in the table first.", "warn")
        return row

    @safe
    def add(self):
        ProductDialog(self.app, self.on_show)

    @safe
    def edit(self):
        row = self._pick()
        if row:
            ProductDialog(self.app, self.on_show, self.svc.products.get(row["id"]))

    @safe
    def history(self):
        row = self._pick()
        if row:
            HistoryDialog(self.app, self.svc.products.get(row["id"]))

    @safe
    def delete(self):
        row = self._pick()
        if row and self.app.confirm(f"Delete '{row['name']}'?\n\nProducts that were never bought or sold are removed. "
                                    "Products with transactions are archived (hidden) so old invoices stay correct."):
            result = self.svc.products.delete(row["id"], self.uid)
            self.on_show()
            self.app.toast(f"Product {result}")

    @safe
    def undo(self):
        label = self.svc.undo.undo(self.uid)
        self.on_show()
        self.app.toast(f"Undone: {label}", "info")

    @safe
    def export(self):
        path = filedialog.asksaveasfilename(parent=self.app, defaultextension=".csv", initialdir=config.EXPORT_DIR,
                                            initialfile="products.csv", filetypes=[("CSV file", "*.csv")])
        if path:
            n = self.svc.csv.export_products(path)
            self.app.toast(f"Exported {n} products")

    @safe
    def import_csv(self):
        path = filedialog.askopenfilename(parent=self.app, filetypes=[("CSV file", "*.csv")],
                                          title="Choose a products CSV (columns: sku, name, category, cost_price, selling_price ...)")
        if not path:
            return
        imported, errors = self.svc.csv.import_products(path, self.uid)
        self.on_show()
        if errors:
            from tkinter import messagebox
            shown = "\n".join(errors[:10]) + (f"\n... and {len(errors) - 10} more" if len(errors) > 10 else "")
            messagebox.showwarning("Import finished with problems", f"{imported} product(s) imported.\n\nSkipped rows:\n{shown}", parent=self.app)
        else:
            self.app.toast(f"Imported {imported} products")
