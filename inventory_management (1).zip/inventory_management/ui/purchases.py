import tkinter as tk
import uuid
from tkinter import ttk

import validators
from database import today_str
from errors import BusinessRuleError
from ui.screen import Screen, safe
from ui.theme import C, font, money
from ui.widgets import DataTable, Dialog, FlatButton, IdCombo, field

STATUS_FILTER = [("All statuses", None), ("Draft", "DRAFT"), ("Confirmed", "CONFIRMED"), ("Cancelled", "CANCELLED")]


class TextDialog(Dialog):
    def __init__(self, app, title, text, width=640):
        super().__init__(app, title, width)
        box = tk.Text(self.body, font=("Consolas", 10), width=70, height=min(text.count("\n") + 2, 24), relief="flat",
                      bg=C["bg"], padx=12, pady=10)
        box.insert("1.0", text)
        box.configure(state="disabled")
        box.pack(fill="both", expand=True)
        FlatButton(self.body, "Close", self.destroy, kind="ghost").pack(anchor="e", pady=(12, 0))


class PurchasesScreen(Screen):
    title = "Purchases"
    subtitle = "Build a purchase, then receive it. Stock increases only when a purchase is confirmed - and only once."

    def build(self, parent):
        self.lines, self.token = [], uuid.uuid4().hex
        editor = ttk.Frame(parent, style="Card.TFrame", padding=16)
        editor.pack(fill="x")
        for c in range(4):
            editor.columnconfigure(c, weight=1, uniform="p")
        self.supplier = field(editor, 0, "Supplier", IdCombo(editor), 0)
        self.date_var, self.notes_var = tk.StringVar(value=today_str()), tk.StringVar()
        field(editor, 0, "Purchase date (YYYY-MM-DD)", ttk.Entry(editor, textvariable=self.date_var), 1)
        field(editor, 0, "Notes (optional)", ttk.Entry(editor, textvariable=self.notes_var), 2, span=2)
        self.product = field(editor, 1, "Product", IdCombo(editor), 0, span=2)
        self.product.bind("<<ComboboxSelected>>", lambda e: self.fill_cost())
        self.qty_var, self.cost_var = tk.StringVar(value="1"), tk.StringVar()
        field(editor, 1, "Quantity", ttk.Entry(editor, textvariable=self.qty_var), 2)
        field(editor, 1, "Unit cost", ttk.Entry(editor, textvariable=self.cost_var), 3)
        row = ttk.Frame(editor, style="Card.TFrame")
        row.grid(row=4, column=0, columnspan=4, sticky="ew")
        FlatButton(row, "Add line", self.add_line).pack(side="left", padx=(0, 8))
        FlatButton(row, "Remove selected line", self.remove_line, kind="ghost").pack(side="left", padx=(0, 8))
        FlatButton(row, "Clear", self.clear, kind="quiet").pack(side="left")
        self.total = ttk.Label(row, text="Total: " + money(0), style="CardH2.TLabel")
        self.total.pack(side="right")
        self.lines_table = DataTable(editor, [("sku", "SKU", 110, "w", None), ("name", "Product", 240, "w", None),
                                              ("qty", "Qty", 70, "e", None), ("cost", "Unit cost", 100, "e", lambda v: f"{v:,.2f}"),
                                              ("total", "Line total", 110, "e", lambda v: f"{v:,.2f}")], height=4,
                                     empty_text="No lines yet. Pick a product, set quantity and cost, then 'Add line'.")
        self.lines_table.grid(row=5, column=0, columnspan=4, sticky="ew", pady=(10, 8))
        done = ttk.Frame(editor, style="Card.TFrame")
        done.grid(row=6, column=0, columnspan=4, sticky="e")
        FlatButton(done, "Save as draft", lambda: self.save(False), kind="ghost").pack(side="left", padx=(0, 8))
        FlatButton(done, "Save and receive stock", lambda: self.save(True)).pack(side="left")

        lst = ttk.Frame(parent, style="Card.TFrame", padding=16)
        lst.pack(fill="both", expand=True, pady=(12, 0))
        top = ttk.Frame(lst, style="Card.TFrame")
        top.pack(fill="x", pady=(0, 8))
        ttk.Label(top, text="Purchase records", style="CardH2.TLabel").pack(side="left")
        self.status = ttk.Combobox(top, state="readonly", width=16, values=[t for t, _ in STATUS_FILTER])
        self.status.current(0)
        self.status.pack(side="left", padx=12)
        self.status.bind("<<ComboboxSelected>>", lambda e: self.load_list())
        FlatButton(top, "View details", self.view, kind="ghost").pack(side="right")
        FlatButton(top, "Cancel draft", self.cancel, kind="danger").pack(side="right", padx=8)
        FlatButton(top, "Receive stock", self.receive, kind="amber").pack(side="right")
        self.table = DataTable(lst, [("purchase_no", "Purchase no.", 130, "w", None), ("purchase_date", "Date", 90, "w", None),
                                     ("supplier", "Supplier", 190, "w", None), ("status", "Status", 100, "w", None),
                                     ("units", "Units", 60, "e", None), ("total_cost", "Total", 110, "e", lambda v: f"{v:,.2f}")],
                               height=6, on_double=lambda r: self.view(),
                               tag_func=lambda r: "done" if r["status"] == "CANCELLED" else "",
                               empty_text="No purchases recorded yet.")
        self.table.pack(fill="both", expand=True)

    def on_show(self, prefill=None, **_):
        self.supplier.set_items(self.sup_pairs(self.svc))
        self.product.set_items(self.product_pairs(self.svc))
        self.load_list()
        if prefill:
            self.clear()
            if prefill.get("supplier_id"):
                self.supplier.set_id(prefill["supplier_id"])
            self.product.set_id(prefill["product_id"])
            self.fill_cost()
            self.qty_var.set(str(prefill["qty"]))
            self.app.toast("Restock suggestion loaded. Check the numbers, then add the line.", "info")

    def fill_cost(self):
        pid = self.product.get_id()
        if pid:
            self.cost_var.set(f"{self.svc.products.get(pid)['cost_price']:.2f}")

    def load_list(self):
        status = STATUS_FILTER[self.status.current()][1] if self.status.current() >= 0 else None
        self.table.set_rows(self.svc.purchases.list(status=status))

    def refresh_lines(self):
        self.lines_table.set_rows(self.lines)
        self.total.configure(text="Total: " + money(sum(l["total"] for l in self.lines)))

    @safe
    def add_line(self):
        pid = self.product.get_id()
        if not pid:
            raise BusinessRuleError("Choose a product first.")
        qty = validators.integer(self.qty_var.get(), "Quantity", minimum=1)
        cost = validators.money(self.cost_var.get(), "Unit cost")
        prod = self.svc.products.get(pid)
        for line in self.lines:
            if line["product_id"] == pid:
                line["qty"] += qty
                line["cost"] = cost
                line["total"] = round(line["qty"] * cost, 2)
                break
        else:
            self.lines.append({"product_id": pid, "sku": prod["sku"], "name": prod["name"], "qty": qty,
                               "cost": cost, "total": round(qty * cost, 2)})
        self.qty_var.set("1")
        self.refresh_lines()

    @safe
    def remove_line(self):
        row = self.lines_table.selected()
        if row is None:
            raise BusinessRuleError("Select a line to remove.")
        self.lines.remove(row)
        self.refresh_lines()

    def clear(self):
        self.lines = []
        self.qty_var.set("1")
        self.cost_var.set("")
        self.notes_var.set("")
        self.refresh_lines()

    @safe
    def save(self, receive):
        supplier = self.supplier.get_id()
        items = [(l["product_id"], l["qty"], l["cost"]) for l in self.lines]
        if receive and not self.app.confirm("Save this purchase and add the quantities to stock now?"):
            return
        self.svc.purchases.create(supplier, self.date_var.get(), items, self.notes_var.get(), self.uid,
                                  request_token=self.token, confirm=receive)
        self.token = uuid.uuid4().hex      # new token: the next purchase is a different transaction
        self.clear()
        self.on_show()
        self.app.toast("Purchase received - stock updated" if receive else "Purchase saved as draft")

    def _pick(self):
        row = self.table.selected()
        if row is None:
            self.app.toast("Select a purchase in the table first.", "warn")
        return row

    @safe
    def receive(self):
        row = self._pick()
        if row and self.app.confirm(f"Receive {row['purchase_no']} and add {row['units']} unit(s) to stock?"):
            self.svc.purchases.confirm(row["id"], self.uid)
            self.on_show()
            self.app.toast("Stock received")

    @safe
    def cancel(self):
        row = self._pick()
        if row and self.app.confirm(f"Cancel draft {row['purchase_no']}?"):
            self.svc.purchases.cancel(row["id"], self.uid)
            self.load_list()
            self.app.toast("Draft cancelled", "info")

    @safe
    def view(self):
        row = self._pick()
        if not row:
            return
        p = self.svc.purchases.get(row["id"])
        out = [f"Purchase {p['purchase_no']}   ({p['status']})", f"Supplier: {p['supplier']}   Date: {p['purchase_date']}",
               f"Notes: {p['notes'] or '-'}", "", f"{'Item':<32}{'Qty':>6}{'Unit cost':>12}{'Total':>12}", "-" * 62]
        out += [f"{(i['sku'] + ' ' + i['name'])[:31]:<32}{i['quantity']:>6}{i['unit_cost']:>12,.2f}{i['line_total']:>12,.2f}" for i in p["items"]]
        out += ["-" * 62, f"{'TOTAL':>50}{p['total_cost']:>12,.2f}"]
        TextDialog(self.app, "Purchase details", "\n".join(out))
