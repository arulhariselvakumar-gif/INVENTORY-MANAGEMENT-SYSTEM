import os
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import config
import validators
from errors import BusinessRuleError, InsufficientStockError
from ui.screen import Screen, safe
from ui.theme import C, font, money
from ui.widgets import DataTable, FlatButton, IdCombo, field

MODES = ["Set stock to", "Add units", "Remove units"]


class StockScreen(Screen):
    title = "Stock control"
    subtitle = "Correct stock after a count, damage or loss. Every change needs a reason and is kept in the history."

    def build(self, parent):
        parent.columnconfigure(0, weight=2, uniform="s")
        parent.columnconfigure(1, weight=3, uniform="s")
        parent.rowconfigure(0, weight=1)
        form = ttk.Frame(parent, style="Card.TFrame", padding=18)
        form.grid(row=0, column=0, sticky="new", padx=(0, 14))
        form.columnconfigure(0, weight=1)
        ttk.Label(form, text="Adjust stock", style="CardH2.TLabel").grid(row=0, column=0, sticky="w", pady=(0, 10))
        self.product = field(form, 1, "Product", IdCombo(form))
        self.product.bind("<<ComboboxSelected>>", lambda e: self.show_history())
        self.current = ttk.Label(form, text="", style="CardMuted.TLabel")
        self.current.grid(row=4, column=0, sticky="w", pady=(0, 8))
        self.mode = field(form, 3, "What do you want to do?", ttk.Combobox(form, state="readonly", values=MODES))
        self.mode.current(0)
        self.qty_var, self.reason_var = tk.StringVar(), tk.StringVar()
        field(form, 4, "Quantity", ttk.Entry(form, textvariable=self.qty_var))
        field(form, 5, "Reason (required)", ttk.Entry(form, textvariable=self.reason_var))
        FlatButton(form, "Apply adjustment", self.apply).grid(row=20, column=0, sticky="ew", pady=(4, 0))
        self.undo_btn = FlatButton(form, "Undo last stock or product change", self.undo, kind="ghost")
        self.undo_btn.grid(row=21, column=0, sticky="ew", pady=(8, 0))
        ttk.Separator(form).grid(row=22, column=0, sticky="ew", pady=14)
        ttk.Label(form, text="Does every stock figure match its history?", style="CardMuted.TLabel").grid(row=23, column=0, sticky="w")
        FlatButton(form, "Check consistency", self.verify, kind="quiet").grid(row=24, column=0, sticky="w", pady=(4, 0))

        tabs = ttk.Notebook(parent)
        tabs.grid(row=0, column=1, sticky="nsew")
        hist = ttk.Frame(tabs, style="Card.TFrame", padding=12)
        summ = ttk.Frame(tabs, style="Card.TFrame", padding=12)
        tabs.add(hist, text="History of selected product")
        tabs.add(summ, text="Movement summary")
        self.history = DataTable(hist, [("created_at", "When", 130, "w", None), ("movement_type", "Type", 95, "w", None),
                                        ("quantity_change", "Change", 65, "e", lambda v: f"{v:+d}"),
                                        ("quantity_after", "After", 55, "e", None), ("reason", "Reason", 200, "w", None),
                                        ("user_name", "By", 70, "w", None)], height=14,
                                 empty_text="Choose a product to see its stock history (newest first).")
        self.history.pack(fill="both", expand=True)
        self.summary = DataTable(summ, [("sku", "SKU", 100, "w", None), ("name", "Product", 170, "w", None),
                                        ("opening", "Opening", 65, "e", None), ("received", "Received", 70, "e", None),
                                        ("sold", "Sold", 55, "e", None), ("returned", "Returned", 70, "e", None),
                                        ("adjusted", "Adjusted", 70, "e", None), ("current_qty", "Now", 55, "e", None)],
                                 height=14, empty_text="No products yet.")
        self.summary.pack(fill="both", expand=True)

    def on_show(self, **_):
        selected = self.product.get_id()
        self.product.set_items(self.product_pairs(self.svc))
        if selected:
            self.product.set_id(selected)
        self.show_history()
        self.summary.set_rows(self.svc.inventory.movement_summary())
        self.undo_btn.set_enabled(self.svc.undo.can_undo())

    def show_history(self):
        pid = self.product.get_id()
        if not pid:
            self.history.set_rows([])
            return
        prod = self.svc.products.get(pid)
        self.current.configure(text=f"Currently in stock: {prod['quantity']}   (reorder at {prod['reorder_level']})")
        self.history.set_rows(list(self.svc.inventory.history_list(pid)))      # linked list, newest first

    @safe
    def apply(self):
        pid = self.product.get_id()
        if not pid:
            raise BusinessRuleError("Choose a product first.")
        amount = validators.integer(self.qty_var.get(), "Quantity", minimum=0)
        prod = self.svc.products.get(pid)
        mode = self.mode.current()
        new_qty = amount if mode == 0 else prod["quantity"] + amount if mode == 1 else prod["quantity"] - amount
        if new_qty < 0:
            raise InsufficientStockError(f"Cannot remove {amount}: only {prod['quantity']} in stock.")
        if not self.app.confirm(f"Change '{prod['name']}' from {prod['quantity']} to {new_qty}?"):
            return
        res = self.svc.inventory.adjust_stock(pid, new_qty, self.reason_var.get(), self.uid)
        self.svc.undo.record_adjustment(pid, res["delta"], f"{prod['name']} {res['old']} to {res['new']}")
        self.qty_var.set("")
        self.reason_var.set("")
        self.on_show()
        self.app.toast("Stock adjusted")

    @safe
    def undo(self):
        label = self.svc.undo.undo(self.uid)
        self.on_show()
        self.app.toast(f"Undone: {label}", "info")

    @safe
    def verify(self):
        bad = self.svc.inventory.verify_consistency()
        if not bad:
            messagebox.showinfo("All good", "Every product's stock matches the sum of its movements.", parent=self.app)
            return
        names = "\n".join(f"{b['name']}: stored {b['stored_qty']}, history says {b['movement_total']}" for b in bad[:8])
        if self.app.confirm(f"{len(bad)} product(s) do not match their history:\n\n{names}\n\nRebuild their stock from the history?"):
            n = self.svc.inventory.recalculate_stock(self.uid)
            self.on_show()
            self.app.toast(f"{n} product(s) corrected")


class LowStockScreen(Screen):
    title = "Low-stock alerts"
    subtitle = "Products at or below their reorder level, with a suggested order size."

    def build(self, parent):
        parent.columnconfigure(0, weight=3, uniform="l")
        parent.columnconfigure(1, weight=2, uniform="l")
        parent.rowconfigure(1, weight=1)
        bar = ttk.Frame(parent)
        bar.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        self.status = ttk.Combobox(bar, state="readonly", width=16, values=["Low and out", "Low only", "Out of stock only"])
        self.status.current(0)
        self.status.pack(side="left", padx=(0, 8))
        self.category, self.supplier = IdCombo(bar, width=20), IdCombo(bar, width=24)
        self.category.pack(side="left", padx=(0, 8))
        self.supplier.pack(side="left", padx=(0, 8))
        for c in (self.status, self.category, self.supplier):
            c.bind("<<ComboboxSelected>>", lambda e: self.load())
        FlatButton(bar, "Export CSV", self.export, kind="quiet").pack(side="right")
        FlatButton(bar, "Add to restock queue", self.enqueue, kind="amber").pack(side="right", padx=8)

        left = ttk.Frame(parent, style="Card.TFrame", padding=12)
        left.grid(row=1, column=0, sticky="nsew", padx=(0, 12))
        self.table = DataTable(left, [("sku", "SKU", 100, "w", None), ("name", "Product", 170, "w", None),
                                      ("quantity", "Left", 50, "e", None), ("reorder_level", "Reorder at", 75, "e", None),
                                      ("suggested_qty", "Order", 60, "e", None),
                                      ("estimated_cost", "Est. cost", 90, "e", lambda v: f"{v:,.2f}"),
                                      ("status", "Status", 60, "w", None)], height=14,
                               tag_func=lambda r: "out" if r["status"] == "OUT" else "low",
                               empty_text="Nothing needs restocking right now.")
        self.table.pack(fill="both", expand=True)
        self.note = ttk.Label(left, text="", style="CardMuted.TLabel")
        self.note.pack(anchor="w", pady=(8, 0))

        right = ttk.Frame(parent, style="Card.TFrame", padding=12)
        right.grid(row=1, column=1, sticky="nsew")
        head = ttk.Frame(right, style="Card.TFrame")
        head.pack(fill="x", pady=(0, 4))
        ttk.Label(head, text="Restock queue", style="CardH2.TLabel").pack(side="left")
        FlatButton(head, "Process next", self.process_next).pack(side="right")
        ttk.Label(right, text="First in, first out: the product at the top is handled next.",
                  style="CardMuted.TLabel").pack(anchor="w", pady=(0, 8))
        self.queue_table = DataTable(right, [("pos", "#", 35, "e", None), ("name", "Product", 170, "w", None),
                                             ("suggested_qty", "Qty", 55, "e", None), ("created_at", "Queued", 120, "w", None)],
                                     height=12, empty_text="The queue is empty. Select a product and 'Add to restock queue'.")
        self.queue_table.pack(fill="both", expand=True)

    def on_show(self, **_):
        self.category.set_items(self.cat_pairs(self.svc), first="All categories")
        self.supplier.set_items(self.sup_pairs(self.svc), first="All suppliers")
        self.load()

    def _status(self):
        return (None, "LOW", "OUT")[max(self.status.current(), 0)]

    def load(self):
        rows = self.svc.inventory.low_stock(self._status(), self.category.get_id(), self.supplier.get_id())
        self.table.set_rows(rows)
        total = sum(r["estimated_cost"] for r in rows)
        self.note.configure(text=f"{len(rows)} product(s). Suggested order = enough to reach {config.LOW_STOCK_TARGET_FACTOR} x the "
                                 f"reorder level. Estimated cost to restock all: {money(total)}")
        queue = self.svc.inventory.restock_queue()
        self.queue_table.set_rows([{**t, "pos": i + 1} for i, t in enumerate(queue.to_list())])

    @safe
    def enqueue(self):
        row = self.table.selected()
        if row is None:
            raise BusinessRuleError("Select a product in the table first.")
        qty = self.svc.inventory.queue_restock(row["id"], self.uid)
        self.load()
        self.app.toast(f"Queued {qty} x {row['name']}")

    @safe
    def process_next(self):
        task = self.svc.inventory.process_next_restock(self.uid)
        self.app.navigate("purchases", prefill={"supplier_id": task["supplier_id"], "product_id": task["product_id"],
                                                "qty": task["suggested_qty"]})

    @safe
    def export(self):
        path = filedialog.asksaveasfilename(parent=self.app, defaultextension=".csv", initialdir=config.EXPORT_DIR,
                                            initialfile="low_stock.csv", filetypes=[("CSV file", "*.csv")])
        if path:
            report = self.svc.reports.low_stock(self._status(), self.category.get_id(), self.supplier.get_id())
            n = self.svc.reports.export_csv(report, path)
            self.app.toast(f"Exported {n} rows")
