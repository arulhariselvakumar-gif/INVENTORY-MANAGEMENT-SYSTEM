import tkinter as tk
from tkinter import ttk

import config
from errors import InventoryError
from ui.theme import C, font
from ui.widgets import FlatButton


class LoginScreen(tk.Frame):
    def __init__(self, app):
        super().__init__(app, bg=C["bg"])
        self.app = app
        self.columnconfigure(0, weight=5, uniform="a")
        self.columnconfigure(1, weight=6, uniform="a")
        self.rowconfigure(0, weight=1)

        side = tk.Frame(self, bg=C["ink"])
        side.grid(row=0, column=0, sticky="nsew")
        inner = tk.Frame(side, bg=C["ink"])
        inner.place(relx=0.5, rely=0.5, anchor="center")
        tk.Label(inner, text=config.APP_NAME, bg=C["ink"], fg="white", font=font(26, "bold")).pack(anchor="w")
        tk.Frame(inner, bg=C["amber"], height=4, width=64).pack(anchor="w", pady=(10, 14))
        tk.Label(inner, text="Know what is on the shelf,\nand what is about to run out.", bg=C["ink"],
                 fg=C["ink_text"], font=font(13), justify="left").pack(anchor="w")

        right = tk.Frame(self, bg=C["bg"])
        right.grid(row=0, column=1, sticky="nsew")
        self.card = tk.Frame(right, bg=C["card"], padx=34, pady=30, highlightbackground=C["line"], highlightthickness=1)
        self._card_x = 0
        self.card.place(relx=0.5, rely=0.5, anchor="center", x=0)
        tk.Label(self.card, text="Sign in", bg=C["card"], fg=C["text"], font=font(18, "bold")).grid(row=0, column=0, sticky="w")
        tk.Label(self.card, text="Use your administrator account.", bg=C["card"], fg=C["muted"]).grid(row=1, column=0, sticky="w", pady=(0, 16))
        self.user_var, self.pass_var = tk.StringVar(value=config.DEFAULT_ADMIN_USERNAME), tk.StringVar()
        tk.Label(self.card, text="Username", bg=C["card"], fg=C["muted"]).grid(row=2, column=0, sticky="w")
        self.user_entry = ttk.Entry(self.card, textvariable=self.user_var, width=32)
        self.user_entry.grid(row=3, column=0, sticky="ew", pady=(2, 12))
        tk.Label(self.card, text="Password", bg=C["card"], fg=C["muted"]).grid(row=4, column=0, sticky="w")
        self.pass_entry = ttk.Entry(self.card, textvariable=self.pass_var, show="•", width=32)
        self.pass_entry.grid(row=5, column=0, sticky="ew", pady=(2, 4))
        self.show_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(self.card, text="Show password", variable=self.show_var,
                        command=lambda: self.pass_entry.configure(show="" if self.show_var.get() else "•")
                        ).grid(row=6, column=0, sticky="w", pady=(0, 12))
        self.message = tk.Label(self.card, text="", bg=C["card"], fg=C["danger"], wraplength=290, justify="left")
        self.message.grid(row=7, column=0, sticky="w")
        self.button = FlatButton(self.card, "Sign in", self.submit)
        self.button.grid(row=8, column=0, sticky="ew", pady=(8, 0))
        self.hint = tk.Label(self.card, text="", bg=C["card"], fg=C["muted"], font=font(9), wraplength=290, justify="left")
        self.hint.grid(row=9, column=0, sticky="w", pady=(12, 0))
        self.user_entry.bind("<Return>", lambda e: self.pass_entry.focus_set())
        self.pass_entry.bind("<Return>", lambda e: self.submit())
        self.after(100, self.pass_entry.focus_set)
        self.refresh_hint()

    def refresh_hint(self):
        try:
            if self.app.svc.auth.is_default_password(self.user_var.get().strip()):
                self.hint.configure(text=f"First time here? The starting password is {config.DEFAULT_ADMIN_PASSWORD}. "
                                         "Change it from the sidebar after signing in.")
        except Exception:
            pass

    def submit(self):
        try:
            user = self.app.svc.auth.login(self.user_var.get(), self.pass_var.get())
        except InventoryError as exc:
            self.message.configure(text=str(exc))
            self.pass_var.set("")
            self.shake()
            return
        self.app.on_login(user)

    def shake(self, i=0):
        """Short sideways wobble: shows the sign-in was refused."""
        offsets = [-10, 10, -7, 7, -4, 4, 0]
        self.card.place_configure(x=offsets[i])
        if i < len(offsets) - 1:
            self.after(35, self.shake, i + 1)
