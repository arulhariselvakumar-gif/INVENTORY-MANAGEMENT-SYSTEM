import tkinter as tk
import uuid
from tkinter import filedialog, ttk

import config
import validators
from errors import BusinessRuleError, InventoryError
from services.sales_service import calc_totals
from ui.purchases import TextDialog
from ui.screen import Screen, safe
from ui.theme import C, font, money
from ui.widgets import DataTable, Dialog, FlatButton, IdCombo, field

STATUS_FILTER = [("All statuses", None), ("Completed", "COMPLETED"), ("Partly returned", "PARTIAL_RETURN"),
                 ("Returned", "RETURNED"), ("Cancelled", "CANCELLED")]


class InvoiceDialog(TextDialog):
    def __init__(self, app, sale_id):
        text = app.svc.sales.invoice_text(sale_id)
        super().__init__(app, "Invoice", text, 560)
        self.sale_id, self.text = sale_id, text
        FlatButton(self.body, "Save as text file", self.save, kind="quiet").pack(anchor="e", pady=(8, 0))

    @safe
    def save(self):
        name = self.svc_name()
        path = filedialog.asksaveasfilename(parent=self, defaultextension=".txt", initialdir=config.EXPORT_DIR,
                                            initialfile=name + ".txt", filetypes=[("Text file", "*.txt")])
        if path:
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(self.text)
            self.app.toast("Invoice saved")

    def svc_name(self):
        return self.app.svc.sales.get(self.sale_id)["invoice_no"]


class ReturnDialog(Dialog):
    def __init__(self, app, sale, on_done):
        super().__init__(app, f"Return items - {sale['invoice_no']}", 520)
        self.sale, self.on_done, self.spins = sale, on_done, {}
        ttk.Label(self.body, text="Choose how many units come back. Returned units go back into stock.",
                  style="CardMuted.TLabel").grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 10))
        r = 1
        for item in sale["items"]:
            left = item["quantity"] - item["returned_qty"]
            if left <= 0:
                continue
            ttk.Label(self.body, text=f"{item['name']}  (sold {item['quantity']}, can return {left})",
                      style="Card.TLabel").grid(row=r, column=0, sticky="w", pady=4)
            var = tk.StringVar(value="0")
            ttk.Spinbox(self.body, from_=0, to=left, width=5, textvariable=var).grid(row=r, column=1, padx=10)
            self.spins[item["id"]] = var
            r += 1
        self.reason = tk.StringVar()
        ttk.Label(self.body, text="Reason", style="CardMuted.TLabel").grid(row=r, column=0, sticky="w", pady=(12, 2))
        ttk.Entry(self.body, textvariable=self.reason, width=54).grid(row=r + 1, column=0, columnspan=3, sticky="ew")
        FlatButton(self.body, "Return selected items", self.submit).grid(row=r + 2, column=0, columnspan=3, sticky="e", pady=(14, 0))

    @safe
    def submit(self):
        quantities = {}
        for item_id, var in self.spins.items():
            qty = validators.integer(var.get() or "0", "Return quantity", minimum=0)
            if qty:
                quantities[item_id] = qty
        refund = self.app.svc.sales.return_items(self.sale["id"], quantities, self.reason.get(), self.app.user["id"])
        self.destroy()
        self.on_done()
        self.app.toast(f"Return recorded - refund {money(refund)}")


class SalesScreen(Screen):
    title = "Sales and invoices"
    subtitle = "Scan or pick products, review the totals, then complete the sale. Stock drops only when the sale succeeds."

    def build(self, parent):
        self.cart, self.token, self.index = [], uuid.uuid4().hex, None
        top = ttk.Frame(parent)
        top.pack(fill="x")
        top.columnconfigure(0, weight=3, uniform="s")
        top.columnconfigure(1, weight=2, uniform="s")
        left = ttk.Frame(top, style="Card.TFrame", padding=16)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 12))
        for c in range(4):
            left.columnconfigure(c, weight=1)
        self.sku_var, self.qty_var = tk.StringVar(), tk.StringVar(value="1")
        sku = field(left, 0, "Type SKU or name, press Enter", ttk.Entry(left, textvariable=self.sku_var), 0, span=2)
        sku.bind("<Return>", lambda e: self.find())
        self.sku_entry = sku
        self.product = field(left, 0, "Product", IdCombo(left), 2, span=2)
        field(left, 1, "Quantity", ttk.Entry(left, textvariable=self.qty_var), 0)
        row = ttk.Frame(left, style="Card.TFrame")
        row.grid(row=3, column=1, columnspan=3, sticky="w", pady=(0, 10))
        FlatButton(row, "Add to cart", self.add_to_cart).pack(side="left", padx=(0, 8))
        FlatButton(row, "Remove line", self.remove_line, kind="ghost").pack(side="left")
        self.cart_table = DataTable(left, [("sku", "SKU", 100, "w", None), ("name", "Product", 190, "w", None),
                                           ("qty", "Qty", 50, "e", None), ("price", "Price", 80, "e", lambda v: f"{v:,.2f}"),
                                           ("total", "Line total", 90, "e", lambda v: f"{v:,.2f}")], height=6,
                                    empty_text="The cart is empty.")
        self.cart_table.grid(row=4, column=0, columnspan=4, sticky="ew")

        right = ttk.Frame(top, style="Card.TFrame", padding=16)
        right.grid(row=0, column=1, sticky="nsew")
        right.columnconfigure((0, 1), weight=1, uniform="r")
        self.customer = tk.StringVar()
        self.discount, self.tax = tk.StringVar(value="0"), tk.StringVar(value=f"{config.DEFAULT_TAX_PERCENT:g}")
        field(right, 0, "Customer (optional)", ttk.Entry(right, textvariable=self.customer), 0, span=2)
        field(right, 1, "Discount %", ttk.Entry(right, textvariable=self.discount), 0)
        field(right, 1, "Tax %", ttk.Entry(right, textvariable=self.tax), 1)
        for var in (self.discount, self.tax):
            var.trace_add("write", lambda *_: self.refresh_totals())
        self.totals = {}
        r = 4
        for key, label, style in (("subtotal", "Subtotal", "Card.TLabel"), ("discount", "Discount", "Card.TLabel"),
                                  ("tax", "Tax", "Card.TLabel"), ("total", "Total to pay", "CardH2.TLabel")):
            ttk.Label(right, text=label, style=style).grid(row=r, column=0, sticky="w")
            self.totals[key] = ttk.Label(right, text="-", style=style)
            self.totals[key].grid(row=r, column=1, sticky="e")
            r += 1
        FlatButton(right, "Complete sale", self.complete).grid(row=r, column=0, columnspan=2, sticky="ew", pady=(12, 0))
        FlatButton(right, "Clear cart", self.clear, kind="quiet").grid(row=r + 1, column=0, columnspan=2, sticky="ew", pady=(4, 0))

        hist = ttk.Frame(parent, style="Card.TFrame", padding=16)
        hist.pack(fill="both", expand=True, pady=(12, 0))
        bar = ttk.Frame(hist, style="Card.TFrame")
        bar.pack(fill="x", pady=(0, 8))
        ttk.Label(bar, text="Past sales", style="CardH2.TLabel").pack(side="left")
        self.search = tk.StringVar()
        ttk.Entry(bar, textvariable=self.search, width=22).pack(side="left", padx=(12, 6))
        self.search.trace_add("write", lambda *_: self.load_history())
        self.status = ttk.Combobox(bar, state="readonly", width=16, values=[t for t, _ in STATUS_FILTER])
        self.status.current(0)
        self.status.pack(side="left")
        self.status.bind("<<ComboboxSelected>>", lambda e: self.load_history())
        FlatButton(bar, "Cancel sale", self.cancel, kind="danger").pack(side="right")
        FlatButton(bar, "Return items", self.returns, kind="ghost").pack(side="right", padx=8)
        FlatButton(bar, "View invoice", self.view, kind="amber").pack(side="right")
        self.history = DataTable(hist, [("invoice_no", "Invoice", 130, "w", None), ("sale_date", "Date", 90, "w", None),
                                        ("customer_name", "Customer", 160, "w", None),
                                        ("total", "Total", 100, "e", lambda v: f"{v:,.2f}"), ("status", "Status", 120, "w", None)],
                                 height=6, on_double=lambda r: self.view(),
                                 tag_func=lambda r: "done" if r["status"] in ("CANCELLED", "RETURNED") else "",
                                 empty_text="No sales yet.")
        self.history.pack(fill="both", expand=True)

    def on_show(self, **_):
        self.reload_products()
        self.load_history()
        self.refresh_totals()

    def reload_products(self):
        """Rebuild the in-memory index (hash table + BST) from the database, and refill the picker."""
        self.index = self.svc.products.build_index()
        self.set_choices(self.index.products)

    def set_choices(self, products):
        self.product.set_items(self.product_pairs(self.svc, products))

    @safe
    def find(self):
        text = self.sku_var.get().strip()
        if not text:
            self.set_choices(self.index.products)
            return
        hit = self.index.hash_lookup("sku", text)["results"]          # exact SKU: hash table, O(1)
        matches = hit or self.index.name_prefix(text)["results"]      # otherwise name prefix: BST
        if not matches:
            self.app.toast("No product with that SKU or name.", "warn")
            return
        self.set_choices(matches)
        self.product.set_id(matches[0]["id"])
        if len(matches) > 1:
            self.app.toast(f"{len(matches)} matches - pick one in the Product box", "info")

    @safe
    def add_to_cart(self):
        pid = self.product.get_id()
        if not pid:
            raise BusinessRuleError("Choose a product first.")
        qty = validators.integer(self.qty_var.get(), "Quantity", minimum=1)
        prod = self.svc.products.get(pid)
        already = sum(l["qty"] for l in self.cart if l["product_id"] == pid)
        if qty + already > prod["quantity"]:
            raise BusinessRuleError(f"Only {prod['quantity']} of '{prod['name']}' in stock ({already} already in the cart).")
        for line in self.cart:
            if line["product_id"] == pid:
                line["qty"] += qty
                line["total"] = round(line["qty"] * line["price"], 2)
                break
        else:
            self.cart.append({"product_id": pid, "sku": prod["sku"], "name": prod["name"], "qty": qty,
                              "price": prod["selling_price"], "total": round(qty * prod["selling_price"], 2)})
        self.qty_var.set("1")
        self.sku_var.set("")
        self.cart_table.set_rows(self.cart)
        self.refresh_totals()
        self.sku_entry.focus_set()

    @safe
    def remove_line(self):
        row = self.cart_table.selected()
        if row is None:
            raise BusinessRuleError("Select a cart line to remove.")
        self.cart.remove(row)
        self.cart_table.set_rows(self.cart)
        self.refresh_totals()

    def refresh_totals(self):
        try:
            t = calc_totals([(l["qty"], l["price"]) for l in self.cart], validators.percent(self.discount.get() or "0", "Discount"),
                            validators.percent(self.tax.get() or "0", "Tax"))
        except InventoryError:
            for label in self.totals.values():
                label.configure(text="-")
            return
        self.totals["subtotal"].configure(text=money(t["subtotal"]))
        self.totals["discount"].configure(text="-" + money(t["discount_amount"]))
        self.totals["tax"].configure(text=money(t["tax_amount"]))
        self.totals["total"].configure(text=money(t["total"]))

    def clear(self):
        self.cart = []
        self.cart_table.set_rows([])
        self.customer.set("")
        self.discount.set("0")
        self.refresh_totals()

    @safe
    def complete(self):
        items = [(l["product_id"], l["qty"]) for l in self.cart]
        if not items:
            raise BusinessRuleError("The cart is empty.")
        sale_id = self.svc.sales.create(items, self.customer.get(), self.discount.get(), self.tax.get(),
                                        self.uid, request_token=self.token)
        self.token = uuid.uuid4().hex      # a fresh token for the next sale; double-clicks reuse the old one
        self.clear()
        self.on_show()
        self.app.toast("Sale completed")
        InvoiceDialog(self.app, sale_id)

    def load_history(self):
        status = STATUS_FILTER[self.status.current()][1] if self.status.current() >= 0 else None
        self.history.set_rows(self.svc.sales.list(search=self.search.get(), status=status))

    def _pick(self):
        row = self.history.selected()
        if row is None:
            self.app.toast("Select a sale in the table first.", "warn")
        return row

    @safe
    def view(self):
        row = self._pick()
        if row:
            InvoiceDialog(self.app, row["id"])

    @safe
    def returns(self):
        row = self._pick()
        if row:
            ReturnDialog(self.app, self.svc.sales.get(row["id"]), self.on_show)

    @safe
    def cancel(self):
        row = self._pick()
        if not row:
            return
        reason = tk.StringVar()
        dlg = Dialog(self.app, "Cancel sale", 440)
        ttk.Label(dlg.body, text=f"Cancel {row['invoice_no']}? All remaining units go back into stock.",
                  style="Card.TLabel", wraplength=380).pack(anchor="w")
        ttk.Label(dlg.body, text="Reason", style="CardMuted.TLabel").pack(anchor="w", pady=(12, 2))
        ttk.Entry(dlg.body, textvariable=reason, width=48).pack(fill="x")

        def confirm():
            try:
                refund = self.svc.sales.cancel(row["id"], reason.get(), self.uid)
            except Exception as exc:     # noqa: BLE001 - show a friendly message instead of crashing
                self.app.handle_error(exc)
                return
            dlg.destroy()
            self.on_show()
            self.app.toast(f"Sale cancelled - refund {money(refund)}")
        FlatButton(dlg.body, "Cancel this sale", confirm, kind="danger").pack(anchor="e", pady=(14, 0))
