import tkinter as tk
from tkinter import ttk

from errors import BusinessRuleError
from ui.screen import Screen, safe
from ui.widgets import DataTable, Dialog, FlatButton, IdCombo, field


class ReassignDialog(Dialog):
    def __init__(self, app, category, others, on_choose):
        super().__init__(app, "Move products first", 420)
        ttk.Label(self.body, text=f"'{category['name']}' still has products.\nChoose the category they should move to:",
                  style="Card.TLabel").pack(anchor="w", pady=(0, 10))
        self.combo = IdCombo(self.body, width=40)
        self.combo.set_items([(c["id"], c["name"]) for c in others])
        self.combo.pack(fill="x")
        row = ttk.Frame(self.body, style="Card.TFrame")
        row.pack(fill="x", pady=(16, 0))
        FlatButton(row, "Cancel", self.destroy, kind="ghost").pack(side="left")
        FlatButton(row, "Move products and delete", lambda: (on_choose(self.combo.get_id()), self.destroy()),
                   kind="danger").pack(side="right")


class CategoriesScreen(Screen):
    title = "Categories"
    subtitle = "Group products so they are easy to filter and report on."

    def build(self, parent):
        parent.columnconfigure(0, weight=3)
        parent.columnconfigure(1, weight=2)
        parent.rowconfigure(0, weight=1)
        self.table = DataTable(parent, [("name", "Category", 200, "w", None), ("description", "Description", 280, "w", None),
                                        ("product_count", "Products", 80, "e", None)], height=14,
                               on_select=self.load_form, empty_text="No categories yet. Add the first one on the right.")
        self.table.grid(row=0, column=0, sticky="nsew", padx=(0, 14))
        form = ttk.Frame(parent, style="Card.TFrame", padding=18)
        form.grid(row=0, column=1, sticky="new")
        form.columnconfigure(0, weight=1)
        ttk.Label(form, text="Category details", style="CardH2.TLabel").grid(row=0, column=0, sticky="w", pady=(0, 10))
        self.name, self.desc = tk.StringVar(), tk.StringVar()
        field(form, 1, "Name", ttk.Entry(form, textvariable=self.name))
        field(form, 2, "Description (optional)", ttk.Entry(form, textvariable=self.desc))
        buttons = ttk.Frame(form, style="Card.TFrame")
        buttons.grid(row=10, column=0, sticky="ew", pady=(4, 0))
        FlatButton(buttons, "Add new", self.add).pack(side="left", padx=(0, 8))
        FlatButton(buttons, "Save changes", self.update, kind="ghost").pack(side="left", padx=(0, 8))
        FlatButton(buttons, "Delete", self.delete, kind="danger").pack(side="left")
        FlatButton(form, "Clear form", self.clear, kind="quiet").grid(row=11, column=0, sticky="w", pady=(8, 0))
        self._selected = None

    def on_show(self, **_):
        self.table.set_rows(self.svc.categories.list())

    def load_form(self, row):
        self._selected = row
        if row:
            self.name.set(row["name"])
            self.desc.set(row["description"])

    def clear(self):
        self._selected = None
        self.name.set("")
        self.desc.set("")

    @safe
    def add(self):
        self.svc.categories.add(self.name.get(), self.desc.get(), self.uid)
        self.clear()
        self.on_show()
        self.app.toast("Category added")

    @safe
    def update(self):
        if not self._selected:
            raise BusinessRuleError("Select a category in the table first.")
        self.svc.categories.update(self._selected["id"], self.name.get(), self.desc.get(), self.uid)
        self.on_show()
        self.app.toast("Category updated")

    @safe
    def delete(self):
        row = self._selected
        if not row:
            raise BusinessRuleError("Select a category in the table first.")
        if not self.app.confirm(f"Delete the category '{row['name']}'?"):
            return
        try:
            self.svc.categories.delete(row["id"], user_id=self.uid)
        except BusinessRuleError:
            others = [c for c in self.svc.categories.list() if c["id"] != row["id"]]
            if not others:
                raise BusinessRuleError("This category is in use and there is no other category to move the products to. "
                                        "Create another category first.") from None
            ReassignDialog(self.app, row, others, lambda target: self._reassign(row, target))
            return
        self.clear()
        self.on_show()
        self.app.toast("Category deleted")

    @safe
    def _reassign(self, row, target):
        moved = self.svc.categories.delete(row["id"], reassign_to=target, user_id=self.uid)
        self.clear()
        self.on_show()
        self.app.toast(f"Category deleted; {moved} product(s) moved")


class SuppliersScreen(Screen):
    title = "Suppliers"
    subtitle = "Who you buy from. Purchases and products link back to these records."

    def build(self, parent):
        parent.columnconfigure(0, weight=3)
        parent.columnconfigure(1, weight=2)
        parent.rowconfigure(0, weight=1)
        left = ttk.Frame(parent)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 14))
        left.rowconfigure(1, weight=1)
        left.columnconfigure(0, weight=1)
        self.search = tk.StringVar()
        ttk.Entry(left, textvariable=self.search).grid(row=0, column=0, sticky="ew", pady=(0, 8))
        self.search.trace_add("write", lambda *_: self.on_show())
        self.table = DataTable(left, [("company", "Company", 170, "w", None), ("name", "Contact", 110, "w", None),
                                      ("phone", "Phone", 100, "w", None), ("email", "Email", 170, "w", None),
                                      ("product_count", "Products", 70, "e", None)], height=14,
                               on_select=self.load_form, empty_text="No suppliers found.")
        self.table.grid(row=1, column=0, sticky="nsew")
        form = ttk.Frame(parent, style="Card.TFrame", padding=18)
        form.grid(row=0, column=1, sticky="new")
        form.columnconfigure(0, weight=1)
        ttk.Label(form, text="Supplier details", style="CardH2.TLabel").grid(row=0, column=0, sticky="w", pady=(0, 10))
        self.vars = {k: tk.StringVar() for k in ("company", "name", "phone", "email", "address")}
        for i, (key, label) in enumerate((("company", "Company name"), ("name", "Contact person"), ("phone", "Contact number"),
                                          ("email", "Email (optional)"), ("address", "Address (optional)")), start=1):
            field(form, i, label, ttk.Entry(form, textvariable=self.vars[key]))
        buttons = ttk.Frame(form, style="Card.TFrame")
        buttons.grid(row=20, column=0, sticky="ew", pady=(4, 0))
        FlatButton(buttons, "Add new", self.add).pack(side="left", padx=(0, 8))
        FlatButton(buttons, "Save changes", self.update, kind="ghost").pack(side="left", padx=(0, 8))
        FlatButton(buttons, "Delete", self.delete, kind="danger").pack(side="left")
        FlatButton(form, "Clear form", self.clear, kind="quiet").grid(row=21, column=0, sticky="w", pady=(8, 0))
        self._selected = None

    def on_show(self, **_):
        self.table.set_rows(self.svc.suppliers.list(self.search.get()))

    def data(self):
        return {k: v.get() for k, v in self.vars.items()}

    def load_form(self, row):
        self._selected = row
        if row:
            for k, var in self.vars.items():
                var.set(row[k])

    def clear(self):
        self._selected = None
        for var in self.vars.values():
            var.set("")

    @safe
    def add(self):
        self.svc.suppliers.add(self.data(), self.uid)
        self.clear()
        self.on_show()
        self.app.toast("Supplier added")

    @safe
    def update(self):
        if not self._selected:
            raise BusinessRuleError("Select a supplier in the table first.")
        self.svc.suppliers.update(self._selected["id"], self.data(), self.uid)
        self.on_show()
        self.app.toast("Supplier updated")

    @safe
    def delete(self):
        if not self._selected:
            raise BusinessRuleError("Select a supplier in the table first.")
        if self.app.confirm(f"Delete supplier '{self._selected['company']}'?"):
            self.svc.suppliers.delete(self._selected["id"], self.uid)
            self.clear()
            self.on_show()
            self.app.toast("Supplier deleted")
