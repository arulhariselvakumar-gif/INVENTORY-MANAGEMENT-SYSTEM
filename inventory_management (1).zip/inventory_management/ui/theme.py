"""Colours, fonts and ttk styles. Palette: deep pine sidebar, pallet-label amber for emphasis,
quiet grey-green canvas, teal for primary actions."""
from tkinter import ttk

import config

C = {
    "ink": "#12302d", "ink_hover": "#1c4a45", "ink_text": "#c9dfda", "ink_muted": "#7fa39d",
    "accent": "#0f766e", "accent_dark": "#0a5a54", "amber": "#e0a526",
    "bg": "#f3f4f1", "card": "#ffffff", "line": "#dde2da", "stripe": "#f8f9f6",
    "text": "#1c2523", "muted": "#667470",
    "danger": "#b3402a", "danger_dark": "#8d2e1c", "ok": "#2c7a4b",
    "warn_bg": "#fbf0cf", "out_bg": "#f6d9d2", "ok_bg": "#e3f1e8", "grey_bg": "#ebeee9",
}
FONT = "Segoe UI"


def font(size=10, weight="normal"):
    return (FONT, size, weight)


def money(value):
    return f"{config.CURRENCY}{value:,.2f}"


def apply_theme(root):
    root.configure(bg=C["bg"])
    s = ttk.Style(root)
    s.theme_use("clam")
    s.configure(".", font=font(10), background=C["bg"], foreground=C["text"])
    s.configure("TFrame", background=C["bg"])
    s.configure("Card.TFrame", background=C["card"])
    s.configure("TLabel", background=C["bg"], foreground=C["text"])
    s.configure("Card.TLabel", background=C["card"])
    s.configure("Muted.TLabel", foreground=C["muted"])
    s.configure("CardMuted.TLabel", background=C["card"], foreground=C["muted"])
    s.configure("Title.TLabel", font=font(20, "bold"))
    s.configure("H2.TLabel", font=font(12, "bold"))
    s.configure("CardH2.TLabel", font=font(12, "bold"), background=C["card"])
    s.configure("TEntry", fieldbackground="white", bordercolor=C["line"], lightcolor=C["line"],
                darkcolor=C["line"], padding=6)
    s.map("TEntry", bordercolor=[("focus", C["accent"])], lightcolor=[("focus", C["accent"])])
    s.configure("TCombobox", fieldbackground="white", bordercolor=C["line"], padding=5, arrowsize=14)
    s.map("TCombobox", fieldbackground=[("readonly", "white")], bordercolor=[("focus", C["accent"])])
    s.configure("TSpinbox", fieldbackground="white", bordercolor=C["line"], padding=5)
    s.configure("Treeview", background="white", fieldbackground="white", rowheight=30, borderwidth=0,
                font=font(10), foreground=C["text"])
    s.configure("Treeview.Heading", background=C["grey_bg"], foreground=C["text"], font=font(10, "bold"),
                relief="flat", padding=(8, 7))
    s.map("Treeview.Heading", background=[("active", C["line"])])
    s.map("Treeview", background=[("selected", C["accent"])], foreground=[("selected", "white")])
    s.configure("TNotebook", background=C["bg"], borderwidth=0)
    s.configure("TNotebook.Tab", padding=(16, 8), font=font(10, "bold"), background=C["grey_bg"])
    s.map("TNotebook.Tab", background=[("selected", C["card"])], foreground=[("selected", C["accent"])])
    s.configure("TLabelframe", background=C["card"], bordercolor=C["line"])
    s.configure("TLabelframe.Label", background=C["card"], font=font(10, "bold"), foreground=C["accent"])
    s.configure("Vertical.TScrollbar", background=C["line"], troughcolor=C["bg"], borderwidth=0, arrowsize=12)
    s.configure("Horizontal.TScrollbar", background=C["line"], troughcolor=C["bg"], borderwidth=0, arrowsize=12)
    s.configure("TCheckbutton", background=C["card"])
    s.configure("TSeparator", background=C["line"])
