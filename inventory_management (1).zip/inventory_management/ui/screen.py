"""Base class for every page shown in the content area."""
import tkinter as tk
from tkinter import ttk

from ui.theme import font


class Screen(ttk.Frame):
    title = ""
    subtitle = ""

    def __init__(self, app):
        super().__init__(app.content)
        self.app, self.svc = app, app.svc
        head = ttk.Frame(self)
        head.pack(fill="x", padx=28, pady=(22, 10))
        ttk.Label(head, text=self.title, style="Title.TLabel").pack(anchor="w")
        if self.subtitle:
            ttk.Label(head, text=self.subtitle, style="Muted.TLabel").pack(anchor="w", pady=(2, 0))
        self.body = ttk.Frame(self)
        self.body.pack(fill="both", expand=True, padx=28, pady=(0, 22))
        self.build(self.body)

    @property
    def uid(self):
        return self.app.user["id"]

    def build(self, parent):
        raise NotImplementedError

    def on_show(self, **kwargs):
        """Called every time the page is opened - reload data here."""

    def card(self, parent, **grid_or_pack):
        frame = ttk.Frame(parent, style="Card.TFrame", padding=16)
        return frame

    @staticmethod
    def cat_pairs(svc):
        return [(c["id"], c["name"]) for c in svc.categories.list()]

    @staticmethod
    def sup_pairs(svc):
        return [(s["id"], s["company"]) for s in svc.suppliers.list()]

    @staticmethod
    def product_pairs(svc, products=None):
        products = products if products is not None else svc.products.list()
        return [(p["id"], f"{p['sku']} - {p['name']}  ({p['quantity']} in stock)") for p in products]


def safe(fn):
    """Decorator for button handlers: any error becomes a friendly message instead of a crash."""
    import functools

    @functools.wraps(fn)
    def wrapper(self, *args, **kwargs):
        try:
            return fn(self, *args, **kwargs)
        except Exception as exc:     # noqa: BLE001 - the UI must never die on a handler error
            self.app.handle_error(exc)
    return wrapper
