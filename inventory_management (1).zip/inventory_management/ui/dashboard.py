import tkinter as tk
from tkinter import ttk

from ui.screen import Screen
from ui.theme import C, font, money
from ui.widgets import DataTable, FlatButton, animate_number


class StatCard(tk.Frame):
    def __init__(self, master, caption, accent=None, command=None):
        super().__init__(master, bg=C["card"], highlightbackground=C["line"], highlightthickness=1, padx=16, pady=12,
                         cursor="hand2" if command else "")
        tk.Frame(self, bg=accent or C["accent"], width=36, height=3).pack(anchor="w")
        self.value = tk.Label(self, text="0", bg=C["card"], fg=C["text"], font=font(21, "bold"))
        self.value.pack(anchor="w", pady=(8, 0))
        tk.Label(self, text=caption, bg=C["card"], fg=C["muted"]).pack(anchor="w")
        self.note = tk.Label(self, text=" ", bg=C["card"], fg=C["muted"], font=font(9))
        self.note.pack(anchor="w")
        if command:
            for w in (self, self.value, self.note) + tuple(self.winfo_children()):
                w.bind("<Button-1>", lambda e: command())

    def show(self, number, formatter, note=" "):
        animate_number(self.value, number, formatter)
        self.note.configure(text=note)


class DashboardScreen(Screen):
    title = "Dashboard"
    subtitle = "Today's picture of stock, purchases and sales."

    def build(self, parent):
        grid = ttk.Frame(parent)
        grid.pack(fill="x")
        spec = [("products", "Products", None, "products"), ("units", "Units in stock", None, "products"),
                ("value", "Stock value (at cost)", None, "reports"), ("low", "Low-stock products", C["amber"], "lowstock"),
                ("suppliers", "Suppliers", None, "suppliers"), ("purchases", "Purchases received", None, "purchases"),
                ("sales", "Sales", None, "sales"), ("revenue", "Net sales revenue", None, "reports")]
        self.cards = {}
        for i, (key, caption, accent, target) in enumerate(spec):
            card = StatCard(grid, caption, accent, command=lambda t=target: self.app.navigate(t))
            card.grid(row=i // 4, column=i % 4, sticky="nsew", padx=(0, 12 if i % 4 < 3 else 0), pady=(0, 12))
            grid.columnconfigure(i % 4, weight=1, uniform="cards")
            self.cards[key] = card

        lower = ttk.Frame(parent)
        lower.pack(fill="both", expand=True, pady=(4, 0))
        lower.columnconfigure(0, weight=3, uniform="l")
        lower.columnconfigure(1, weight=2, uniform="l")
        lower.rowconfigure(0, weight=1)
        left = ttk.Frame(lower, style="Card.TFrame", padding=14)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 12))
        ttk.Label(left, text="Recent transactions", style="CardH2.TLabel").pack(anchor="w", pady=(0, 8))
        self.recent = DataTable(left, [("kind", "Type", 80, "w", None), ("ref", "Reference", 130, "w", None),
                                       ("party", "Customer / supplier", 170, "w", None),
                                       ("amount", "Amount", 100, "e", lambda v: money(v)),
                                       ("status", "Status", 110, "w", None)], height=8,
                                tag_func=lambda r: "done" if r["status"] in ("CANCELLED", "RETURNED") else "",
                                empty_text="No transactions yet. Record a purchase or a sale to see it here.")
        self.recent.pack(fill="both", expand=True)

        right = ttk.Frame(lower, style="Card.TFrame", padding=14)
        right.grid(row=0, column=1, sticky="nsew")
        top = ttk.Frame(right, style="Card.TFrame")
        top.pack(fill="x", pady=(0, 8))
        ttk.Label(top, text="Needs restocking", style="CardH2.TLabel").pack(side="left")
        FlatButton(top, "Open alerts", lambda: self.app.navigate("lowstock"), kind="quiet").pack(side="right")
        self.low = DataTable(right, [("name", "Product", 170, "w", None), ("quantity", "Left", 50, "e", None),
                                     ("status", "Status", 70, "w", None)], height=8,
                             tag_func=lambda r: "out" if r["status"] == "OUT" else "low",
                             empty_text="Nothing is running low.")
        self.low.pack(fill="both", expand=True)

    def on_show(self, **_):
        s = self.svc.reports.dashboard_stats()
        c = self.cards
        c["products"].show(s["total_products"], lambda v: f"{int(v):,}")
        c["units"].show(s["total_quantity"], lambda v: f"{int(v):,}")
        c["value"].show(s["stock_value"], lambda v: money(v))
        c["low"].show(s["low_stock"], lambda v: f"{int(v)}", f"{s['out_of_stock']} completely out of stock")
        c["suppliers"].show(s["suppliers"], lambda v: f"{int(v)}")
        c["purchases"].show(s["purchases"], lambda v: f"{int(v)}", f"{money(s['purchase_spend'])} spent")
        c["sales"].show(s["sales"], lambda v: f"{int(v)}", "completed or partly returned")
        c["revenue"].show(s["sales_revenue"], lambda v: money(v), "after discounts and returns, excl. tax")
        self.recent.set_rows(self.svc.reports.recent_transactions())
        self.low.set_rows(self.svc.inventory.low_stock()[:12])
