"""Main window: login -> sidebar shell, navigation with a short slide-in, toasts and error handling."""
import logging
import os
import sqlite3
import tkinter as tk
from tkinter import messagebox, ttk

import config
from errors import InventoryError
from ui.theme import C, apply_theme, font
from ui.widgets import Dialog, FlatButton, mix

NAV = [("dashboard", "Dashboard"), ("products", "Products"), ("categories", "Categories"),
       ("suppliers", "Suppliers"), ("purchases", "Purchases"), ("sales", "Sales and invoices"),
       ("stock", "Stock control"), ("lowstock", "Low-stock alerts"), ("search", "Search and sort lab"),
       ("reports", "Reports and charts"), ("backup", "Backup and restore")]


def _screen_classes():
    """Imported lazily so a problem in one screen cannot stop the login window from opening."""
    from ui.dashboard import DashboardScreen
    from ui.products import ProductsScreen
    from ui.masters import CategoriesScreen, SuppliersScreen
    from ui.purchases import PurchasesScreen
    from ui.sales import SalesScreen
    from ui.stock import StockScreen, LowStockScreen
    from ui.search import SearchScreen
    from ui.reports import ReportsScreen
    from ui.backup import BackupScreen
    return {"dashboard": DashboardScreen, "products": ProductsScreen, "categories": CategoriesScreen,
            "suppliers": SuppliersScreen, "purchases": PurchasesScreen, "sales": SalesScreen,
            "stock": StockScreen, "lowstock": LowStockScreen, "search": SearchScreen,
            "reports": ReportsScreen, "backup": BackupScreen}


class NavItem(tk.Frame):
    def __init__(self, master, text, command):
        super().__init__(master, bg=C["ink"], cursor="hand2")
        self.bar = tk.Frame(self, bg=C["ink"], width=4)
        self.bar.pack(side="left", fill="y")
        self.label = tk.Label(self, text=text, bg=C["ink"], fg=C["ink_text"], font=font(10), anchor="w", padx=18, pady=9)
        self.label.pack(side="left", fill="x", expand=True)
        self.active, self._bg, self._job = False, C["ink"], None
        for w in (self, self.label, self.bar):
            w.bind("<Button-1>", lambda e: command())
            w.bind("<Enter>", lambda e: self._fade(C["ink_hover"]))
            w.bind("<Leave>", lambda e: self._fade(C["ink_hover"] if self.active else C["ink"]))

    def _fade(self, target, steps=5):
        if self._job:
            self.after_cancel(self._job)
        start = self._bg

        def step(i=1):
            self._bg = mix(start, target, i / steps)
            for w in (self, self.label):
                w.configure(bg=self._bg)
            self._job = self.after(14, step, i + 1) if i < steps else None
        step()

    def set_active(self, active):
        self.active = active
        self.bar.configure(bg=C["amber"] if active else C["ink"])
        self.label.configure(fg="white" if active else C["ink_text"], font=font(10, "bold" if active else "normal"))
        self._fade(C["ink_hover"] if active else C["ink"])


class App(tk.Tk):
    def __init__(self, svc):
        super().__init__()
        self.svc, self.user = svc, None
        self.title(config.APP_NAME)
        self.geometry("1320x800")
        self.minsize(1120, 700)
        apply_theme(self)
        self.screens, self.nav_items, self.current, self._toast, self._toast_job = {}, {}, None, None, None
        logging.basicConfig(filename=os.path.join(config.DATA_DIR, "app.log"), level=logging.ERROR)
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.bind("<F5>", lambda e: self.refresh_current())
        self.shell = None
        self.show_login()
        self._fade_in(0.0)

    def _fade_in(self, alpha):
        try:
            self.attributes("-alpha", alpha)
            if alpha < 1:
                self.after(18, self._fade_in, min(alpha + 0.12, 1.0))
        except tk.TclError:
            pass

    # ---------- login / shell ----------
    def show_login(self):
        from ui.login import LoginScreen
        if self.shell:
            self.shell.destroy()
            self.shell = None
        self.screens, self.nav_items, self.current = {}, {}, None
        self.login = LoginScreen(self)
        self.login.pack(fill="both", expand=True)

    def on_login(self, user):
        self.user = user
        self.login.destroy()
        self.shell = tk.Frame(self, bg=C["bg"])
        self.shell.pack(fill="both", expand=True)
        self.shell.columnconfigure(1, weight=1)
        self.shell.rowconfigure(0, weight=1)
        self._build_sidebar()
        self.content = tk.Frame(self.shell, bg=C["bg"])
        self.content.grid(row=0, column=1, sticky="nsew")
        self._classes = _screen_classes()
        self.navigate("dashboard")

    def _build_sidebar(self):
        side = tk.Frame(self.shell, bg=C["ink"], width=236)
        side.grid(row=0, column=0, sticky="ns")
        side.grid_propagate(False)
        side.pack_propagate(False)
        tk.Label(side, text=config.APP_NAME, bg=C["ink"], fg="white", font=font(15, "bold"), anchor="w",
                 padx=20).pack(fill="x", pady=(24, 2))
        tk.Frame(side, bg=C["amber"], height=3, width=40).pack(anchor="w", padx=20, pady=(0, 18))
        for key, text in NAV:
            item = NavItem(side, text, lambda k=key: self.navigate(k))
            item.pack(fill="x")
            self.nav_items[key] = item
        tk.Frame(side, bg=C["ink"]).pack(fill="both", expand=True)
        tk.Label(side, text=f"Signed in as {self.user['username']}", bg=C["ink"], fg=C["ink_muted"], anchor="w",
                 padx=20).pack(fill="x")
        row = tk.Frame(side, bg=C["ink"])
        row.pack(fill="x", padx=14, pady=(6, 18))
        FlatButton(row, "Password", self.change_password, kind="ghost").pack(side="left", padx=(6, 6))
        FlatButton(row, "Sign out", self.logout, kind="amber").pack(side="left")

    # ---------- navigation ----------
    def navigate(self, key, **kwargs):
        if key not in self.screens:
            self.screens[key] = self._classes[key](self)
        screen = self.screens[key]
        if self.current and self.current != key:
            self.screens[self.current].place_forget()
            self.nav_items[self.current].set_active(False)
        self.current = key
        self.nav_items[key].set_active(True)
        screen.on_show(**kwargs)
        self._slide_in(screen, 28)

    def _slide_in(self, screen, offset):
        """Content glides 28 px into place - confirms that the click changed the page."""
        screen.place(x=offset, y=0, relwidth=1, relheight=1)
        screen.lift()
        if offset > 0:
            self.after(14, self._slide_in, screen, max(offset - 7, 0))

    def refresh_current(self):
        if self.current:
            self.screens[self.current].on_show()

    # ---------- feedback ----------
    def toast(self, message, kind="ok"):
        """Small notice that slides in at the bottom-right and fades away by itself."""
        if self._toast is not None:
            self._toast.destroy()
        if self._toast_job:
            self.after_cancel(self._toast_job)
        colours = {"ok": (C["ok"], "white"), "info": (C["ink"], "white"), "warn": (C["amber"], C["ink"])}
        bg, fg = colours.get(kind, colours["ok"])
        self._toast = tk.Label(self, text=message, bg=bg, fg=fg, font=font(10, "bold"), padx=18, pady=11)
        self._slide_toast(self._toast, 120)
        self._toast_job = self.after(3200, self._dismiss_toast)

    def _slide_toast(self, widget, offset):
        try:
            widget.place(relx=1.0, rely=1.0, anchor="se", x=-24 + offset, y=-24)
            widget.lift()
            if offset > 0:
                self.after(12, self._slide_toast, widget, max(offset - 24, 0))
        except tk.TclError:
            pass

    def _dismiss_toast(self):
        if self._toast is not None:
            self._toast.destroy()
            self._toast = None

    def confirm(self, message, title="Please confirm"):
        return messagebox.askyesno(title, message, parent=self)

    def handle_error(self, exc):
        if isinstance(exc, InventoryError):
            messagebox.showwarning("Please check", str(exc), parent=self)
        elif isinstance(exc, sqlite3.Error):
            logging.exception("Database error")
            messagebox.showerror("Database problem",
                                 f"The database could not complete that action and nothing was changed.\n\n{exc}", parent=self)
        else:
            logging.exception("Unexpected error")
            messagebox.showerror("Something went wrong",
                                 "An unexpected error stopped that action. Details were saved to data/app.log.\n\n"
                                 f"{type(exc).__name__}: {exc}", parent=self)

    # ---------- account ----------
    def change_password(self):
        dlg = Dialog(self, "Change password", 400)
        vars_ = [tk.StringVar() for _ in range(3)]
        for i, (label, var) in enumerate(zip(("Current password", "New password (8+ characters, letters and digits)",
                                              "Repeat new password"), vars_)):
            ttk.Label(dlg.body, text=label, style="CardMuted.TLabel").grid(row=i * 2, column=0, sticky="w")
            ttk.Entry(dlg.body, textvariable=var, show="•", width=40).grid(row=i * 2 + 1, column=0, pady=(2, 10))

        def save():
            try:
                if vars_[1].get() != vars_[2].get():
                    raise InventoryError("The two new passwords do not match.")
                self.svc.auth.change_password(self.user["id"], vars_[0].get(), vars_[1].get())
            except Exception as exc:
                self.handle_error(exc)
                return
            dlg.destroy()
            self.toast("Password changed")
        FlatButton(dlg.body, "Save password", save).grid(row=6, column=0, sticky="e", pady=(6, 0))

    def logout(self):
        if not self.confirm("Sign out of the application?"):
            return
        self.svc.auth.logout(self.user)
        self.svc.undo.stack.clear()
        self.user = None
        self.show_login()

    def force_logout(self, message):
        """Used after a restore: the data underneath changed, so everyone signs in again."""
        self.svc.undo.stack.clear()
        self.user = None
        self.show_login()
        self.login.message.configure(text=message, fg=C["ok"])

    def on_close(self):
        try:
            self.svc.close()
        finally:
            self.destroy()
