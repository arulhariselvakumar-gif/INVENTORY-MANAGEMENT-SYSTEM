import os
import sys
from tkinter import filedialog, ttk

import config
from errors import BusinessRuleError
from ui.screen import Screen, safe
from ui.widgets import DataTable, FlatButton


class BackupScreen(Screen):
    title = "Backup and restore"
    subtitle = "Copy your whole database to a safe file, or bring an earlier copy back."

    def build(self, parent):
        top = ttk.Frame(parent, style="Card.TFrame", padding=18)
        top.pack(fill="x")
        ttk.Label(top, text="Back up", style="CardH2.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(top, text=f"Backups are saved in:  {config.BACKUP_DIR}", style="CardMuted.TLabel").grid(row=1, column=0, sticky="w", pady=(2, 10))
        row = ttk.Frame(top, style="Card.TFrame")
        row.grid(row=2, column=0, sticky="w")
        FlatButton(row, "Back up now", self.backup_now).pack(side="left", padx=(0, 8))
        FlatButton(row, "Back up to a chosen file...", self.backup_as, kind="ghost").pack(side="left", padx=(0, 8))
        FlatButton(row, "Open backup folder", self.open_folder, kind="quiet").pack(side="left")

        lst = ttk.Frame(parent, style="Card.TFrame", padding=18)
        lst.pack(fill="both", expand=True, pady=(12, 0))
        head = ttk.Frame(lst, style="Card.TFrame")
        head.pack(fill="x", pady=(0, 8))
        ttk.Label(head, text="Restore", style="CardH2.TLabel").pack(side="left")
        FlatButton(head, "Restore from a file...", self.restore_file, kind="ghost").pack(side="right")
        FlatButton(head, "Restore selected backup", self.restore_selected, kind="danger").pack(side="right", padx=8)
        ttk.Label(lst, text="Restoring replaces all current data. A safety copy of today's data is made first, and you will sign in again.",
                  style="CardMuted.TLabel").pack(anchor="w", pady=(0, 8))
        self.table = DataTable(lst, [("name", "Backup file", 330, "w", None), ("modified", "Created", 160, "w", None),
                                     ("size_kb", "Size (KB)", 90, "e", None)], height=8,
                               empty_text="No backups yet. Use 'Back up now'.")
        self.table.pack(fill="both", expand=True)

    def on_show(self, **_):
        self.table.set_rows(self.svc.backup.list_backups())

    @safe
    def backup_now(self):
        path = self.svc.backup.backup()
        self.svc.db.log(self.uid, "BACKUP_CREATED", os.path.basename(path))
        self.on_show()
        self.app.toast("Backup created: " + os.path.basename(path))

    @safe
    def backup_as(self):
        path = filedialog.asksaveasfilename(parent=self.app, defaultextension=".db", initialdir=config.BACKUP_DIR,
                                            initialfile="inventory_backup.db", filetypes=[("Database backup", "*.db")])
        if path:
            self.svc.backup.backup(path)
            self.svc.db.log(self.uid, "BACKUP_CREATED", os.path.basename(path))
            self.on_show()
            self.app.toast("Backup saved")

    @safe
    def open_folder(self):
        os.makedirs(config.BACKUP_DIR, exist_ok=True)
        if sys.platform.startswith("win"):
            os.startfile(config.BACKUP_DIR)     # noqa: S606 - Windows only, folder we created
        else:
            raise BusinessRuleError(f"Open this folder yourself: {config.BACKUP_DIR}")

    def _restore(self, path):
        self.svc.backup.verify(path)
        if not self.app.confirm(f"Replace ALL current data with:\n{os.path.basename(path)}?\n\nA safety copy of the current data "
                                "is made first. You will be signed out."):
            return
        safety = self.svc.backup.restore(path)
        self.app.force_logout(f"Restore complete. Previous data was saved as {os.path.basename(safety)}. Please sign in.")

    @safe
    def restore_selected(self):
        row = self.table.selected()
        if row is None:
            raise BusinessRuleError("Select a backup in the list first.")
        self._restore(row["path"])

    @safe
    def restore_file(self):
        path = filedialog.askopenfilename(parent=self.app, initialdir=config.BACKUP_DIR, filetypes=[("Database backup", "*.db")])
        if path:
            self._restore(path)
