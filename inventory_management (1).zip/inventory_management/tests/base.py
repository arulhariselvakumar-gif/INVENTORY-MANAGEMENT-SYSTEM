"""Shared test fixture: every test gets a brand-new temporary database (your real data is never touched)."""
import os
import shutil
import tempfile
import unittest

from services.container import Services


class DbTestCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmp, "test.db")
        self.svc = Services(self.db_path, os.path.join(self.tmp, "backups"))
        self.uid = self.svc.auth.login("admin", "Admin@123")["id"]
        self.cat = self.svc.categories.add("General", "", self.uid)
        self.sup = self.svc.suppliers.add({"name": "Ravi", "company": "Acme Traders", "phone": "9840011122",
                                           "email": "r@acme.example", "address": "Chennai"}, self.uid)

    def tearDown(self):
        self.svc.close()
        shutil.rmtree(self.tmp, ignore_errors=True)

    def make_product(self, sku="SKU-1", name="Widget", cost=10, price=20, qty=50, reorder=5, supplier=True):
        return self.svc.products.add({"sku": sku, "name": name, "category_id": self.cat,
                                      "supplier_id": self.sup if supplier else None, "cost_price": cost,
                                      "selling_price": price, "quantity": qty, "reorder_level": reorder,
                                      "description": ""}, self.uid)

    def qty(self, pid):
        return self.svc.products.get(pid)["quantity"]
