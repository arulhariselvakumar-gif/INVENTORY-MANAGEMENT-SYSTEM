import sqlite3
import unittest

from errors import (BusinessRuleError, DuplicateTransactionError, InsufficientStockError, ValidationError)
from services.sales_service import calc_totals
from tests.base import DbTestCase


class PurchaseTests(DbTestCase):
    def test_draft_does_not_change_stock_confirm_does_once(self):
        pid = self.make_product(qty=10)
        pur = self.svc.purchases.create(self.sup, "2026-02-01", [(pid, 25, 8.5)], "test", self.uid)
        self.assertEqual(self.qty(pid), 10)
        self.svc.purchases.confirm(pur, self.uid)
        self.assertEqual(self.qty(pid), 35)
        with self.assertRaises(BusinessRuleError):                       # "reopened" / double click
            self.svc.purchases.confirm(pur, self.uid)
        self.assertEqual(self.qty(pid), 35)
        head = self.svc.purchases.get(pur)
        self.assertEqual((head["status"], head["total_cost"]), ("CONFIRMED", 212.5))
        self.assertTrue(head["purchase_no"].startswith("PO-202602-"))

    def test_multi_item_total_and_validation(self):
        a, b = self.make_product("P-A", "A"), self.make_product("P-B", "B")
        pur = self.svc.purchases.create(self.sup, "2026-02-01", [(a, 10, 1.25), (b, 3, 100)], user_id=self.uid)
        self.assertEqual(self.svc.purchases.get(pur)["total_cost"], 312.5)
        for items in ([], [(a, 0, 5)], [(a, 1, -5)], [(a, 1, 5), (a, 2, 5)], [(999, 1, 5)]):
            with self.assertRaises(ValidationError):
                self.svc.purchases.create(self.sup, "2026-02-01", items, user_id=self.uid)
        with self.assertRaises(ValidationError):
            self.svc.purchases.create(self.sup, "01/02/2026", [(a, 1, 5)], user_id=self.uid)

    def test_cancel_rules_and_duplicate_token(self):
        pid = self.make_product(qty=1)
        draft = self.svc.purchases.create(self.sup, "2026-02-01", [(pid, 5, 1)], user_id=self.uid, request_token="tok-1")
        with self.assertRaises(DuplicateTransactionError):
            self.svc.purchases.create(self.sup, "2026-02-01", [(pid, 5, 1)], user_id=self.uid, request_token="tok-1")
        self.assertEqual(len(self.svc.purchases.list()), 1)
        self.svc.purchases.cancel(draft, self.uid)
        with self.assertRaises(BusinessRuleError):
            self.svc.purchases.confirm(draft, self.uid)
        done = self.svc.purchases.create(self.sup, "2026-02-01", [(pid, 5, 1)], user_id=self.uid, confirm=True)
        with self.assertRaises(BusinessRuleError):
            self.svc.purchases.cancel(done, self.uid)

    def test_failed_confirm_rolls_back_everything(self):
        pid = self.make_product(qty=1)
        pur = self.svc.purchases.create(self.sup, "2026-02-01", [(pid, 5, 1)], user_id=self.uid)
        self.svc.db.execute("DROP TRIGGER IF EXISTS x")
        self.svc.db.execute("CREATE TRIGGER x BEFORE INSERT ON stock_movements BEGIN SELECT RAISE(ABORT,'boom'); END")
        with self.assertRaises(sqlite3.Error):
            self.svc.purchases.confirm(pur, self.uid)
        self.svc.db.execute("DROP TRIGGER x")
        self.assertEqual(self.svc.purchases.get(pur)["status"], "DRAFT")   # status flip was rolled back too
        self.assertEqual(self.qty(pid), 1)


class SalesTests(DbTestCase):
    def test_calc_totals_exact_decimal_rounding(self):
        t = calc_totals([(3, 19.99), (1, 0.10)], 10, 18)
        self.assertEqual(t, {"subtotal": 60.07, "discount_amount": 6.01, "tax_amount": 9.73, "total": 63.79})
        self.assertEqual(calc_totals([(1, 100)], 0, 0)["total"], 100.0)

    def test_successful_sale_deducts_stock_and_stores_totals(self):
        a, b = self.make_product("S-A", "A", price=100, qty=10), self.make_product("S-B", "B", price=50, qty=5)
        sid = self.svc.sales.create([(a, 2), (b, 1)], "Priya", 10, 18, self.uid)
        sale = self.svc.sales.get(sid)
        self.assertEqual((sale["subtotal"], sale["discount_amount"], sale["tax_amount"], sale["total"]),
                         (250.0, 25.0, 40.5, 265.5))
        self.assertEqual((self.qty(a), self.qty(b)), (8, 4))
        self.assertTrue(sale["invoice_no"].startswith("INV-") and sale["customer_name"] == "Priya")
        self.assertIn("265.50", self.svc.sales.invoice_text(sid))

    def test_invoice_numbers_are_unique(self):
        pid = self.make_product(qty=10)
        numbers = {self.svc.sales.get(self.svc.sales.create([(pid, 1)], user_id=self.uid))["invoice_no"] for _ in range(4)}
        self.assertEqual(len(numbers), 4)

    def test_insufficient_stock_rejects_whole_sale(self):
        ok, short = self.make_product("R-OK", "Ok", qty=10), self.make_product("R-SH", "Short", qty=2)
        with self.assertRaises(InsufficientStockError):
            self.svc.sales.create([(ok, 3), (short, 5)], user_id=self.uid)
        self.assertEqual((self.qty(ok), self.qty(short)), (10, 2))          # first line was NOT deducted
        self.assertEqual(self.svc.sales.list(), [])                         # no half-saved invoice
        self.assertEqual(self.svc.db.scalar("SELECT COUNT(*) FROM sale_items"), 0)

    def test_duplicate_lines_merge_and_validation(self):
        pid = self.make_product(qty=10)
        sid = self.svc.sales.create([(pid, 2), (pid, 3)], user_id=self.uid)
        self.assertEqual([i["quantity"] for i in self.svc.sales.get(sid)["items"]], [5])
        for kwargs in (dict(items=[]), dict(items=[(pid, 0)]), dict(items=[(pid, 1)], discount_percent=101),
                       dict(items=[(pid, 1)], tax_percent=-1), dict(items=[(pid, 1)], discount_percent="x")):
            with self.assertRaises(ValidationError):
                self.svc.sales.create(user_id=self.uid, **kwargs)

    def test_duplicate_submit_is_blocked(self):
        pid = self.make_product(qty=10)
        self.svc.sales.create([(pid, 2)], user_id=self.uid, request_token="form-1")
        with self.assertRaises(DuplicateTransactionError):
            self.svc.sales.create([(pid, 2)], user_id=self.uid, request_token="form-1")
        self.assertEqual((self.qty(pid), len(self.svc.sales.list())), (8, 1))

    def test_partial_return_then_cancel_restore_stock(self):
        pid = self.make_product(qty=10, price=100)
        sid = self.svc.sales.create([(pid, 4)], "Kavya", 10, 18, self.uid)
        item = self.svc.sales.get(sid)["items"][0]["id"]
        refund = self.svc.sales.return_items(sid, {item: 1}, "faulty", self.uid)
        self.assertEqual(refund, 106.20)                                    # 100 - 10% = 90, +18% = 106.20
        self.assertEqual((self.qty(pid), self.svc.sales.get(sid)["status"]), (7, "PARTIAL_RETURN"))
        with self.assertRaises(BusinessRuleError):
            self.svc.sales.return_items(sid, {item: 4}, "too many", self.uid)
        self.assertEqual(self.qty(pid), 7)
        self.svc.sales.cancel(sid, "customer left", self.uid)
        self.assertEqual((self.qty(pid), self.svc.sales.get(sid)["status"]), (10, "CANCELLED"))
        with self.assertRaises(BusinessRuleError):
            self.svc.sales.cancel(sid, "again", self.uid)

    def test_full_return_marks_returned_and_stock_matches_history(self):
        pid = self.make_product(qty=10)
        sid = self.svc.sales.create([(pid, 3)], user_id=self.uid)
        item = self.svc.sales.get(sid)["items"][0]["id"]
        self.svc.sales.return_items(sid, {item: 3}, "wrong item", self.uid)
        self.assertEqual(self.svc.sales.get(sid)["status"], "RETURNED")
        self.assertEqual(self.svc.inventory.verify_consistency(), [])

    def test_failed_sale_rolls_back_with_midway_database_error(self):
        a, b = self.make_product("T-A", "A", qty=10), self.make_product("T-B", "B", qty=10)
        self.svc.db.execute("CREATE TRIGGER boom BEFORE INSERT ON stock_movements WHEN NEW.quantity_change = -4 "
                            "BEGIN SELECT RAISE(ABORT,'disk error'); END")
        with self.assertRaises(sqlite3.Error):
            self.svc.sales.create([(a, 1), (b, 4)], user_id=self.uid)
        self.assertEqual((self.qty(a), self.qty(b), self.svc.sales.list()), (10, 10, []))


if __name__ == "__main__":
    unittest.main()
