import unittest

import auth
from errors import (AuthError, BusinessRuleError, DuplicateError, InsufficientStockError, ValidationError)
from tests.base import DbTestCase


class LoginTests(DbTestCase):
    def test_login_success_and_failures(self):
        self.assertEqual(self.svc.auth.login("admin", "Admin@123")["username"], "admin")
        with self.assertRaises(AuthError):
            self.svc.auth.login("admin", "wrong")
        with self.assertRaises(AuthError):
            self.svc.auth.login("nobody", "Admin@123")
        with self.assertRaises(ValidationError):
            self.svc.auth.login("", "")

    def test_password_is_hashed_and_salted(self):
        stored = self.svc.db.scalar("SELECT password_hash FROM users WHERE username='admin'")
        self.assertNotIn("Admin@123", stored)
        self.assertTrue(auth.verify_password("Admin@123", stored))
        self.assertNotEqual(auth.hash_password("x1234567"), auth.hash_password("x1234567"))

    def test_lockout_after_repeated_failures(self):
        for _ in range(5):
            with self.assertRaises(AuthError):
                self.svc.auth.login("admin", "bad")
        with self.assertRaises(AuthError) as ctx:
            self.svc.auth.login("admin", "Admin@123")       # correct password, but locked
        self.assertIn("Too many", str(ctx.exception))

    def test_change_password(self):
        self.svc.auth.change_password(self.uid, "Admin@123", "NewPass123")
        self.assertEqual(self.svc.auth.login("admin", "NewPass123")["id"], self.uid)
        with self.assertRaises(ValidationError):
            self.svc.auth.change_password(self.uid, "NewPass123", "short")


class ProductTests(DbTestCase):
    def test_add_and_codes_and_opening_movement(self):
        a, b = self.make_product("AAA-1", "A", qty=10), self.make_product("BBB-2", "B", qty=0)
        self.assertEqual(self.svc.products.get(a)["product_code"], "P0001")
        self.assertEqual(self.svc.products.get(b)["product_code"], "P0002")
        self.assertEqual(len(self.svc.inventory.history_list(a)), 1)
        self.assertEqual(len(self.svc.inventory.history_list(b)), 0)

    def test_duplicate_sku_is_rejected_case_insensitively(self):
        self.make_product("DUP-1")
        with self.assertRaises(DuplicateError):
            self.make_product("dup-1", "Other")
        self.assertEqual(len(self.svc.products.list()), 1)    # nothing half-saved

    def test_validation(self):
        base = dict(sku="OK-1", name="N", category_id=self.cat, cost_price=1, selling_price=2, quantity=1, reorder_level=1)
        for bad in ({"name": ""}, {"sku": "a b"}, {"cost_price": "abc"}, {"selling_price": -5},
                    {"quantity": "1.5"}, {"quantity": -3}, {"reorder_level": "x"}, {"category_id": None}):
            with self.assertRaises(ValidationError, msg=str(bad)):
                self.svc.products.add({**base, **bad}, self.uid)

    def test_update_does_not_touch_stock_and_returns_old_values(self):
        pid = self.make_product(qty=7)
        old = self.svc.products.update(pid, {"sku": "SKU-1", "name": "Renamed", "category_id": self.cat,
                                             "cost_price": 11, "selling_price": 25, "reorder_level": 3}, self.uid)
        self.assertEqual(old["name"], "Widget")
        now = self.svc.products.get(pid)
        self.assertEqual((now["name"], now["quantity"]), ("Renamed", 7))

    def test_delete_vs_archive(self):
        fresh, used = self.make_product("NEW-1", "Fresh"), self.make_product("USE-1", "Used")
        self.svc.sales.create([(used, 1)], user_id=self.uid)
        self.assertEqual(self.svc.products.delete(fresh, self.uid), "deleted")
        self.assertEqual(self.svc.products.delete(used, self.uid), "archived")
        self.assertEqual(self.svc.products.list(), [])
        self.assertEqual(len(self.svc.products.list(include_inactive=True)), 1)

    def test_list_filters_and_status(self):
        self.make_product("S-OK", "Plenty", qty=50, reorder=5)
        self.make_product("S-LOW", "Few", qty=3, reorder=5)
        self.make_product("S-OUT", "None", qty=0, reorder=5)
        by = lambda st: [p["sku"] for p in self.svc.products.list(status=st)]
        self.assertEqual((by("OK"), by("LOW"), by("OUT")), (["S-OK"], ["S-LOW"], ["S-OUT"]))
        self.assertEqual(len(self.svc.products.list(search="few")), 1)

    def test_categories_cannot_be_deleted_while_used(self):
        self.make_product()
        with self.assertRaises(BusinessRuleError):
            self.svc.categories.delete(self.cat, user_id=self.uid)
        other = self.svc.categories.add("Other")
        self.assertEqual(self.svc.categories.delete(self.cat, reassign_to=other, user_id=self.uid), 1)
        self.assertEqual(self.svc.products.list()[0]["category"], "Other")

    def test_supplier_rules(self):
        with self.assertRaises(DuplicateError):
            self.svc.suppliers.add({"name": "X", "company": "acme traders", "phone": "9840011122"})
        with self.assertRaises(ValidationError):
            self.svc.suppliers.add({"name": "X", "company": "New Co", "phone": "abc"})
        self.make_product()
        with self.assertRaises(BusinessRuleError):
            self.svc.suppliers.delete(self.sup)
        self.assertEqual(len(self.svc.suppliers.list("acme")), 1)


class SearchSortIndexTests(DbTestCase):
    def setUp(self):
        super().setUp()
        for i, (name, price, qty) in enumerate([("Zebra pen", 30, 5), ("Apple cable", 99, 40), ("Mango mouse", 450, 12),
                                               ("Apple charger", 700, 3), ("Kiwi case", 120, 0)]):
            self.make_product(f"IDX-{i}", name, cost=price / 2, price=price, qty=qty)
        self.index = self.svc.products.build_index()

    def test_all_methods_find_same_product(self):
        for method in ("hash_lookup", "linear", "binary"):
            for field in ("id", "sku"):
                value = 3 if field == "id" else "idx-2"
                res = getattr(self.index, method)(field, value)
                self.assertEqual([p["name"] for p in res["results"]], ["Mango mouse"], (method, field))

    def test_not_found_and_bad_input(self):
        for method in ("hash_lookup", "linear", "binary"):
            self.assertEqual(getattr(self.index, method)("sku", "nope")["results"], [])
        self.assertEqual(self.index.hash_lookup("id", "abc")["results"], [])
        self.assertEqual(self.index.binary("id", "abc")["results"], [])

    def test_name_search_with_duplicates_and_prefix(self):
        self.make_product("IDX-9", "Apple cable", qty=1)
        index = self.svc.products.build_index()
        self.assertEqual(len(index.binary("name", "apple cable")["results"]), 2)
        self.assertEqual(len(index.linear("name", "Apple Cable")["results"]), 2)
        self.assertEqual(sorted(p["name"] for p in index.name_prefix("app")["results"]),
                         ["Apple cable", "Apple cable", "Apple charger"])

    def test_binary_is_cheaper_than_linear(self):
        for i in range(100, 160):
            self.make_product(f"BULK-{i}", f"Bulk {i}", qty=1)
        index = self.svc.products.build_index()
        self.assertLess(index.binary("sku", "BULK-159")["comparisons"], index.linear("sku", "BULK-159")["comparisons"])

    def test_sort_by_every_key_and_algorithm_agree(self):
        for key in ("name", "price", "quantity", "stock_value"):
            for desc in (False, True):
                bub = self.index.sort(key, "bubble", desc)["results"]
                mer = self.index.sort(key, "merge", desc)["results"]
                self.assertEqual([p["id"] for p in bub], [p["id"] for p in mer], (key, desc))
        self.assertEqual(self.index.sort("price", "merge")["results"][0]["name"], "Zebra pen")

    def test_bubble_sort_refuses_huge_input(self):
        import config
        old, config.BUBBLE_SORT_LIMIT = config.BUBBLE_SORT_LIMIT, 3
        try:
            with self.assertRaises(BusinessRuleError):
                self.index.sort("name", "bubble")
        finally:
            config.BUBBLE_SORT_LIMIT = old


if __name__ == "__main__":
    unittest.main()
