import random
import unittest

from dsa.binary_search_tree import BinarySearchTree
from dsa.hash_table import HashTable
from dsa.linked_list import LinkedList
from dsa.queue_ds import Queue
from dsa.searching import binary_search, linear_search
from dsa.sorting import bubble_sort, merge_sort
from dsa.stack import Stack


class StackTests(unittest.TestCase):
    def test_lifo_order(self):
        s = Stack()
        for x in (1, 2, 3):
            s.push(x)
        self.assertEqual([s.pop(), s.pop(), s.pop()], [3, 2, 1])

    def test_empty_errors(self):
        s = Stack()
        self.assertTrue(s.is_empty())
        with self.assertRaises(IndexError):
            s.pop()
        with self.assertRaises(IndexError):
            s.peek()

    def test_capacity_drops_oldest(self):
        s = Stack(capacity=2)
        for x in (1, 2, 3):
            s.push(x)
        self.assertEqual(s.to_list(), [3, 2])


class QueueTests(unittest.TestCase):
    def test_fifo_and_growth_with_wraparound(self):
        q = Queue(capacity=2)
        for i in range(3):
            q.enqueue(i)
        self.assertEqual(q.dequeue(), 0)
        for i in range(3, 12):          # forces wrap-around and several growths
            q.enqueue(i)
        self.assertEqual(q.to_list(), list(range(1, 12)))
        self.assertEqual([q.dequeue() for _ in range(11)], list(range(1, 12)))
        self.assertTrue(q.is_empty())

    def test_empty_errors(self):
        q = Queue()
        with self.assertRaises(IndexError):
            q.dequeue()
        with self.assertRaises(IndexError):
            q.front()


class LinkedListTests(unittest.TestCase):
    def test_prepend_append_reverse_remove(self):
        ll = LinkedList()
        ll.append(2)
        ll.prepend(1)
        ll.append(3)
        self.assertEqual(ll.to_list(), [1, 2, 3])
        ll.reverse()
        self.assertEqual(ll.to_list(), [3, 2, 1])
        self.assertTrue(ll.remove_first(lambda v: v == 2))
        self.assertFalse(ll.remove_first(lambda v: v == 99))
        self.assertEqual((ll.to_list(), len(ll)), ([3, 1], 2))
        self.assertEqual(ll.find(lambda v: v == 1), 1)
        self.assertIsNone(ll.find(lambda v: v == 7))


class HashTableTests(unittest.TestCase):
    def test_put_get_overwrite_remove_resize(self):
        h = HashTable(buckets=4)
        for i in range(100):
            h.put(f"k{i}", i)
        self.assertEqual(len(h), 100)
        self.assertGreater(h.bucket_count(), 4)
        h.put("k5", "new")
        self.assertEqual(h.get("k5"), "new")
        self.assertEqual(len(h), 100)
        self.assertTrue(h.remove("k5"))
        self.assertFalse(h.remove("k5"))
        self.assertIsNone(h.get("k5"))
        self.assertIn("k6", h)

    def test_collisions_are_handled(self):
        class Bad:                       # every key lands in the same bucket
            def __init__(self, n): self.n = n
            def __hash__(self): return 1
            def __eq__(self, o): return self.n == o.n
        h = HashTable()
        for i in range(10):
            h.put(Bad(i), i)
        self.assertEqual([h.get(Bad(i)) for i in range(10)], list(range(10)))


class BSTTests(unittest.TestCase):
    def test_inorder_is_sorted_and_duplicates_kept(self):
        keys = ["pear", "apple", "fig", "apple", "kiwi"]
        t = BinarySearchTree()
        for k in keys:
            t.insert(k, k)
        self.assertEqual(t.inorder(), sorted(keys))
        self.assertEqual(t.search("apple"), ["apple", "apple"])
        self.assertEqual(t.search("zzz"), [])
        self.assertEqual((t.min_key(), t.max_key()), ("apple", "pear"))

    def test_prefix_search(self):
        words = ["usb cable", "usb hub", "ups", "mouse", "usbc", "u"]
        t = BinarySearchTree.build_balanced([(w, w) for w in words])
        self.assertEqual(sorted(t.prefix_search("usb")), ["usb cable", "usb hub", "usbc"])
        self.assertEqual(t.prefix_search("x"), [])

    def test_balanced_height_vs_stick(self):
        pairs = [(i, i) for i in range(127)]
        balanced = BinarySearchTree.build_balanced(pairs)
        stick = BinarySearchTree()
        for k, v in pairs:
            stick.insert(k, v)
        self.assertEqual(balanced.height(), 7)
        self.assertEqual(stick.height(), 127)

    def test_empty_tree(self):
        t = BinarySearchTree()
        self.assertEqual((t.inorder(), t.height(), t.min_key(), t.search(1)), ([], 0, None, []))


class SearchSortTests(unittest.TestCase):
    def test_linear_and_binary_search(self):
        data = [5, 3, 9, 1]
        self.assertEqual(linear_search(data, 9), (2, 3))
        self.assertEqual(linear_search(data, 7)[0], -1)
        ordered = sorted(data)
        self.assertEqual(binary_search(ordered, 9)[0], 3)
        self.assertEqual(binary_search(ordered, 4)[0], -1)
        self.assertEqual(binary_search([], 1), (-1, 0))

    def test_binary_search_every_element_random(self):
        random.seed(1)
        data = sorted(random.sample(range(1000), 200))
        for i, v in enumerate(data):
            self.assertEqual(binary_search(data, v)[0], i)

    def test_sorts_match_python_sorted(self):
        random.seed(2)
        for n in (0, 1, 2, 17, 150):
            data = [random.randint(0, 40) for _ in range(n)]
            for rev in (False, True):
                self.assertEqual(merge_sort(data, reverse=rev), sorted(data, reverse=rev))
                self.assertEqual(bubble_sort(data, reverse=rev), sorted(data, reverse=rev))

    def test_sorts_are_stable(self):
        pairs = [(2, "a"), (1, "b"), (2, "c"), (1, "d"), (2, "e")]
        expected = sorted(pairs, key=lambda p: p[0])
        self.assertEqual(merge_sort(pairs, key=lambda p: p[0]), expected)
        self.assertEqual(bubble_sort(pairs, key=lambda p: p[0]), expected)
        self.assertEqual(merge_sort(pairs, key=lambda p: p[0], reverse=True),
                         sorted(pairs, key=lambda p: p[0], reverse=True))

    def test_stats_and_input_untouched(self):
        data, stats = [3, 1, 2], {}
        bubble_sort(data, stats=stats)
        self.assertGreater(stats["comparisons"], 0)
        self.assertEqual(data, [3, 1, 2])
        sorted_stats = {}
        bubble_sort([1, 2, 3, 4], stats=sorted_stats)
        self.assertEqual(sorted_stats["comparisons"], 3)    # early exit: best case O(n)


if __name__ == "__main__":
    unittest.main()
