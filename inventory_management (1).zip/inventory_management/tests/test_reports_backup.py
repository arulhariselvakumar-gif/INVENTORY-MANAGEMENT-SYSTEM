import csv
import os
import unittest

from errors import ValidationError
from sample_data import load_sample_data
from services.container import Services
from services.charts import sales_trend_figure, stock_distribution_figure
from tests.base import DbTestCase


class ReportTests(DbTestCase):
    def test_valuation_and_dashboard(self):
        self.make_product("V-1", "One", cost=10, price=20, qty=5)
        self.make_product("V-2", "Two", cost=100, price=150, qty=2)
        stats = self.svc.reports.dashboard_stats()
        self.assertEqual((stats["total_products"], stats["total_quantity"], stats["stock_value"]), (2, 7, 250.0))
        val = self.svc.reports.valuation()
        self.assertEqual((val["rows"][0]["cost_value"], val["rows"][0]["retail_value"],
                          val["rows"][0]["potential_margin"]), (250.0, 400.0, 150.0))

    def test_profit_is_not_revenue_and_handles_discount_and_returns(self):
        pid = self.make_product(cost=60, price=100, qty=20)
        sid = self.svc.sales.create([(pid, 5)], "A", 10, 18, self.uid, sale_date="2026-03-01")
        profit = self.svc.reports.profit()["rows"][0]
        self.assertEqual((profit["units"], profit["revenue"], profit["cost"], profit["profit"]), (5, 450.0, 300.0, 150.0))
        self.svc.sales.return_items(sid, {self.svc.sales.get(sid)["items"][0]["id"]: 2}, "faulty", self.uid)
        profit = self.svc.reports.profit()["rows"][0]
        self.assertEqual((profit["units"], profit["revenue"], profit["profit"]), (3, 270.0, 90.0))
        self.assertIn("not net profit", self.svc.reports.profit()["summary"])
        self.assertEqual(self.svc.reports.dashboard_stats()["sales_revenue"], 270.0)   # tax excluded

    def test_date_filters_best_sellers_supplier_summary(self):
        a, b = self.make_product("D-A", "A", qty=50), self.make_product("D-B", "B", qty=50)
        self.svc.sales.create([(a, 5)], user_id=self.uid, sale_date="2026-01-10")
        self.svc.sales.create([(a, 2), (b, 9)], user_id=self.uid, sale_date="2026-02-10")
        self.svc.purchases.create(self.sup, "2026-01-05", [(a, 10, 5)], user_id=self.uid, confirm=True)
        self.assertEqual(len(self.svc.reports.sales("2026-02-01", "2026-02-28")["rows"]), 1)
        self.assertEqual(len(self.svc.reports.sales()["rows"]), 2)
        best = self.svc.reports.best_sellers()["rows"]
        self.assertEqual([(r["sku"], r["units_sold"]) for r in best], [("D-B", 9), ("D-A", 7)])
        sup = self.svc.reports.supplier_summary()["rows"][0]
        self.assertEqual((sup["supplier"], sup["units"], sup["total_spent"]), ("Acme Traders", 10, 50.0))
        with self.assertRaises(ValidationError):
            self.svc.reports.sales("not-a-date")

    def test_every_report_runs_and_exports_csv(self):
        load_sample_data(self.svc, self.uid)
        for name in self.svc.reports.REPORTS:
            report = self.svc.reports.run(name)
            path = os.path.join(self.tmp, "r.csv")
            n = self.svc.reports.export_csv(report, path)
            with open(path, encoding="utf-8-sig", newline="") as fh:
                rows = list(csv.reader(fh))
            self.assertEqual(len(rows) - 1, n, name)
            self.assertEqual(rows[0], [h for _, h in report["columns"]], name)

    def test_charts_build(self):
        load_sample_data(self.svc, self.uid)
        self.assertTrue(stock_distribution_figure(self.svc.reports.stock_by_category()).axes)
        self.assertTrue(sales_trend_figure(self.svc.reports.sales_trend()).axes)
        stock_distribution_figure([]).savefig(os.path.join(self.tmp, "e.png"))      # empty-data branch


class CsvImportTests(DbTestCase):
    def test_round_trip_and_error_reporting(self):
        self.make_product("C-1", "Alpha", qty=4)
        path = os.path.join(self.tmp, "p.csv")
        self.assertEqual(self.svc.csv.export_products(path), 1)
        with open(path, "a", encoding="utf-8", newline="") as fh:
            fh.write("C-2,Beta,Newcat,,5,9,3,1,\nC-1,Dup,General,,1,2,1,1,\nC-3,Bad,General,,abc,2,1,1,\n"
                     "C-4,Gamma,General,Nobody Ltd,1,2,1,1,\n")
        imported, errors = self.svc.csv.import_products(path, self.uid)
        self.assertEqual(imported, 1)
        self.assertEqual(len(errors), 4)   # re-imported C-1 (line 2), duplicate C-1, bad cost price, unknown supplier
        self.assertTrue(any("already used" in e for e in errors))
        self.assertTrue(any("Cost price" in e for e in errors))
        self.assertTrue(any("unknown supplier" in e for e in errors))
        self.assertEqual(self.svc.products.build_index().hash_lookup("sku", "c-2")["results"][0]["name"], "Beta")

    def test_missing_columns_and_missing_file(self):
        bad = os.path.join(self.tmp, "bad.csv")
        with open(bad, "w") as fh:
            fh.write("a,b\n1,2\n")
        with self.assertRaises(ValidationError):
            self.svc.csv.import_products(bad, self.uid)
        with self.assertRaises(ValidationError):
            self.svc.csv.import_products(os.path.join(self.tmp, "nope.csv"), self.uid)


class BackupTests(DbTestCase):
    def test_backup_then_restore_brings_data_back(self):
        pid = self.make_product(qty=10)
        path = self.svc.backup.backup()
        self.assertTrue(os.path.getsize(path) > 0)
        self.svc.sales.create([(pid, 4)], user_id=self.uid)
        self.svc.products.delete(self.make_product("X-2", "Extra"), self.uid)
        self.assertEqual(self.qty(pid), 6)
        safety = self.svc.backup.restore(path)
        self.assertTrue(os.path.exists(safety))
        self.assertEqual((self.qty(pid), len(self.svc.sales.list())), (10, 0))
        self.svc.sales.create([(pid, 1)], user_id=self.uid)                 # live DB still works after restore
        self.assertEqual(self.qty(pid), 9)

    def test_invalid_backups_are_refused(self):
        junk = os.path.join(self.tmp, "junk.db")
        with open(junk, "wb") as fh:
            fh.write(b"this is not sqlite" * 50)
        other = os.path.join(self.tmp, "other.db")
        import sqlite3
        c = sqlite3.connect(other); c.execute("CREATE TABLE t(x)"); c.commit(); c.close()
        for bad in (junk, other, os.path.join(self.tmp, "missing.db"), self.db_path):
            with self.assertRaises(ValidationError):
                self.svc.backup.restore(bad)
        with self.assertRaises(ValidationError):
            self.svc.backup.backup(self.db_path)
        self.assertEqual(len(self.svc.backup.list_backups()), 0)


class PersistenceTests(DbTestCase):
    def test_data_survives_closing_and_reopening(self):
        pid = self.make_product(qty=10)
        self.svc.sales.create([(pid, 3)], "Persist", 0, 18, self.uid)
        self.svc.close()
        reopened = Services(self.db_path, self.tmp)
        try:
            self.assertEqual(reopened.products.get(pid)["quantity"], 7)
            self.assertEqual(reopened.sales.list()[0]["customer_name"], "Persist")
            self.assertEqual(reopened.auth.login("admin", "Admin@123")["username"], "admin")
            self.assertEqual(reopened.inventory.verify_consistency(), [])
        finally:
            reopened.close()
            self.svc = Services(self.db_path, self.tmp)      # so tearDown has something to close


class SampleDataTests(DbTestCase):
    def test_sample_data_is_consistent(self):
        info = load_sample_data(self.svc, self.uid)
        self.assertEqual(info["products"], 20)
        self.assertEqual(self.svc.inventory.verify_consistency(), [])
        self.assertTrue(self.svc.inventory.low_stock("OUT"))
        self.assertEqual(self.svc.inventory.restock_queue().size(), 1)


if __name__ == "__main__":
    unittest.main()
