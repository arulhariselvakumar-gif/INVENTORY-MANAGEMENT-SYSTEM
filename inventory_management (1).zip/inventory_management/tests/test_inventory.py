import unittest

from errors import (BusinessRuleError, DuplicateError, InsufficientStockError, NotFoundError, ValidationError)
from services.inventory_service import apply_stock_change
from tests.base import DbTestCase


class StockTests(DbTestCase):
    def test_adjustment_records_movement_and_reason(self):
        pid = self.make_product(qty=10)
        res = self.svc.inventory.adjust_stock(pid, 7, "Damaged in store", self.uid)
        self.assertEqual((res["old"], res["new"], res["delta"]), (10, 7, -3))
        newest = self.svc.inventory.history_list(pid).head.value
        self.assertEqual((newest["movement_type"], newest["quantity_change"], newest["quantity_after"],
                          newest["reason"], newest["user_name"]), ("ADJUSTMENT", -3, 7, "Damaged in store", "admin"))

    def test_adjustment_validation(self):
        pid = self.make_product(qty=10)
        for args in ((10, "same"), (-1, "neg"), ("x", "bad"), (5, "")):
            with self.assertRaises((ValidationError,)):
                self.svc.inventory.adjust_stock(pid, args[0], args[1], self.uid)
        self.assertEqual(self.qty(pid), 10)

    def test_stock_can_never_go_negative(self):
        pid = self.make_product(qty=2)
        with self.assertRaises(InsufficientStockError):
            with self.svc.db.transaction():
                apply_stock_change(self.svc.db, pid, -3, "ADJUSTMENT")
        self.assertEqual(self.qty(pid), 2)
        with self.assertRaises(Exception):     # the database CHECK constraint is the last line of defence
            self.svc.db.execute("UPDATE products SET quantity = -1 WHERE id = ?", (pid,))

    def test_history_is_newest_first_linked_list(self):
        pid = self.make_product(qty=10)
        self.svc.inventory.adjust_stock(pid, 12, "count", self.uid)
        self.svc.sales.create([(pid, 2)], user_id=self.uid)
        types = [m["movement_type"] for m in self.svc.inventory.history_list(pid)]
        self.assertEqual(types, ["SALE", "ADJUSTMENT", "OPENING"])

    def test_consistency_check_and_recalculate(self):
        pid = self.make_product(qty=10)
        self.assertEqual(self.svc.inventory.verify_consistency(), [])
        self.svc.db.execute("UPDATE products SET quantity = 99 WHERE id = ?", (pid,))   # simulate corruption
        self.assertEqual(len(self.svc.inventory.verify_consistency()), 1)
        self.assertEqual(self.svc.inventory.recalculate_stock(self.uid), 1)
        self.assertEqual(self.qty(pid), 10)

    def test_movement_summary_adds_up(self):
        pid = self.make_product(qty=10)
        self.svc.purchases.create(self.sup, "2026-01-05", [(pid, 5, 9)], user_id=self.uid, confirm=True)
        self.svc.sales.create([(pid, 4)], user_id=self.uid)
        self.svc.inventory.adjust_stock(pid, 10, "recount", self.uid)       # 11 -> 10
        row = self.svc.inventory.movement_summary()[0]
        self.assertEqual((row["opening"], row["received"], row["sold"], row["returned"], row["adjusted"], row["current_qty"]),
                         (10, 5, 4, 0, -1, 10))
        self.assertEqual(row["opening"] + row["received"] - row["sold"] + row["returned"] + row["adjusted"], row["current_qty"])


class LowStockTests(DbTestCase):
    def test_low_out_and_suggested_quantity(self):
        self.make_product("A-OK", "Fine", qty=50, reorder=5)
        self.make_product("B-LOW", "Low", qty=3, reorder=10)
        self.make_product("C-OUT", "Out", qty=0, reorder=4)
        self.make_product("D-EDGE", "Edge", qty=5, reorder=5)      # equal to reorder level counts as low
        rows = {r["sku"]: r for r in self.svc.inventory.low_stock()}
        self.assertEqual(set(rows), {"B-LOW", "C-OUT", "D-EDGE"})
        self.assertEqual((rows["B-LOW"]["status"], rows["C-OUT"]["status"]), ("LOW", "OUT"))
        self.assertEqual(rows["B-LOW"]["suggested_qty"], 17)      # 2 x 10 - 3
        self.assertEqual(rows["C-OUT"]["suggested_qty"], 8)
        self.assertEqual(rows["D-EDGE"]["suggested_qty"], 5)
        self.assertEqual([r["sku"] for r in self.svc.inventory.low_stock("OUT")], ["C-OUT"])
        self.assertEqual(self.svc.reports.dashboard_stats()["low_stock"], 3)
        self.assertEqual(self.svc.reports.dashboard_stats()["out_of_stock"], 1)


class RestockQueueTests(DbTestCase):
    def test_fifo_processing_and_duplicates(self):
        a = self.make_product("Q-A", "First", qty=0)
        b = self.make_product("Q-B", "Second", qty=0)
        self.svc.inventory.queue_restock(a, self.uid)
        self.svc.inventory.queue_restock(b, self.uid)
        with self.assertRaises(DuplicateError):
            self.svc.inventory.queue_restock(a, self.uid)
        self.assertEqual([t["name"] for t in self.svc.inventory.restock_queue().to_list()], ["First", "Second"])
        self.assertEqual(self.svc.inventory.process_next_restock(self.uid)["name"], "First")
        self.assertEqual(self.svc.inventory.process_next_restock(self.uid)["name"], "Second")
        with self.assertRaises(BusinessRuleError):
            self.svc.inventory.process_next_restock(self.uid)
        self.svc.inventory.queue_restock(a, self.uid)         # allowed again once processed


class UndoTests(DbTestCase):
    def test_undo_adjustment_and_edit_in_lifo_order(self):
        pid = self.make_product(qty=10, price=20)
        self.svc.inventory.adjust_stock(pid, 6, "oops", self.uid)
        self.svc.undo.record_adjustment(pid, -4, "Adjusted Widget 10 -> 6")
        old = self.svc.products.update(pid, {"sku": "SKU-1", "name": "Widget", "category_id": self.cat,
                                             "cost_price": 10, "selling_price": 99, "reorder_level": 5}, self.uid)
        self.svc.undo.record_product_edit(pid, old, "Edited Widget")
        self.svc.undo.undo(self.uid)                                     # edit undone first
        self.assertEqual(self.svc.products.get(pid)["selling_price"], 20)
        self.assertEqual(self.qty(pid), 6)
        self.svc.undo.undo(self.uid)                                     # then the adjustment
        self.assertEqual(self.qty(pid), 10)
        with self.assertRaises(BusinessRuleError):                       # empty stack
            self.svc.undo.undo(self.uid)

    def test_failed_undo_keeps_entry(self):
        pid = self.make_product(qty=10)
        self.svc.inventory.adjust_stock(pid, 15, "found", self.uid)
        self.svc.undo.record_adjustment(pid, 5, "found 5")
        self.svc.sales.create([(pid, 14)], user_id=self.uid)             # only 1 left, undo would need -5
        with self.assertRaises(Exception):
            self.svc.undo.undo(self.uid)
        self.assertTrue(self.svc.undo.can_undo())


if __name__ == "__main__":
    unittest.main()
