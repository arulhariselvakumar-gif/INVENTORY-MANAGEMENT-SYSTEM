"""Binary Search Tree. Used as a sorted product-name index (prefix search + sorted listing).
Each node keeps a LIST of values because two products may share the same key."""


from dsa.sorting import merge_sort


class BSTNode:
    __slots__ = ("key", "values", "left", "right")

    def __init__(self, key, value):
        self.key = key
        self.values = [value]
        self.left = None
        self.right = None


class BinarySearchTree:
    def __init__(self):
        self.root = None
        self._count = 0

    def insert(self, key, value):
        self._count += 1
        if self.root is None:
            self.root = BSTNode(key, value)
            return
        cur = self.root
        while True:
            if key == cur.key:
                cur.values.append(value)
                return
            side = "left" if key < cur.key else "right"
            nxt = getattr(cur, side)
            if nxt is None:
                setattr(cur, side, BSTNode(key, value))
                return
            cur = nxt

    @classmethod
    def build_balanced(cls, pairs):
        """pairs = [(key, value), ...]. Sorting first and inserting the middle element
        first keeps the height near log2(n); inserting sorted data one by one would
        create a 'stick' of height n."""
        tree = cls()
        ordered = merge_sort(pairs, key=lambda p: p[0])      # our own merge sort

        def add(lo, hi):
            if lo > hi:
                return
            mid = (lo + hi) // 2
            tree.insert(*ordered[mid])
            add(lo, mid - 1)
            add(mid + 1, hi)

        add(0, len(ordered) - 1)
        return tree

    def search(self, key):
        cur = self.root
        while cur:
            if key == cur.key:
                return list(cur.values)
            cur = cur.left if key < cur.key else cur.right
        return []

    def prefix_search(self, prefix):
        """All values whose key starts with prefix. Subtrees that cannot match are skipped."""
        out = []

        def walk(node):
            if node is None:
                return
            if node.key >= prefix:
                walk(node.left)
            if node.key.startswith(prefix):
                out.extend(node.values)
            if node.key[:len(prefix)] <= prefix:
                walk(node.right)

        walk(self.root)
        return out

    def inorder(self):
        """Values in ascending key order (iterative, so deep trees cannot overflow the stack)."""
        out, stack, cur = [], [], self.root
        while stack or cur:
            while cur:
                stack.append(cur)
                cur = cur.left
            cur = stack.pop()
            out.extend(cur.values)
            cur = cur.right
        return out

    def height(self):
        def h(node):
            return 0 if node is None else 1 + max(h(node.left), h(node.right))
        return h(self.root)

    def min_key(self):
        cur = self.root
        while cur and cur.left:
            cur = cur.left
        return cur.key if cur else None

    def max_key(self):
        cur = self.root
        while cur and cur.right:
            cur = cur.right
        return cur.key if cur else None

    def __len__(self):
        return self._count
