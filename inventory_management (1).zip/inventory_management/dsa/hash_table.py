"""Hash table with separate chaining. Used for O(1) average SKU / ID lookup."""


class HashTable:
    def __init__(self, buckets=16, max_load=0.75):
        self._buckets = [[] for _ in range(max(buckets, 4))]
        self._size = 0
        self._max_load = max_load

    def _index(self, key):
        return hash(key) % len(self._buckets)

    def put(self, key, value):
        bucket = self._buckets[self._index(key)]
        for pair in bucket:
            if pair[0] == key:
                pair[1] = value
                return
        bucket.append([key, value])
        self._size += 1
        if self._size / len(self._buckets) > self._max_load:
            self._resize()

    def get(self, key, default=None):
        for k, v in self._buckets[self._index(key)]:
            if k == key:
                return v
        return default

    def contains(self, key):
        return any(k == key for k, _ in self._buckets[self._index(key)])

    def remove(self, key):
        bucket = self._buckets[self._index(key)]
        for i, (k, _) in enumerate(bucket):
            if k == key:
                del bucket[i]
                self._size -= 1
                return True
        return False

    def keys(self):
        return [k for b in self._buckets for k, _ in b]

    def items(self):
        return [(k, v) for b in self._buckets for k, v in b]

    def bucket_count(self):
        return len(self._buckets)

    def _resize(self):
        old = self.items()
        self._buckets = [[] for _ in range(len(self._buckets) * 2)]
        self._size = 0
        for k, v in old:
            self.put(k, v)

    def __len__(self):
        return self._size

    def __contains__(self, key):
        return self.contains(key)
