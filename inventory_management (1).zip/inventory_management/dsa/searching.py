"""Searching algorithms. Both return (index_or_-1, comparisons) so the UI can show the work done."""


def linear_search(items, target, key=lambda x: x):
    """Works on UNSORTED data. Best O(1), average/worst O(n), space O(1)."""
    comparisons = 0
    for i, item in enumerate(items):
        comparisons += 1
        if key(item) == target:
            return i, comparisons
    return -1, comparisons


def binary_search(items, target, key=lambda x: x):
    """Works ONLY if items are sorted ascending by the same key.
    Best O(1), average/worst O(log n), space O(1)."""
    lo, hi, comparisons = 0, len(items) - 1, 0
    while lo <= hi:
        mid = (lo + hi) // 2
        comparisons += 1
        value = key(items[mid])
        if value == target:
            return mid, comparisons
        if value < target:
            lo = mid + 1
        else:
            hi = mid - 1
    return -1, comparisons


def linear_search_all(items, predicate):
    """Return every item matching predicate (used for substring searches). O(n)."""
    return [item for item in items if predicate(item)]
