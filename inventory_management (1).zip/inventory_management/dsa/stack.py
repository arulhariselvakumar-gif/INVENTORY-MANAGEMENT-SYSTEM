"""Stack (LIFO) built on a Python list. Used for the undo history."""


class Stack:
    def __init__(self, capacity=None):
        self._items = []
        self.capacity = capacity          # None = unlimited

    def push(self, item):
        if self.capacity is not None and len(self._items) >= self.capacity:
            del self._items[0]            # drop the oldest entry so memory stays bounded
        self._items.append(item)

    def pop(self):
        if not self._items:
            raise IndexError("pop from an empty stack")
        return self._items.pop()

    def peek(self):
        if not self._items:
            raise IndexError("peek at an empty stack")
        return self._items[-1]

    def is_empty(self):
        return not self._items

    def size(self):
        return len(self._items)

    def clear(self):
        self._items.clear()

    def to_list(self):
        """Top of the stack first."""
        return list(reversed(self._items))

    def __len__(self):
        return len(self._items)
