"""Singly linked list. Used to hold a product's stock-movement history (newest first)."""


class Node:
    __slots__ = ("value", "next")

    def __init__(self, value, next_node=None):
        self.value = value
        self.next = next_node


class LinkedList:
    def __init__(self):
        self.head = None
        self._size = 0

    def prepend(self, value):             # O(1) - perfect for "newest first"
        self.head = Node(value, self.head)
        self._size += 1

    def append(self, value):              # O(n) because we only keep a head pointer
        node = Node(value)
        if self.head is None:
            self.head = node
        else:
            cur = self.head
            while cur.next:
                cur = cur.next
            cur.next = node
        self._size += 1

    def find(self, predicate):
        cur = self.head
        while cur:
            if predicate(cur.value):
                return cur.value
            cur = cur.next
        return None

    def remove_first(self, predicate):
        prev, cur = None, self.head
        while cur:
            if predicate(cur.value):
                if prev:
                    prev.next = cur.next
                else:
                    self.head = cur.next
                self._size -= 1
                return True
            prev, cur = cur, cur.next
        return False

    def reverse(self):
        prev, cur = None, self.head
        while cur:
            cur.next, prev, cur = prev, cur, cur.next
        self.head = prev

    def __iter__(self):
        cur = self.head
        while cur:
            yield cur.value
            cur = cur.next

    def to_list(self):
        return list(self)

    def __len__(self):
        return self._size
