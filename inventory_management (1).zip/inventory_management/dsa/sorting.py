"""Sorting algorithms written from scratch. Both accept key= and reverse=, and fill an
optional stats dict with the number of comparisons so the UI can display it."""


def bubble_sort(items, key=lambda x: x, reverse=False, stats=None):
    """Repeatedly swap neighbours that are out of order. Stable. Best O(n) (already sorted,
    thanks to the early-exit flag), average/worst O(n^2), space O(1) extra."""
    data = list(items)
    comparisons = 0
    n = len(data)
    for end in range(n - 1, 0, -1):
        swapped = False
        for i in range(end):
            comparisons += 1
            a, b = key(data[i]), key(data[i + 1])
            if (a < b) if reverse else (a > b):
                data[i], data[i + 1] = data[i + 1], data[i]
                swapped = True
        if not swapped:
            break
    if stats is not None:
        stats["comparisons"] = comparisons
    return data


def merge_sort(items, key=lambda x: x, reverse=False, stats=None):
    """Divide in halves, sort each, merge. Stable. Always O(n log n) time, O(n) space."""
    counter = {"comparisons": 0}

    def merge(left, right):
        out, i, j = [], 0, 0
        while i < len(left) and j < len(right):
            counter["comparisons"] += 1
            a, b = key(left[i]), key(right[j])
            take_left = (a >= b) if reverse else (a <= b)    # <= / >= keeps equal items in order
            if take_left:
                out.append(left[i])
                i += 1
            else:
                out.append(right[j])
                j += 1
        out.extend(left[i:])
        out.extend(right[j:])
        return out

    def sort(part):
        if len(part) <= 1:
            return part
        mid = len(part) // 2
        return merge(sort(part[:mid]), sort(part[mid:]))

    result = sort(list(items))
    if stats is not None:
        stats["comparisons"] = counter["comparisons"]
    return result
