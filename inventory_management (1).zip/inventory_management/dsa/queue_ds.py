"""Queue (FIFO) as a circular array.  File is not called queue.py so it can never
shadow Python's built-in 'queue' module."""


class Queue:
    def __init__(self, capacity=8):
        self._data = [None] * max(capacity, 2)
        self._head = 0
        self._size = 0

    def enqueue(self, item):
        if self._size == len(self._data):
            self._grow()
        self._data[(self._head + self._size) % len(self._data)] = item
        self._size += 1

    def dequeue(self):
        if self._size == 0:
            raise IndexError("dequeue from an empty queue")
        item = self._data[self._head]
        self._data[self._head] = None
        self._head = (self._head + 1) % len(self._data)
        self._size -= 1
        return item

    def front(self):
        if self._size == 0:
            raise IndexError("front of an empty queue")
        return self._data[self._head]

    def is_empty(self):
        return self._size == 0

    def size(self):
        return self._size

    def to_list(self):
        """Front of the queue first."""
        return [self._data[(self._head + i) % len(self._data)] for i in range(self._size)]

    def _grow(self):
        """Double the array and unwrap the items so the head is at index 0 again."""
        new_data = [None] * (len(self._data) * 2)
        for i in range(self._size):
            new_data[i] = self._data[(self._head + i) % len(self._data)]
        self._data, self._head = new_data, 0

    def __len__(self):
        return self._size
